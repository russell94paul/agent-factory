# AI Console / Claude-Style Workspace

## Core product model
The UI is not a chat app. It is an **attention and execution environment**.

## Session list card
Each session should expose:
- title / mission;
- repo or system;
- semantic state;
- elapsed/last activity;
- "needs you" reason;
- current phase;
- pending artifact/diff;
- cost/usage only if useful.

## Session detail layout
Recommended desktop pattern:

**Left: session navigator (collapsible)**
- related sessions
- mission threads
- checkpoints

**Center: conversation / activity timeline**
- messages
- tool events summarized
- major state transitions
- approvals anchored to rationale

**Right: persistent inspector**
Tabs:
- Context
- Files/Diff
- Artifacts
- Evidence
- Plan
- Runs/Logs

The right inspector should follow the selected event/object without losing the center timeline.

## Attention inbox
One unified queue for all sessions:
- approval needed
- question
- failure
- budget warning
- client input
- merge gate
- deployment gate

Support:
- approve;
- modify;
- delegate;
- snooze;
- batch-safe approvals.

## Session state language
Use exactly one canonical vocabulary across desktop/mobile/web:
Working / Waiting / Blocked / Reviewing / Paused / Done / Failed.

## Returning to a session
Show a "Since you were away" summary before raw transcript:
- 3–5 meaningful changes;
- decisions made;
- files/artifacts created;
- blockers;
- next action.

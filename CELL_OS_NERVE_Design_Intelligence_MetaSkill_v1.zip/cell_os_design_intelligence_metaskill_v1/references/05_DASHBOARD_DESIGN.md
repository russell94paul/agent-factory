# Dashboard Design

Dashboards should answer decisions, not merely display metrics.

## Page sequence
1. **What needs attention?**
2. **What changed?**
3. **What is healthy/unhealthy?**
4. **Why?**
5. **What can I do?**

## Home dashboard
Top band:
- Needs You
- Active Missions
- Recently Completed
- System/Integration incidents

Middle:
- session activity lanes;
- work queue;
- upcoming automations.

Bottom:
- trends and supporting analytics.

## Avoid
- KPI card grids where every metric has equal visual weight.
- red/green-only semantics.
- charts without decision context.
- legends far away from data.
- totals without comparison or baseline.

## Operational metric framing
Every metric should have at least one of:
- target;
- baseline;
- previous period;
- expected band;
- explanatory annotation.

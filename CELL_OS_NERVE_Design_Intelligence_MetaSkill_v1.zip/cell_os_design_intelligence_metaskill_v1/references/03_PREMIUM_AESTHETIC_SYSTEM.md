# Premium Aesthetic System

"Premium" should feel restrained, coherent and precise—not busy.

## Visual direction
- Strong typography hierarchy.
- Generous whitespace around decisions; higher density inside data regions.
- One accent color family plus semantic status colors.
- Surfaces separated by spacing and subtle tonal shifts before borders.
- Borders used sparingly; avoid boxed-everything dashboards.
- Use depth only to clarify layering, not as decoration.
- Prefer 8px base spacing rhythm with a small set of exceptions.
- One icon language across the product.

## Signature premium moments
- Smooth command palette entrance.
- Cross-page shared-element continuity for selected session/artifact.
- Inspector panel that feels attached to the selected object.
- Tiny state transitions when work changes from working → waiting → done.
- Beautiful empty states that teach the next action.
- High-quality skeletons that preserve layout geometry.

## Avoid
- gratuitous glassmorphism;
- neon everywhere;
- oversaturated gradients behind text;
- excessive glow;
- dozens of card containers;
- giant hero areas inside operational software;
- animated background effects during focused work.

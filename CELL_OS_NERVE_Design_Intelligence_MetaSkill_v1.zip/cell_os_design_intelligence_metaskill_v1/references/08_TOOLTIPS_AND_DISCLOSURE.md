# Tooltips & Progressive Disclosure

## Tooltips are for
- unfamiliar icon labels;
- short definitions;
- timestamps;
- abbreviated metrics;
- supplemental provenance.

## Tooltips are not for
- critical instructions;
- approvals;
- errors;
- long explanations;
- information required to complete a task.

## Accessibility contract
Hover/focus content should be:
- dismissible;
- hoverable;
- persistent long enough to consume;
- keyboard-triggerable when pointer-triggerable.

## Premium inspector pattern
For richer "extra information", prefer a right-side inspector or popover:
- summary;
- properties;
- relationships;
- evidence;
- actions.

Use hover preview for speed, click to pin for deeper inspection.

# Accessibility

Target WCAG 2.2 AA as baseline.

## Non-negotiables
- full keyboard path;
- visible focus;
- logical DOM/focus order;
- semantic labels;
- no status communicated by color alone;
- sufficient contrast;
- zoom/reflow support;
- appropriately sized pointer targets;
- screen-reader announcements for async status changes;
- reduced motion support.

## Agent UI special cases
- Announce when a session changes to "Waiting for user".
- Do not repeatedly announce streaming token output.
- Permission prompts must be reachable from the active client.
- If a live region is used, announce meaningful state transitions, not every event.
- Tooltips must not be the sole location of important content.

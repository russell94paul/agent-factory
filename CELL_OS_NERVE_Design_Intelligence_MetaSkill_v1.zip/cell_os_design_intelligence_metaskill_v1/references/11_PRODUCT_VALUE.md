# Subscription Value / Product Prioritization

A paid feature should meaningfully improve one or more:
- time saved;
- interruptions avoided;
- errors prevented;
- coordination reduced;
- trust/evidence improved;
- work completed while user is away;
- reuse across projects;
- visibility across systems.

## Feature score
Score 1–5 on:
- frequency;
- pain severity;
- unique advantage;
- trust benefit;
- retention potential;
- implementation complexity (reverse scored).

Avoid premium features that are only visual skins.

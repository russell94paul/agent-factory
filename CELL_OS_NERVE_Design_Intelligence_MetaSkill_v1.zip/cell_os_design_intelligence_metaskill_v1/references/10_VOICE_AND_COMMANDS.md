# Voice & Command Interaction

Voice should accelerate the product, not become a gimmick.

## Recommended modes

### Push-to-talk
Hold a key/button, speak a command:
- "Start a new session for SALES-014."
- "Show sessions waiting for me."
- "Approve the safe file-read actions."
- "Summarize what changed in Marketing Model."
- "Open the latest design artifact."

### Wake phrase
Optional and off by default.
Use only if the product can clearly indicate listening state and provide privacy controls.

### Spoken brief
Optional "read me the attention queue" mode for hands-busy contexts.

## Voice UX requirements
- always show transcription before consequential actions;
- require confirmation for destructive/high-risk actions;
- support correction without starting over;
- visual fallback for every voice action;
- never require voice for core functionality.

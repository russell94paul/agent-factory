# Information Architecture & Navigation

## Principle
Permanent navigation should represent durable user mental models, not implementation modules.

## Recommended CELL OS hierarchy

### Primary rail
- **Home** — attention, active work, recent outcomes.
- **Missions** — scoped units of work / tickets / objectives.
- **Sessions** — live and historical agent conversations/executions.
- **Automations** — recurring and event-driven workflows.
- **Artifacts** — specs, reports, diffs, diagrams, research, deliverables.
- **Knowledge** — memory, linked context, provenance, reusable facts.
- **Insights** — performance, reliability, cost, quality, trend analysis.
- **Integrations** — repos, email, calendar, databases, observability, APIs.

### Global layer
- Command palette
- Universal search
- Attention inbox
- Voice command
- User/system menu

## Layout rules
- Keep the left rail narrow and stable.
- Support icon + label; compact icon-only is optional, never default for first use.
- Allow pinning favorite missions/sessions under the relevant parent.
- Use breadcrumbs only for true hierarchy; do not use them as decoration.
- Contextual subtabs belong in the page header.
- Preserve the same right-side inspector pattern across pages.

## Navigation accelerators
- Cmd/Ctrl+K: command/search.
- G then H/M/S/A/R/K/I: Go to major areas.
- Cmd/Ctrl+Shift+P: action palette.
- `/` focuses universal search when safe.
- Escape closes inspectors/modals one layer at a time.

# HCI & Human Factors

## Optimize cognitive bandwidth
Agentic software creates a new HCI problem: users supervise processes that continue while attention moves elsewhere.

Design for:
- prospective memory ("what did I need to come back to?");
- interruption recovery;
- multi-session monitoring;
- trust calibration;
- decision fatigue;
- context reacquisition.

## Required patterns

### Attention queue
Aggregate all "needs human" events into one place:
- permission
- clarifying question
- failed test
- merge/release gate
- client response
- budget threshold
- conflict / ambiguity

### Resumption cues
When returning to a session, show:
- what changed since last seen;
- current state;
- last meaningful action;
- next requested decision;
- generated artifacts/diffs.

### Stable context
Never allow a system prompt/dialog to consume keystrokes intended for the message composer.
Never silently reset the user's reading position.
Never collapse important evidence solely because a new event arrives.

### Trust calibration
Differentiate:
- observed fact;
- agent inference;
- recommendation;
- proposed action;
- completed action.

Use provenance and confidence only when meaningful—not decorative percentages.

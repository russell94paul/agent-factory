# Charts & Data Visualization

## Chart selection
- Trend over time → line / area sparingly.
- Ranked comparison → horizontal bar.
- Part-to-whole → stacked bar; avoid many-slice pies.
- Distribution → histogram / box / violin when audience supports it.
- Relationship → scatter.
- Flow/dependency → Sankey/network only when structure is the question.
- Operational state → timeline / lane / event strip.
- SLA / target → bullet chart / target band.
- Multi-agent performance → small multiples or sortable table + sparklines.

## Interaction
Tooltips should add detail, not contain the only interpretation.
Crosshair and synchronized hover are useful for aligned time series.
Selection should support drill-down into the underlying run/session.
Use brushing/zoom only when data density warrants it.

## Animation
Animate data transitions only when it preserves object identity and aids change comprehension.
Never animate every point from zero on every refresh.

# Motion System

## Motion roles
1. Orientation — where did this panel/card come from?
2. Causality — what changed because of my action?
3. Status — working/waiting/done transitions.
4. Continuity — same object across surfaces.
5. Feedback — pressed/saved/queued/approved.

## Timing bands
- Micro feedback: ~80–160ms
- Small UI transitions: ~160–240ms
- Panel/page transitions: ~220–360ms
- Complex shared-element transitions: keep under ~500ms unless user-triggered and meaningful

Use easing that enters gently and exits decisively.
Avoid identical timing for every element.

## Reduced motion
Respect `prefers-reduced-motion`.
In reduced mode:
- remove translation/scale choreography;
- retain opacity or immediate state changes;
- preserve all information.

## Agent-specific motion
A session that changes state should not jump around the list.
Use a subtle state morph and keep spatial position unless the user explicitly sorts by state.

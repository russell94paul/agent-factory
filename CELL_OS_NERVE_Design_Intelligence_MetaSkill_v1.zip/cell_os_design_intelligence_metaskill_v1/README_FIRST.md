# CELL OS Design Intelligence Meta-Skill v1

This pack is a **self-contained design "skill of skills"** for Claude/Claude Code-style product work.

It was assembled on 2026-09-02 from:
- a GitHub scan for UI, UX, product design, HCI/psychology, dashboard/data-viz, motion, accessibility and design-audit skills;
- a focused research pass on Claude Code UX friction;
- a synthesis tailored to the CELL OS / former "Switchboard" console concept.

## What is inside

- `SKILL.md` — the meta-skill/router Claude should load first.
- `DEEP_RESEARCH_REPORT.md` — product/UX research, Claude Code friction map, premium feature opportunities, navigation architecture and page layouts.
- `CLAUDE_DESIGN_DEEP_RESEARCH_PROMPT.md` — prompt to hand to Claude Design / Claude Code.
- `references/` — focused mini-skills for HCI, navigation, dashboards, charts, motion, tooltips, accessibility, premium aesthetics, AI-console design and voice UX.
- `sources/curated_github_skills.json` — the repositories discovered in this pass.
- `sources/research_sources.json` — current web sources used in the report.
- `bootstrap/clone_curated_skills.sh` and `.ps1` — optional scripts that clone the source repositories into a local `vendor-skills/` folder.

## Important licensing note

This ZIP does **not blindly redistribute third-party repositories**. The GitHub connector can inspect public repositories but cannot export arbitrary repository ZIP binaries into this runtime. Instead, the pack is self-contained and includes clone scripts plus a source manifest.

The core repo `nextlevelbuilder/ui-ux-pro-max-skill` was verified as MIT during this research pass. For every other repo, review its license before copying or redistributing its contents.

## Recommended use

1. Give this entire folder to Claude.
2. Tell Claude to read `SKILL.md`.
3. Then run the prompt in `CLAUDE_DESIGN_DEEP_RESEARCH_PROMPT.md`.
4. If you want the third-party source skills locally, run the clone script and let Claude inspect them as evidence, not as unquestionable doctrine.

## Product naming

"Switchboard" should be treated as retired in the design work. The report includes a naming shortlist; the working recommendation is **NERVE** as an internal product codename because the console routes signals, attention, commands and state across sessions and systems. Do a proper trademark/domain screen before public launch.

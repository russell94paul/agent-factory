# Deep Research Report — CELL OS / Former "Switchboard" UI

## Executive thesis

The opportunity is not to build a prettier terminal wrapper.

The opportunity is to build a **premium supervisory operating surface for AI work**:
a place where a user can see every active mission, session, blocked approval, artifact,
automation, client input, repository change and important system signal without carrying
all of that state in their head.

The strongest design idea is:

> **Design around attention, not around chat.**

A premium AI console should tell the user, immediately:
1. What needs me?
2. What is working?
3. What is blocked?
4. What changed?
5. What finished?
6. What is risky?
7. What can I safely delegate?

---

## 1. Friction map: working with Claude Code

### F1 — Re-explaining context
A recurring community complaint is the overhead of explaining context that already exists
in the developer's head or repo. This makes the interaction feel slower than simply coding
when context acquisition is poor.

**Product implication:** persistent project/memory context, visual context packs, mission
briefs, and reusable context bundles should be first-class objects.

### F2 — "Busy" does not mean "progressing"
Recent Claude Code issue reports describe remote sessions that appear active while actually
waiting on permissions or input.

**Product implication:** every session gets a semantic state, and "Needs You" is a separate
attention class rather than another activity indicator.

### F3 — Permission fatigue
Repeated or unreliable approval prompts interrupt flow and can create prompt fatigue.

**Product implication:** unified approval inbox, clear scope, batch-safe approval,
permission profiles, and adjacent rationale.

### F4 — Remote parity gaps
Reports describe permission dialogs that appear only on the host terminal, leaving remote
sessions blocked.

**Product implication:** approvals and questions must be channel-independent and synced
across desktop/web/mobile.

### F5 — Focus stealing
A reported regression caused permission dialogs to capture keyboard input while users were
typing.

**Product implication:** never steal focus from active composition. Queue the prompt and
show a non-destructive "needs attention" banner.

### F6 — Transcript disorientation
Long terminal histories can re-render and scroll in disruptive ways.

**Product implication:** event virtualization, stable scroll anchors, "return to last read,"
"since you were away," and semantic timeline landmarks.

### F7 — Approval without nearby context
When scrolling moves the explanation away from a permission dialog, users cannot easily
judge whether to approve.

**Product implication:** every approval card includes the immediate rationale, command/tool,
scope, affected resources and reversible/irreversible status.

### F8 — Multi-session attention tax
Running several parallel sessions creates an operator problem: which one is progressing and
which one needs intervention?

**Product implication:** session overview lanes, attention inbox, sorting by "needs me",
and push/desktop notifications.

### F9 — Weak artifact continuity
Chat output, code diff, plan, test evidence and generated documents can feel scattered.

**Product implication:** a persistent artifact model with linked provenance back to mission,
session and commit.

### F10 — Mode fragmentation
Terminal, IDE, web, remote control and mobile can expose different interaction affordances.

**Product implication:** shared state model and consistent semantics across all surfaces.

---

## 2. Product design principles

1. **Five-second comprehension** — a returning user understands system state almost instantly.
2. **One attention inbox** — all approvals/questions/blockers converge.
3. **Conversation is one view, not the product model.**
4. **Context should travel with the mission.**
5. **Artifacts are first-class.**
6. **Preserve typing, scroll position and spatial memory.**
7. **Motion explains state; it does not decorate idle space.**
8. **Progressive disclosure beats dense walls of telemetry.**
9. **Every autonomous action has evidence and provenance.**
10. **Keyboard, mouse and voice are equal accelerators around the same command model.**

---

## 3. Recommended navigation

### Permanent left rail
| Area | Purpose |
|---|---|
| Home | What needs attention + what changed |
| Missions | Work units, tickets, investigations, client requests |
| Sessions | Live/historical Claude/agent sessions |
| Automations | Scheduled/event-driven workflows and run history |
| Artifacts | Reports, specs, diffs, diagrams, client deliverables |
| Knowledge | Memory, linked context, provenance, reusable facts |
| Insights | Performance, reliability, cost, quality, SLA |
| Integrations | Repos, email, calendar, data platforms, observability |

### Global utilities
- Universal command/search (`Cmd/Ctrl+K`)
- Push-to-talk microphone
- Attention/notification center
- Quick create
- User/system/settings

This keeps the permanent navigation stable while each page can use its own contextual subtabs.

---

## 4. Page layouts

### Home — "Command Deck"
**Top:** large, calm "Needs You" strip with no more than 3–5 highest-priority items.

**Middle left:** Active Missions, grouped by Working / Waiting / Blocked.

**Middle right:** Recent Outcomes — completed tasks, artifacts, merged work, client replies.

**Bottom:** upcoming automations, system health and compact trend cards.

The Home screen should be *decision-heavy and telemetry-light*.

### Missions
Split view:
- left: mission list / filters;
- center: mission brief, checklist, current phase;
- right inspector: sessions, artifacts, evidence, dependencies, client inputs.

A mission should become the durable container for work that may span many sessions.

### Sessions
Default view: state-oriented grid or lanes:
- Needs You
- Working
- Reviewing
- Paused
- Done recently

Clicking a session opens the detail workspace without losing the overview.

### Session detail
Three-pane desktop layout:
- collapsible left context/thread nav;
- central conversation + event timeline;
- right inspector for context, files/diff, artifacts, evidence, plan, logs.

### Automations
Two modes:
- visual catalog of automations;
- operational runs view.

Each automation card shows:
trigger, next run, last outcome, affected systems, owner, safety/gate profile.

### Artifacts
Premium gallery/library with:
- type icons/previews;
- mission/session provenance;
- version timeline;
- pin/share/export;
- compare versions.

### Knowledge
Do not default to a giant graph.
Default to search + curated collections + recently used context.
Graph view is a secondary exploration mode.

### Insights
Start with outcomes:
success rate, time-to-green, rework, blocked time, cost per accepted result, human-gate rejection,
agent/team reliability.

### Integrations
Cards for connected systems plus a health/permission surface.
Make failures and credential problems explicit.

---

## 5. Premium feature opportunities people may pay for

### 1. Unified Attention Inbox
All approvals, questions, blockers and failed gates from every session in one place.

### 2. "Since You Were Away"
Instant semantic recap of meaningful changes, not raw transcript.

### 3. Multi-Session Control Room
See 5–50 sessions with true working/waiting/blocked state and intervene without opening each one.

### 4. Cross-Device Approval
Approve/modify/deny from desktop, web or mobile with full adjacent rationale.

### 5. Mission Context Packs
Reusable bundles of repo paths, docs, client context, schemas, constraints and prior decisions.

### 6. Artifact Workspace
Specs, reports, diagrams, diffs and test evidence become versioned, searchable, linked assets.

### 7. Voice Command Layer
Push-to-talk for starting sessions, navigating, asking for summaries and acting on attention items.

### 8. Smart Session Spawn
"Create three investigation sessions using the same context pack, different hypotheses."

### 9. Automation Studio
Turn repeated workflows into scheduled/event-driven routines with safe gates and run history.

### 10. Client Intake → Scoped Mission
Email/meeting/ticket arrives → context assembled → clarifying questions → design artifact → estimate.

### 11. Evidence Mode
Every conclusion can reveal source files, tool calls, tests, links and assumptions.

### 12. Diff + Runtime Preview
Code change, visual change and test/run status visible beside the conversation.

### 13. Personal Command Memory
Frequently used actions become shortcuts/macros without forcing users to remember syntax.

### 14. Reliability & Cost Intelligence
Which agents/sessions/workflows succeed, stall, regress or burn budget.

### 15. Notification Intelligence
Notify only for "needs user", risk threshold, failure, client response or completion—not every event.

### 16. Session Templates / Operating Playbooks
Debug, research, client scope, data-model design, incident response, UI redesign, release.

### 17. Semantic Global Search
Search across messages, files, artifacts, missions, commits and decisions.

### 18. Handoff / Briefing Room
A polished shareable view for a client or teammate that hides internal noise and exposes decisions,
open questions and evidence.

### 19. Safe Batch Actions
Approve a class of low-risk actions across multiple sessions with clear scope and rollback boundaries.

### 20. Adaptive Workspace Layouts
Layout presets for:
- Focus
- Debug
- Research
- Design
- Incident
- Client Review
while preserving consistent navigation and command semantics.

---

## 6. Motion & interaction system

Use a small motion vocabulary.

### State change
Working → Waiting should subtly change icon/state treatment without moving the session card.

### Selection
Selecting a session can smoothly bind the overview card to the detail header/inspector.

### Inspector
Right-side inspector slides/fades in with restrained motion; pinned state persists.

### Success
Completion should feel satisfying but quiet: small check morph, status update, artifact highlight.

### Avoid
- animated gradients behind dense work surfaces;
- constant pulsing;
- cards floating on hover;
- every chart animating on every refresh;
- layout-shifting spring effects.

Always support reduced motion.

---

## 7. Tooltips / extra-information model

Three levels:

1. **Tooltip** — 1–2 line label/definition.
2. **Popover** — compact metadata or quick actions.
3. **Inspector** — deep details, evidence, relationships, configuration.

Rule:
> If the information changes a decision, it should not exist only in a tooltip.

---

## 8. Voice / speech

Voice can be genuinely useful if treated as a command accelerator.

### Good
- "Show sessions waiting for me."
- "Start a session for this mission."
- "Summarize what changed since noon."
- "Open the failed deployment."
- "Read the three highest-priority blockers."

### Risky
Voice-only approvals for consequential actions.

### Recommendation
Push-to-talk first. Wake-word is optional later and off by default.
Every consequential voice action should display its interpreted command before execution.

---

## 9. Naming: retire "Switchboard"

Working shortlist (not trademark-cleared):

| Name | Why it fits | Risk |
|---|---|---|
| **NERVE** | Routes signals + attention across the whole system | Edgy, strong internal codename |
| Relay | Clear routing metaphor | Generic / crowded |
| Atria | Central chambers / hub feeling | Needs brand screen |
| Vector | Direction + execution | Common tech name |
| Lucent | Clarity / premium | Brand collision risk |
| Command | Obvious operator surface | Generic |
| Meridian | Orientation / navigation | Longer |
| Loom | Weaves threads/sessions | Existing product associations |
| Pulse | Live state / health | Very common |
| Conduit | Flow between systems | More industrial |

### Recommendation
Use **NERVE** as the design-program codename:
**CELL OS — NERVE**

Tagline:
> The interface for directing synthetic work.

Before public naming, run a proper trademark/domain/product collision screen.

---

## 10. Research-backed design constraints

### Tooltip behavior
WCAG guidance requires hover/focus content to be dismissible, hoverable and persistent.

### Motion
Respect reduced-motion preferences and remove non-essential motion for users who request it.

### Async status
Do not rely on color alone and do not overload assistive technologies with token-level streaming announcements.
Announce meaningful state changes.

---

## 11. Deep research agenda for the next pass

1. Competitive teardown: Claude Code web/remote, Cursor, Windsurf, Linear, Raycast, GitHub, Vercel, Datadog, Temporal, Prefect.
2. 30–50 Claude Code issue clustering by UX friction.
3. Reddit/community thematic analysis: context, permissions, multi-session, remote, cost, notifications, artifacts.
4. HCI literature on supervisory control and interruption recovery.
5. Information architecture testing for 6/8/10-tab variants.
6. Voice command desirability + privacy study.
7. Motion prototyping with reduced-motion paired variants.
8. Dashboard research on operational decision latency.
9. Accessibility audit for all live/streaming/approval patterns.
10. Pricing/value research: which features create weekly retention.

---

## Sources used in this pass

- Anthropic Claude Code CLI docs: https://docs.anthropic.com/en/docs/claude-code/cli-usage
- Claude Code remote session state issue: https://github.com/anthropics/claude-code/issues/37317
- Claude Code remote permission issue: https://github.com/anthropics/claude-code/issues/90606
- Claude Code focus-stealing issue: https://github.com/anthropics/claude-code/issues/63558
- Claude Code terminal re-render issue: https://github.com/anthropics/claude-code/issues/17529
- Claude Code approval-context issue: https://github.com/anthropics/claude-code/issues/34354
- W3C hover/focus guidance: https://www.w3.org/WAI/WCAG22/Understanding/content-on-hover-or-focus
- W3C reduced-motion technique: https://www.w3.org/WAI/WCAG22/Techniques/css/C39.html
- WCAG 2.2: https://www.w3.org/TR/WCAG22/

## Source skills discovered

See `sources/curated_github_skills.json`.

# Curated GitHub Skill Sources

| Repository | Category | Status | License | Notes |
|---|---|---|---|---|
| [nextlevelbuilder/ui-ux-pro-max-skill](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill) | ui, ux, design-system, accessibility, motion, charts, responsive | core | MIT (verified during research) | Best broad foundation found in this pass; includes UX rules, charts, GSAP presets, product palettes, typography and multi-stack implementation guidance. |
| [szilu/ux-designer-skill](https://github.com/szilu/ux-designer-skill) | ux, research, information-architecture | specialist-candidate | Review before vendoring | UX-designer-oriented skill with a large reference set; useful for research and IA depth. |
| [Nuclear-Marmalade/ux-psychology-skill](https://github.com/Nuclear-Marmalade/ux-psychology-skill) | hci, psychology, behavior | specialist-candidate | Review before vendoring | Behavioral/UX psychology specialization. |
| [gian-lepear/dataviz-design](https://github.com/gian-lepear/dataviz-design) | data-visualization, dashboard, charts | specialist-candidate | Review before vendoring | Data visualization design specialization. |
| [indi256s/dataviz-skill](https://github.com/indi256s/dataviz-skill) | data-visualization, charts | specialist-candidate | Review before vendoring | Compact data-visualization skill candidate. |
| [Ashutos1997/claude-design-auditor-skill](https://github.com/Ashutos1997/claude-design-auditor-skill) | audit, accessibility, quality-control | specialist-candidate | Review before vendoring | Design review/audit skill; useful as a critic rather than a generator. |
| [plugin87/ux-ui-agent-skills](https://github.com/plugin87/ux-ui-agent-skills) | ui, ux, accessibility | specialist-candidate | Review before vendoring | Multi-skill UI/UX candidate discovered through accessibility search. |
| [plugin87/full-stack-design-skills](https://github.com/plugin87/full-stack-design-skills) | product-design, ui, implementation | specialist-candidate | Review before vendoring | Full-stack design skill candidate. |
| [dickwu/apple-design-skill](https://github.com/dickwu/apple-design-skill) | premium-aesthetic, native, interaction | inspiration-candidate | Review before vendoring | Apple-oriented design skill useful for restraint, hierarchy and premium interaction references. |
| [southleft/figma-console-mcp-skills](https://github.com/southleft/figma-console-mcp-skills) | figma, design-tooling, workflow | tooling-candidate | Review before vendoring | Figma console/MCP workflow skills. |
| [get-zeked/pm-super-skill](https://github.com/get-zeked/pm-super-skill) | product-management, prioritization, requirements | specialist-candidate | Review before vendoring | Product-management-oriented super-skill candidate. |
| [PyModel/designer-skill](https://github.com/PyModel/designer-skill) | design, creative | specialist-candidate | Review before vendoring | General designer skill candidate. |
| [palamut62/ui-design-skills-pack](https://github.com/palamut62/ui-design-skills-pack) | ui, design-system | specialist-candidate | Review before vendoring | UI design skill-pack candidate. |
| [rh-uxd/ai-helpers](https://github.com/rh-uxd/ai-helpers) | ux, ai-workflow, research | workflow-candidate | Review before vendoring | AI helpers from a UX-oriented organization. |
| [xenon1919/Claude-Agent-Skills-for-Power-BI-Business-Intelligence](https://github.com/xenon1919/Claude-Agent-Skills-for-Power-BI-Business-Intelligence) | dashboard, business-intelligence, data-product | domain-candidate | Review before vendoring | BI-specific agent skills; useful as a domain reference for analytical surfaces. |

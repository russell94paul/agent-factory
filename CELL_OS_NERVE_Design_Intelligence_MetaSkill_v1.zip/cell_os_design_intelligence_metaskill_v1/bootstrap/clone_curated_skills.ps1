param(
  [string]$Destination = "vendor-skills"
)

New-Item -ItemType Directory -Force -Path $Destination | Out-Null

$repos = @(
  "https://github.com/nextlevelbuilder/ui-ux-pro-max-skill.git",
  "https://github.com/szilu/ux-designer-skill.git",
  "https://github.com/Nuclear-Marmalade/ux-psychology-skill.git",
  "https://github.com/gian-lepear/dataviz-design.git",
  "https://github.com/indi256s/dataviz-skill.git",
  "https://github.com/Ashutos1997/claude-design-auditor-skill.git",
  "https://github.com/plugin87/ux-ui-agent-skills.git",
  "https://github.com/plugin87/full-stack-design-skills.git",
  "https://github.com/dickwu/apple-design-skill.git",
  "https://github.com/southleft/figma-console-mcp-skills.git",
  "https://github.com/get-zeked/pm-super-skill.git",
  "https://github.com/PyModel/designer-skill.git",
  "https://github.com/palamut62/ui-design-skills-pack.git",
  "https://github.com/rh-uxd/ai-helpers.git",
  "https://github.com/xenon1919/Claude-Agent-Skills-for-Power-BI-Business-Intelligence.git"
)

foreach ($repo in $repos) {
  $name = [System.IO.Path]::GetFileNameWithoutExtension($repo)
  $path = Join-Path $Destination $name
  if (Test-Path (Join-Path $path ".git")) {
    Write-Host "Updating $name"
    git -C $path pull --ff-only
  } else {
    Write-Host "Cloning $name"
    git clone --depth 1 $repo $path
  }
}

Write-Host ""
Write-Host "Done. Review each repository's LICENSE before redistributing or merging its content."

# Prompt for Claude Design / Claude Code

You are the principal product designer, HCI researcher and design-systems architect for **CELL OS — NERVE**,
the working replacement for the old "Switchboard" console.

First read:
1. `SKILL.md`
2. `DEEP_RESEARCH_REPORT.md`
3. every file in `references/`
4. `sources/curated_github_skills.json`

If a `vendor-skills/` directory exists, inspect relevant third-party skills as *evidence and inspiration*,
not as authority. Resolve contradictions using user goals, accessibility, HCI fundamentals and observed
workflow friction.

## Objective

Produce a design research + product specification for a premium AI supervisory console that feels:
- elegant;
- fast;
- calm;
- seamless;
- powerful;
- highly navigable;
- satisfying under heavy daily use.

It must not be a generic chat UI or a generic dashboard.

## Required research outputs

### A. Friction analysis
Identify and rank at least 25 frictions in AI coding / Claude Code workflows.
For each:
- user situation;
- trigger;
- cognitive/operational cost;
- current workaround;
- design opportunity;
- severity;
- frequency;
- evidence source.

### B. Information architecture tournament
Design at least 4 materially different navigation architectures.
For each:
- primary rail;
- contextual navigation;
- command/search model;
- mobile adaptation;
- advantages;
- failure modes;
- best user type.

Then select a winner with explicit reasoning.

### C. Page designs
Fully specify:
- Home
- Missions
- Sessions
- Session Detail
- Automations
- Artifacts
- Knowledge
- Insights
- Integrations

For every page include:
- primary user job;
- top actions;
- layout zones;
- empty state;
- loading state;
- error state;
- blocked/waiting state;
- keyboard behavior;
- responsive behavior;
- inspector/tooltips;
- animation;
- accessibility.

### D. Premium product feature portfolio
Generate 30 candidate paid features.
Score each by:
- pain severity;
- weekly frequency;
- differentiation;
- retention;
- trust benefit;
- complexity.

Select the top 12.

### E. Interaction system
Specify:
- command palette;
- push-to-talk;
- attention inbox;
- notifications;
- approvals;
- cross-session actions;
- search;
- drag/drop only where justified;
- keyboard shortcuts;
- undo/redo;
- state transitions.

### F. Visual system
Create 3 premium directions:
1. restrained executive;
2. technical cinematic;
3. warm intelligent.

Each needs typography, spacing, density, shape language, elevation, iconography, color strategy,
dark/light behavior, motion behavior and anti-patterns.

Do not default to neon cyberpunk.

### G. Dashboard/data-viz system
Create chart-selection rules and examples for:
- agent/team success;
- cost;
- time-to-green;
- blocked time;
- automation reliability;
- mission throughput;
- human-gate rejection;
- SLA;
- knowledge freshness.

### H. Tooltip/progressive disclosure system
Define tooltip vs popover vs inspector vs modal rules.

### I. Voice
Design push-to-talk and optional wake-phrase behavior, with privacy and confirmation boundaries.

### J. Prototype specification
End with a component-level spec suitable for implementation:
- shell;
- nav rail;
- top bar;
- command palette;
- attention drawer;
- session card;
- mission card;
- inspector;
- timeline;
- approval card;
- diff viewer;
- artifact preview;
- chart container;
- toast;
- modal;
- voice overlay.

## Design quality bar

The experience should feel premium because it reduces cognitive work, not because it has more effects.

Reject any design that:
- hides blocked states behind spinners;
- relies on color alone;
- steals typing focus;
- shifts list position unnecessarily;
- hides critical context inside hover-only UI;
- cannot be navigated quickly by keyboard;
- overloads the permanent sidebar;
- uses motion without meaning;
- looks impressive in a screenshot but slows daily operation.

## Final deliverable

Produce:
1. Executive design thesis
2. Evidence-backed friction report
3. IA tournament
4. Selected architecture
5. Page-by-page wireframe descriptions
6. Component inventory
7. Interaction + motion spec
8. Accessibility spec
9. Feature roadmap
10. Prototype build plan
11. Open questions / experiments
12. A "delete these bad ideas" section

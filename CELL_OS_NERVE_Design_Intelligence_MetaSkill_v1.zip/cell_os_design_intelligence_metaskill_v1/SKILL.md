---
name: cell-os-design-intelligence
description: >
  Meta-skill for premium product design, UI/UX, HCI, information architecture,
  analytical dashboards, interaction/motion, tooltip/progressive disclosure,
  accessibility, AI coding workspaces, voice interaction and product desirability.
  Use for CELL OS / agent-console design and for any complex multi-surface SaaS.
---

# CELL OS Design Intelligence — Skill of Skills

## Mission

Design interfaces that feel obvious, fast, calm, premium and trustworthy while handling
dense agentic state, many concurrent sessions, approvals, artifacts, automations and data.

Do not optimize for "looks futuristic" alone. Optimize in this order:

1. **Legibility of state**
2. **Attention routing**
3. **Task completion speed**
4. **Error prevention + reversibility**
5. **Information architecture**
6. **Accessibility**
7. **Interaction quality**
8. **Visual hierarchy**
9. **Motion polish**
10. **Novelty**

## Required operating rule

Before proposing a visual redesign, identify:
- the user's primary job-to-be-done;
- the highest-frequency actions;
- the highest-cost interruptions;
- what can block progress;
- what state the user must understand at a glance;
- what deserves persistent navigation versus contextual navigation;
- what information can be progressively disclosed.

## Router

Load the smallest relevant set of references:

| Problem | Load |
|---|---|
| Navigation, sidebars, page hierarchy | `references/01_INFORMATION_ARCHITECTURE.md` |
| Human factors, cognitive load, HCI | `references/02_HCI_AND_HUMAN_FACTORS.md` |
| Premium visual feel | `references/03_PREMIUM_AESTHETIC_SYSTEM.md` |
| Agent/Claude-style workspace | `references/04_AI_CONSOLE_WORKSPACE.md` |
| Dashboards and operational views | `references/05_DASHBOARD_DESIGN.md` |
| Chart selection / analytical interaction | `references/06_CHARTS_AND_DATAVIZ.md` |
| Motion, micro-interactions, transitions | `references/07_MOTION_SYSTEM.md` |
| Tooltips / hover details / progressive disclosure | `references/08_TOOLTIPS_AND_DISCLOSURE.md` |
| Accessibility / keyboard / reduced motion | `references/09_ACCESSIBILITY.md` |
| Voice / speech commands | `references/10_VOICE_AND_COMMANDS.md` |
| Feature prioritization / subscription value | `references/11_PRODUCT_VALUE.md` |

## Design doctrine

### A. Attention > Activity
Never show a wall of "things happening" if the user really needs to know only:
- what needs me now;
- what is blocked;
- what is at risk;
- what finished;
- what changed.

### B. State must be glanceable
Any active session/task should expose a semantic state:
- Working
- Waiting for user
- Blocked
- Reviewing
- Paused
- Done
- Failed

Do not rely on color alone. Pair iconography + text + shape/position.

### C. Preserve spatial memory
Avoid rearranging navigation or live cards aggressively.
Do not steal focus.
Do not move the user's scroll position without intent.
Do not destroy typed input when a system event arrives.

### D. Progressive disclosure
Primary surfaces should show decisions and outcomes.
Details such as logs, tool calls, provenance, reasoning, tokens and raw traces belong behind:
- an inspector panel;
- expandable rows;
- hover/focus summaries;
- "show evidence" actions.

### E. Motion must communicate causality
Animate:
- origin → destination;
- state change;
- hierarchy;
- success/failure;
- reordering the user intentionally caused.

Do not animate merely to signal "premium."

### F. Every autonomous action has a trust surface
For risky or consequential actions, show:
- what will happen;
- why;
- scope;
- affected resources;
- reversible/irreversible;
- approve / modify / deny;
- evidence immediately adjacent.

## CELL OS canonical navigation direction

Default left rail:
1. Home
2. Missions
3. Sessions
4. Automations
5. Artifacts
6. Knowledge
7. Insights
8. Integrations

Global utilities:
- Search / Command Palette
- Voice / Push-to-talk
- Notifications / Attention Inbox
- Settings / Profile

Use contextual secondary navigation inside pages rather than adding more permanent rail items.

## Quality gate

A design is not ready until it passes:
- five-second state comprehension;
- keyboard-only navigation;
- reduced-motion mode;
- 200% zoom/reflow check;
- empty/loading/error/offline/blocked states;
- one-hand/compact pointer targets where relevant;
- permission/approval context check;
- no destructive focus stealing;
- no critical information available only on hover;
- consistent back/escape behavior;
- clear "what changed?" affordance after autonomous work.

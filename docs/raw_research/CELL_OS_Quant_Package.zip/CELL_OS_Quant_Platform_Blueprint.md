# CELL//OS × Futures Quant — Platform Blueprint, Simulations, Gap Analysis & Prop-Firm Deep-Dive

*Prepared 3 Sep 2026. All simulation figures are outputs of `crucible_propsim.py` (shipped alongside) using a synthetic strategy whose statistics are stated explicitly. Replace those statistics with your own strategy's fill-level data and re-run — that is precisely the Crucible workflow.*

---

## 1. Ten platform names

| # | Name | Why it works | Collision risk* |
|---|------|-------------|-----------------|
| 1 | **QUANTA//OS** | Sister-brand to CELL//OS; "quanta" = discrete units of edge | Medium (generic word) |
| 2 | **VANTAGE PRIME** | Institutional, "prime brokerage" connotation, dominance | Medium |
| 3 | **ALPHAFORGE** | Alpha is manufactured, not found; matches the Evolution Loop | Medium-high (used in gaming/dev) |
| 4 | **MERIDIAN LABS** | Precision, reference lines, research-house feel | Medium |
| 5 | **KALMAN** | Named for the filter every quant knows; one-word, hard, cold | Low-medium (eponym) |
| 6 | **SIGNAL//STATE** | Signals + state-space + your `//` house style | Low |
| 7 | **CONVEXITY** | Positive convexity is the whole game in prop firms | Medium |
| 8 | **ORTHOGON** | Orthogonal alpha, uncorrelated by design | Low |
| 9 | **APEXIS** | Sounds like a premium terminal; avoid if you plan to trade at Apex Trader Funding (conflict) | High (near-Apex) |
| 10 | **TENSORDESK** | Multi-model, multi-account "desk" run by AI Operatives | Low-medium |

*Trademark/domain collision must be checked before use. Recommendation: **SIGNAL//STATE** or **ORTHOGON** for the product; **KALMAN** if you want a one-word brand.*

---

## 2. Component tool names (the suite)

Every component is a named module in the Futures Quant **Domain Pane** of CELL//OS. Names are internal product names; each maps to a CELL//OS layer, is owned by one Operative type, and emits events onto the bus.

### 2.1 Data & Memory Layer (Layer 5)
| Component | What it is | Backing tech |
|---|---|---|
| **TAPE** | Raw market-data lake: MBO/MBP-10, trades, quotes, settlement, OI (Databento/dxFeed/Rithmic feed) | Iceberg + Parquet, partitioned `product/date/session` |
| **BARSMITH** | Bar factory: time, tick, volume, dollar, imbalance/run bars, session-aware | Polars/Arrow, DuckDB for research |
| **ROLLKEEPER** | Roll calendars, continuous-contract builders (back-adj, ratio-adj, Panama), OI-based roll detection | Postgres + Python service |
| **CALENDAR** | Sessions, holidays, maintenance windows, economic-event timestamps *with revisions* | Postgres (point-in-time tables) |
| **SPECBOOK** | Contract specs, tick value, margins (with history), fee schedules, symbol maps across vendors | Postgres + versioning |
| **FEATUREVAULT** | Feature store; offline (Parquet) + online (Redis); point-in-time joins enforced | Feast or Hopsworks |
| **LEDGER** | Every fill, order, reject, latency, queue-position estimate — your own exhaust | TimescaleDB |
| **LINEAGE** | Hypothesis → feature → model → backtest → deployment graph | Neo4j (your Org Graph DB) |
| **RECALL** | Research memory for Operatives: post-mortems, regime notes, prior experiments | Vector DB + document store |

### 2.2 Research & Cognitive Core (Layer 3)
| Component | What it is |
|---|---|
| **HYPOTHESIS REGISTRY** | Pre-registered ideas with edge source, expected decay, capacity, kill criteria, and a **backtest budget** |
| **LABELER** | Triple-barrier, trend-scanning, fixed-horizon, meta-labels |
| **FEATUREWORKS** | Hand-crafted microstructure/order-flow features + genetic-programming synthesis (the BLACKBOX feature miner) |
| **RANKER** | Feature & signal ranking: IC/ICIR, MI, clustered MDA, stability selection across folds/regimes |
| **FOLDER** | Purged K-fold w/ embargo, CPCV, walk-forward (anchored/rolling), nested CV — the only CV allowed in the platform |
| **TRAINYARD** | Model training: LightGBM/XGBoost/CatBoost, TFT/PatchTST, HMM regimes; Optuna/Ray Tune with budget accounting |
| **REGIMEWATCH** | HMM / clustering on vol-trend-liquidity → regime state published to bus |
| **MODELGATE** | Model registry + promotion states (incubating → paper → shadow → live → probation → retired) — MLflow |

### 2.3 Crucible — Evaluation & Simulation (Layer 3 Evaluation Engine + BLACKBOX)
| Component | What it is |
|---|---|
| **REPLAY** | Event-driven backtester with L2 replay, queue-position, latency, partial fills, rolls, fees (NautilusTrader or hftbacktest core) |
| **PROPSIM** | Prop-rule survival Monte Carlo: trailing DD (EOD/intraday/static), DLL, consistency, payout schedule, eval fees — *what produced the charts below* |
| **DEFLATOR** | Deflated Sharpe, PBO, SPA/Reality Check, multiple-testing correction against the backtest budget |
| **STRESSLAB** | Regime-conditional bootstrap, synthetic order-flow, historical crisis replays, exchange-outage drills |
| **PARETO** | NSGA-II/III multi-objective search: return, DD, turnover, capacity, tail, distance-to-breach |
| **ARENA** | Strategy tournament: Elo/TrueSkill ratings, survival analysis, elimination brackets ("only the strong get promoted") |

### 2.4 Execution & Risk (Layer 4 Tool Execution + Layer 7 Policy Engine)
| Component | What it is |
|---|---|
| **DISPATCH** | Order router to Rithmic/CQG/Tradovate/ProjectX/IBKR; FIX where available; OCO/bracket native |
| **WARDEN** | Prop-rule enforcement engine: hard pre-trade checks per account (DLL, trailing floor, max contracts, news blackout, consistency) — **fails closed** |
| **MIRROR** | Compliant internal multi-account replicator (proportional sizing, ≤100 ms, own-accounts only) |
| **KILLSWITCH** | Global and per-account flatten; triggered by WARDEN, degradation monitors, or humans |
| **ALLOCATOR** | Capital & signal weighting: HRP + EW-Sharpe softmax with floors, correlation caps, kill-and-revive |
| **RECON** | Fill/position reconciliation vs broker statements every session |

### 2.5 Observability & Evolution (Layer 1, 6, 7)
| Component | What it is |
|---|---|
| **PULSE** | Strategy & portfolio health: rolling Sharpe CUSUM, DD vs MC envelope, slippage drift, PSI feature drift |
| **DISTANCE** | Real-time distance-to-breach dashboard per account (the single most important number in prop trading) |
| **JUDGE** | Operative evals: hallucination checks, tool-error rates, reasoning-trace anomalies, cost creep |
| **POSTMORTEM** | Auto-generated trade/strategy/agent post-mortems written to RECALL |
| **EVOLVE** | Mutation engine: parameter/feature/model mutations under Deflator budget; feeds ARENA |

---

## 3. Architecture diagrams

### 3.1 Domain Pane over CELL//OS layers
```mermaid
flowchart LR
  subgraph L1[Experience]
    MC[Mission Control] --- DIST[DISTANCE dashboard] --- PULSE
  end
  subgraph L2[Interface]
    GW[API Gateway] --- CONN[Connectors: Databento • Rithmic • Tradovate • ProjectX • CQG]
  end
  subgraph L3[Cognitive Core]
    HYP[Hypothesis Registry] --> FW[FEATUREWORKS] --> RK[RANKER] --> TY[TRAINYARD]
    TY --> CR{{CRUCIBLE: REPLAY • PROPSIM • DEFLATOR • PARETO • ARENA}}
    CR --> MG[MODELGATE]
    EV[EVOLVE] --> HYP
  end
  subgraph L4[Coordination]
    WARDEN --> DISPATCH --> MIRROR
    ALLOCATOR --> WARDEN
  end
  subgraph L5[Memory & Data]
    TAPE --> BARSMITH --> FEATUREVAULT
    ROLLKEEPER --> BARSMITH
    LEDGER --> POSTMORTEM --> RECALL
    LINEAGE
  end
  subgraph L6[Events]
    BUS[(Kafka/NATS: md.*, signal.*, order.*, fill.*, risk.*, agent.*)]
  end
  FEATUREVAULT --> TY
  MG --> ALLOCATOR
  DISPATCH --> LEDGER
  BUS -.-> L1 & L3 & L4 & L5
```

### 3.2 The strategy lifecycle (Evolution Loop, quant edition)
```
 MISSION            EXECUTE              EVIDENCE               EVALUATE                 LEARN            MUTATE / PROMOTE
 ┌──────────┐   ┌──────────────┐   ┌──────────────────┐   ┌────────────────────┐   ┌────────────┐   ┌─────────────────────┐
 │Hypothesis│ → │Features/labels│ → │Purged-CV backtest│ → │DEFLATOR (DSR,PBO)  │ → │POSTMORTEM  │ → │EVOLVE → ARENA       │
 │+ budget  │   │TRAINYARD      │   │REPLAY (L2)       │   │PROPSIM survival    │   │RECALL      │   │incubate→paper→shadow│
 │+ kill crit│  │               │   │STRESSLAB         │   │PARETO front pick   │   │RANKER upd. │   │→live→probation→retire│
 └──────────┘   └──────────────┘   └──────────────────┘   └────────────────────┘   └────────────┘   └─────────────────────┘
        ▲                                                                                                       │
        └────────────────────────────── budget decremented per backtest; exceeded ⇒ hypothesis closed ──────────┘
```

### 3.3 Operative mesh (recommended topology)
```
                         ┌─────────────────────┐
                         │  HUMAN  (you)        │  approves: promotions, size changes, new firms
                         └──────────┬──────────┘
                                    │
                         ┌──────────▼──────────┐
                         │  CIO Operative       │  owns ALLOCATOR; cannot place orders
                         └───┬──────────┬──────┘
          ┌──────────────────┘          └──────────────────┐
 ┌────────▼─────────┐                            ┌─────────▼──────────┐
 │ RESEARCH CELL    │  information barrier ▌▌▌   │ EVALUATION CELL     │
 │ Hypothesis Gen.  │  (cannot see holdout)      │ Backtest Engineer   │
 │ Feature Scientist│                            │ Red-Team Reviewer   │
 │ Model Developer  │                            │ Deflator/Statistics │
 └──────────────────┘                            └─────────────────────┘
          ┌───────────────────────────┬───────────────────────────┐
 ┌────────▼─────────┐      ┌──────────▼─────────┐      ┌──────────▼─────────┐
 │ EXECUTION CELL   │      │ RISK CELL          │      │ OPS CELL           │
 │ Execution Trader │◄─veto│ Prop-Rule WARDEN   │      │ Data Steward       │
 │ (deterministic)  │      │ Risk Officer       │      │ SRE / Recon        │
 └──────────────────┘      └────────────────────┘      └────────────────────┘
 Reliability rules: adversarial pair (Research vs Evaluation) • WARDEN has veto over Execution •
 no LLM in the order path • CIO cannot trade • every promotion needs Evaluation + Risk + Human sign-off
```

---

## 4. Simulation results — how the Crucible is actually used

**Synthetic strategy used throughout** (replace with yours): intraday ES/MES, 3 trades/day, win rate 44%, avg win ≈1.75R (lognormal, right-skewed), loss 1R with a 10% chance of a 2R slippage/gap loss, R = 3 pts, fees $1/MES round-trip. Expectancy ≈ $1.3/trade/MES, annualized Sharpe ≈ 1.7. Account: $50K, $2,000 EOD-trailing drawdown, $1,000 daily loss limit, $3,000 eval target, 60-day eval window; funded stage pays 50% of profit above a $500 buffer every 10 trading days, drawdown floor locks at starting balance once earned. 4,000–6,000 paths per cell.

### 4.1 Sizing is the whole game (`sim1_sizing_sweep.png`)
| MES contracts | P(pass eval ≤60d) | P(breach in eval) | Median days to pass | P(funded survives 120d) | E[6-mo payout] | Expected funded lifetime |
|---|---|---|---|---|---|---|
| 2 | 0% | 0% | — | 99.8% | $279 | 120d (cap) |
| 4 | 7.6% | 4.2% | 47 | 78.8% | $1,216 | 111d |
| 6 | 29.7% | 19.7% | 41 | 40.8% | $1,962 | 88d |
| 8 | 43.2% | 38.5% | 33 | 19.7% | $2,196 | 65d |
| 10 | 47.0% | 48.2% | 25 | 10.2% | $2,334 | 50d |
| 15 | 42.4% | 57.5% | 13 | 2.6% | $2,172 | 28d |
| 20 | 34.7% | 65.3% | 7 | 0.1% | $1,129 | 12d |

**Findings**
- A Sharpe-1.7 strategy — better than most retail bots — passes a $50K eval less than half the time at *any* size. Prop evals are a survival game; treat P(pass) as a strategy metric, not an afterthought.
- P(pass) peaks at ~10 MES; P(survive funded) collapses above 4–6 MES. **The eval-optimal size and the funded-optimal size are different.** (See 4.5.)
- CVaR5 of payout is $0 everywhere: 1 in 20 accounts pays nothing regardless of size. Plan capital as a portfolio of accounts, never one.
- First run of this sim used 1–8 *full* ES contracts at 3 trades/day: every account died within 1–4 days. That is exactly how most retail prop accounts fail — sizing, not edge.

### 4.2 Edge sensitivity × drawdown model (`sim2_dd_model_edge.png`)
| Win rate (same payoff shape) | P(pass) EOD trailing | P(pass) intraday trailing |
|---|---|---|
| 40% | 15.0% | 14.2% |
| 42% | 27.6% | 26.3% |
| 44% | 45.0% | 43.6% |
| 46% | 61.8% | 60.8% |

**Findings:** two percentage points of win rate ≈ doubles P(pass). Intraday trailing costs only ~1 pt here because trades are short-held; for swing strategies with large open-PnL excursions the gap is much larger — pick static/EOD-drawdown firms for swing books.

### 4.3 Scaling across accounts (`sim3_multi_account.png`)
8 MES per account, 120 days, Gaussian-copula correlation ρ between accounts' daily PnL.

| ρ (account correlation) | N | E[total payout] | SD | CVaR5 | P(all accounts dead by d120) |
|---|---|---|---|---|---|
| 0.95 (one strategy copied) | 1 / 3 / 5 / 10 | $2.2K / $6.7K / $12.2K / $24.2K | $2.5K / $7.0K / $12.3K / $24.0K | $0 / $0 / $0 / $0 | 79% / 67% / 60% / 54% |
| 0.5 (mixed book) | 1 / 3 / 5 / 10 | $2.4K / $6.9K / $11.6K / $23.3K | $2.6K / $6.0K / $9.1K / $17.0K | $0 / $0 / $48 / $570 | 76% / 53% / 41% / 25% |
| 0.2 (diversified strategies) | 1 / 3 / 5 / 10 | $2.5K / $7.0K / $12.3K / $23.3K | $2.6K / $4.9K / $7.3K / $12.2K | $0 / $12 / $845 / $3.5K | 75% / 48% / 30% / 15% |

**Findings**
- Copying one strategy to 10 accounts multiplies expected payout **and multiplies variance one-for-one** (SD ≈ mean). It is leverage, not diversification. Every account dies in the same week.
- Ten accounts running low-correlation strategies have half the SD, a positive CVaR, and P(total wipe-out) of 15% vs 54%.
- The real "diversification across accounts" is **diversification across strategies and firms**; accounts are just containers.

### 4.4 Why the backtest budget exists (`sim4_overfitting.png`)
Best 2-year annualized Sharpe among N strategies with **zero** true edge: N=10 → 1.83; N=200 → 1.99; N=1000 → 2.59; N=5000 → 2.43 (sampling noise). Theoretical E[max] ≈ √(2 ln N) scaled: 1.5 / 2.3 / 2.6 / 2.9. A parameter grid of 200 cells reliably produces a "Sharpe 2" that is pure noise. DEFLATOR must deflate every reported Sharpe by the number of trials charged to the hypothesis.

### 4.5 Two-regime sizing (`sim7_two_regime_sizing.png`)
E[6-mo payout] − expected eval cost ($150 fee, $100 resets until passed):

| Eval size → Funded size | P(pass) | P(survive 120d) | E[payout] | Net EV per funded account |
|---|---|---|---|---|
| 8 → 3 MES | 44% | 95% | $738 | $464 |
| 8 → 4 MES | 44% | 80% | $1,231 | $956 |
| 8 → 6 MES | 44% | 42% | $1,962 | $1,688 |
| 8 → 8 MES | 44% | 19% | $2,231 | $1,956 |
| 10 → 4 MES | 48% | 80% | $1,210 | $951 |

**Findings:** under a 6-month horizon and a harvest-50%-every-10-days payout schedule, the sim says "size up in the eval, and keep sizing fairly aggressively when funded" — because payouts are harvested before the account dies. That is the well-known prop-firm "harvest" dynamic and it is *rational only if* (a) you treat accounts as disposable, (b) the firm's lifetime payout cap (Apex-style ~$13–14.5K per account per the rules verified today) is below what a long-lived account would produce, and (c) you can re-pass evals cheaply. If instead you want a **track record** to move to live capital or institutional allocation, run funded at 3–4 MES (80–95% survival) and accept lower harvest. Make this an explicit CIO-Operative objective switch: `objective = harvest | longevity`.

### 4.6 Dynamic signal weighting (`sim5_dynamic_weighting.png`)
Four strategies, regime shift at day 250 (two strategies go from best to worst). Equal weight: Sharpe 0.50, total +7.7%. EW-Sharpe softmax allocator (λ=0.93, 30% equal-weight floor): Sharpe 0.72, total +11.9%. Validate allocators with the same purged-CV discipline as strategies — an allocator is a model.

### 4.7 Funded equity fan (`sim6_equity_fan.png`)
Survivors-only median path drifts up ~$60/day at 8 MES; the 5th percentile hugs the locked floor for the first 40 days — that region is where DISTANCE must cut size automatically.

### 4.8 Stage-gate metric table (what PULSE/DEFLATOR enforce)
| Stage | Metrics | Gate | Owner |
|---|---|---|---|
| Hypothesis | edge source, capacity, decay, budget | registered + budget ≤ 50 trials | Research Cell |
| Features | IC/ICIR, MI, stability across folds & regimes | ICIR > 0.3, stable in ≥ 70% of folds | RANKER |
| Backtest | DSR, PBO, Sharpe, Calmar, DD duration, turnover, fee sensitivity | DSR > 0.95, PBO < 0.2, survives 2× fees | Evaluation Cell |
| PROPSIM | P(pass), P(survive 120d), E[payout], CVaR5, distance-to-breach | P(pass) ≥ 40%, P(survive) ≥ 70% at chosen size | Risk Cell |
| Paper / shadow | live-vs-backtest tracking error, slippage attribution | ≥ 30 sessions, slippage ≤ 1.5× modeled | Execution Cell |
| Live probation | rolling-20d Sharpe CUSUM, PSI drift, DISTANCE | no CUSUM alarm, DISTANCE > 30% | PULSE |
| Retire | Sharpe CUSUM alarm ×2, or PSI > 0.25 on top-3 features | auto de-risk → quarantine → human | CIO |

---

## 5. Second-pass gap analysis — critical features you are missing

Ranked by how badly their absence hurts a live quant desk.

1. **Prop-rule enforcement as a fail-closed pre-trade gate (WARDEN).** Nothing in the current architecture stops an Operative from placing a trade that breaches a trailing floor. It must be a deterministic service in the order path, not a policy the LLM reads.
2. **Distance-to-breach as a first-class metric (DISTANCE).** Every size decision, allocator weight, and alert should be conditioned on it. It doesn't exist in the diagram.
3. **A backtest budget + Deflated-Sharpe gate (DEFLATOR).** Evaluation Engine "score & validate" is not enough — without multiple-testing accounting the Evolution Engine becomes an overfitting machine (see 4.4).
4. **Information barrier between hypothesis generation and evaluation.** Research Operatives must not see holdout data or Crucible results in detail; otherwise they learn to game the gate. Enforce it with Identity & Access, not prompting.
5. **Point-in-time correctness in the data layer.** Snowflake/Iceberg/Timescale are fine, but you need bitemporal tables for anything revised (economic data, margins, specs) and PIT joins in the feature store. Lookahead leaks are the #1 silent killer.
6. **Roll & continuous-contract service (ROLLKEEPER).** Futures-specific; every backtest is wrong without it.
7. **Own-execution exhaust as a dataset (LEDGER → slippage model).** Backtests should use *your* measured slippage distribution, not assumptions.
8. **Deterministic execution path with no LLM in it.** Operatives decide *what* strategy runs and at *what* size; a compiled strategy runs the orders. LLM latency and non-determinism are disqualifying in the order path, and firms ban sub-second/latency strategies anyway.
9. **Two-regime sizing objective in the CIO Operative** (`harvest` vs `longevity`) — see 4.5.
10. **Account-portfolio model.** Accounts are containers; the allocator must optimize across (strategy × account × firm) with correlation caps, firm counterparty exposure caps, and payout-schedule awareness.
11. **Compliance ledger.** Store per-firm rules (versioned, dated), the evidence you read them, and a trade-by-trade compliance check output. Rules change monthly and the CFTC is examining whether evaluation-based prop firms should be treated as CTAs — an open question, not settled law; keep a clean paper trail.
12. **Replay-based agent evaluation.** JUDGE should replay historical sessions to Operatives and score decisions against outcomes — the Crucible for agents, not just strategies.
13. **Degradation → action ladder.** Alerts exist; automatic actions (size −50% → pause → quarantine → flatten) do not.
14. **Secrets & credential isolation per account.** Broker credentials per account in the Secrets Manager with scoped tool permissions; an Operative for account A must be unable to touch account B.
15. **Cost telemetry per hypothesis.** LLM + compute cost per unit of validated alpha; the Evolution Engine should be FinOps-aware or it will spend $10K to discover noise.

Suggested changes to the existing diagram: add a **Risk & Compliance** row to the Coordination layer (WARDEN, DISTANCE, KILLSWITCH, Compliance Ledger); split Evaluation Engine into **Evaluate (statistics)** and **Simulate (PROPSIM/STRESSLAB)**; add a **Backtest Budget** counter to the Hypothesis object; make the Domain Pane own its schemas in Layer 5.

---

## 6. Deep-dive: connecting quant models to retail prop firms and scaling capital

### 6.1 The regulatory & rulebook reality (verified 3 Sep 2026)
- Copying trades across accounts you personally own is permitted at nearly every major futures prop firm; copying others' trades or selling signals is prohibited nearly everywhere. Ownership settles most questions.
- Most major futures prop firms allow automated trading — fully automated, semi-automated, or copy trading across your own funded accounts; firms running on Tradovate, Rithmic, and ProjectX include Apex, Topstep, Alpha Futures, Take Profit Trader, FundedNext Futures, MyFundedFutures, TradeDay, and Tradeify — but rules on HFT, arbitrage, and consistency vary and change. **Verify per firm, per account type, in writing, before going live.** Note the conflicting reporting: one source states Apex prohibits fully automated bots on funded accounts while allowing copying of your own accounts — treat "automation allowed" as "semi-automated with a human on the leader account" until the firm confirms otherwise in writing.
- Nearly universally banned: sub-second/HFT, tick/latency/feed arbitrage, grid/martingale, cross-account hedging, inconsistent sizing across copied accounts.
- Account caps: Apex ~20 concurrent accounts, Topstep ~5; consistency caps (e.g., 50% single-day share of profits at some firms) delay payouts rather than kill accounts.
- Topstep example rule structure: three rules end the account instantly (trailing max drawdown, daily loss limit, max contracts); the rest only delay payouts. The trailing floor rises with end-of-day highs and never falls; a good week can put you *closer* to breach.
- Apex moved (Mar 2026) to EOD and intraday trailing-drawdown account types, with a six-payout ladder and ~$13–14.5K lifetime payout potential per account. Firm choice therefore determines whether "longevity" is even worth optimizing.

### 6.2 Step-by-step connection walkthrough

**Step 0 — Pick firms by drawdown model, not by marketing.** Intraday strategies with tight stops: EOD or intraday trailing both work. Swing/overnight: static or EOD only. Prefer firms with native group/copy tools (Tradovate group trading, TopstepX) — fewer moving parts.

**Step 1 — Build the compliance ledger first.** For each firm: drawdown type, DLL, max contracts (per stage), consistency rule, news-trading rule, automation policy (quoted text + date), account cap, payout schedule, lifetime cap, activation/reset fees. Store in SPECBOOK with a version and a "verified on" date. WARDEN reads from here only.

**Step 2 — Compile the strategy.** The Operatives produce a *strategy specification* (signals, sizing function, stops, session filter, regime gating). Compile it to a deterministic runtime (NautilusTrader strategy class, NinjaScript, or a Python service behind your own execution gateway). No LLM calls in the loop. Latency target for order handling < 100 ms end-to-end so copies stay within firms' tolerance.

**Step 3 — Connectivity.**
- Tradovate (REST/WebSocket) — cleanest API; used by many firms; group trading built in.
- Rithmic (R|API+) — lowest latency, C++/Python SDK, NinjaTrader-based firms.
- ProjectX (TopstepX and other white-labels) — REST/WebSocket gateway API.
- Bridges: PickMyTrade / TradersPost / Tradesyncer-style bridges accept webhooks and route to the above; fine for prototyping, add a hop of latency and a third party to trust. For the real desk, integrate the broker API directly through DISPATCH and use bridges only as fallback.
- One credential set per account in the Secrets Manager; Operatives get scoped tool tokens.

**Step 4 — Paper on the firm's own sim.** Every firm's eval *is* a paper account with real rules. Run the compiled strategy on one eval at the PROPSIM-recommended eval size, in shadow mode against your REPLAY expectations. Gate: ≥ 30 sessions, tracking error within tolerance, slippage ≤ 1.5× modeled.

**Step 5 — Pass evals in parallel, at eval size.** Buy N evals (cheap relative to the option value), run the same compliant setup, size at the P(pass)-maximizing level (≈10 MES-equivalent for the example strategy). Expect ~45% pass at that edge; budget for resets. This is where WARDEN's "eval mode" rule-set applies.

**Step 6 — Switch to funded sizing on day 1 of funding.** WARDEN loads the funded rule-set; ALLOCATOR sets size by `objective` (harvest ≈ 6–8 MES-eq, longevity ≈ 3–4 MES-eq for the example). Do not let the eval size leak into the funded account.

**Step 7 — Replicate across accounts with MIRROR.** Own-accounts only; proportional sizing; identical instruments; leader account is the one with the *strictest* rules so followers are always within limits; per-account WARDEN checks still run on every copy (a follower may be closer to its floor than the leader). Log every copy event for the compliance ledger.

**Step 8 — Harvest with the drawdown in mind.** Withdrawals reduce the cushion above the floor; after a payout, DISTANCE drops and size must drop with it. Schedule payouts on the firm's cadence and re-size immediately after.

**Step 9 — Monitor degradation per account, per strategy, per firm.** PULSE alarms → size −50% → pause → flatten. Firm-level: payout delays, rule changes, platform outages → reduce exposure to that firm.

**Step 10 — Recycle.** Dead accounts are expected (see CVaR). Re-enter evals only for strategies whose live stats still pass the stage gates; retire the rest.

### 6.3 Scaling capital — the correct order
1. **Scale strategies before accounts.** A second uncorrelated strategy adds more than a second copy of the first (ρ=0.2 vs 0.95 table). Target a book of 4–8 strategies with pairwise |ρ| < 0.4, spanning at least two of: index futures, rates, energy, metals; and two of: mean-reversion, trend, order-flow, event-driven.
2. **Then scale accounts within a firm** up to the cap (5–20), assigning strategies to accounts so that each account holds a *slice of the book*, not a clone. Within-firm correlation is unavoidable but strategy diversity keeps P(all dead) low.
3. **Then scale across firms.** Firms are counterparties: payout delays, rule changes, and closures are firm-level risks. Cap any single firm at ~35% of expected payout. Prefer firms with different platforms/clearing (Rithmic vs Tradovate vs ProjectX) to diversify platform outages.
4. **Then graduate.** Long-lived, well-documented funded accounts (longevity objective) become the audited track record for live capital, a firm's "live" program, or an outside allocator. That is the only route from "prop harvest" to a real quant business.

### 6.4 Diversifying optimally across accounts (allocation rule)
Treat the problem as **maximize expected payout subject to P(all accounts breached in 120d) ≤ 20%, per-firm share ≤ 35%, per-account distance-to-breach ≥ 30%.** Practical solver:
- Estimate the strategy correlation matrix from live daily PnL (LEDGER), shrink it (Ledoit-Wolf).
- HRP across strategies to get target risk weights.
- Assign strategies to accounts by greedy correlation-minimizing packing (each account gets the 2–3 strategies least correlated with what its firm-siblings already hold).
- Size each account by its own DISTANCE: `size = base_size × clip(DISTANCE/0.5, 0.2, 1)`.
- Re-solve weekly and after every payout, breach, or rule change; PROPSIM re-run is the acceptance test.

### 6.5 Metrics to put on the CIO dashboard
Portfolio: E[payout 6mo], CVaR5, P(all dead 120d), firm concentration, strategy correlation heatmap. Per account: DISTANCE, days-to-payout, consistency-rule headroom, contract headroom. Per strategy: rolling Sharpe CUSUM, live-vs-backtest tracking error, slippage drift, PSI on top features. Per Operative: JUDGE score, tool-error rate, cost per validated hypothesis.

---

## 7. Files shipped
- `crucible_propsim.py` — the PROPSIM prototype; edit the strategy block and rule constants and re-run (≈2 min).
- `sim_results.json` — raw numbers behind every table above.
- `sim1…sim7_*.png` — charts referenced in §4.

*This document is a technical blueprint, not financial advice. Prop-firm rules were verified on 3 Sep 2026 from secondary sources and must be confirmed with each firm directly before funding.*

import numpy as np, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
rng = np.random.default_rng(7)
OUT = "/mnt/user-data/outputs"
plt.rcParams.update({"figure.dpi": 130, "font.size": 9, "axes.grid": True, "grid.alpha": .3})
RES = {}

# ---------- Strategy model (per contract, ES-like: 1pt=$50, 3pt stop => R=$150) ----------
def trade_pnl(n, p_win=0.44, R=15.0, fee=1.0, rng=rng):
    win = rng.random(n) < p_win
    wmag = rng.lognormal(np.log(1.6), 0.45, n)             # avg ~1.75R, right-skewed
    lmag = np.where(rng.random(n) < 0.10, 2.0, 1.0)         # 10% of losses gap/slip to 2R
    return np.where(win, wmag * R, -lmag * R) - fee

def sim_days(paths, days, contracts, p_win=0.44, trades_per_day=3, R=15):
    n = paths * days * trades_per_day
    t = trade_pnl(n, p_win, R).reshape(paths, days, trades_per_day) * contracts
    return t  # per-trade pnl [paths, days, trades]

# ---------- Prop rules (Topstep-style $50K) ----------
START, DD, TARGET, DLL, MAXDAYS = 50000, 2000, 3000, 1000, 60

def run_eval(trades, dd_model="eod"):
    """returns pass_day (or -1), breach_day (or -1) per path"""
    P, D, T = trades.shape
    bal = np.full(P, float(START)); hwm = bal.copy()
    passed = np.full(P, -1); breached = np.full(P, -1)
    for d in range(D):
        day_start = bal.copy()
        for k in range(T):
            alive = (passed < 0) & (breached < 0)
            bal[alive] += trades[alive, d, k]
            if dd_model == "intraday":
                hwm = np.maximum(hwm, bal)
            floor = hwm - DD
            hit = alive & ((bal <= floor) | (bal - day_start <= -DLL))
            breached[hit] = d
        alive = (passed < 0) & (breached < 0)
        hwm = np.maximum(hwm, bal) if dd_model == "eod" else hwm
        floor = hwm - DD
        hit = alive & (bal <= floor); breached[hit] = d
        alive = (passed < 0) & (breached < 0)
        ok = alive & (bal >= START + TARGET); passed[ok] = d
    return passed, breached

def run_funded(trades, payout_every=10, keep=0.9):
    """funded stage: trailing EOD DD until floor reaches START (locks), payouts of 50% of profit above a $500 buffer every N days"""
    P, D, T = trades.shape
    bal = np.full(P, float(START)); hwm = bal.copy(); paid = np.zeros(P)
    breached = np.full(P, -1)
    for d in range(D):
        day_start = bal.copy()
        for k in range(T):
            alive = breached < 0
            bal[alive] += trades[alive, d, k]
            floor = np.minimum(hwm - DD, START)  # locks at start once earned
            hit = alive & ((bal <= floor) | (bal - day_start <= -DLL)); breached[hit] = d
        hwm = np.maximum(hwm, bal)
        if (d + 1) % payout_every == 0:
            alive = breached < 0
            profit = np.maximum(bal - START - 500, 0) * 0.5
            take = alive & (profit > 500)
            paid[take] += profit[take] * keep; bal[take] -= profit[take]
    return paid, breached

# ---------- 1. Sizing sweep ----------
PATHS = 6000
sizes = [2, 4, 6, 8, 10, 15, 20]
sweep = {}
for c in sizes:
    tr = sim_days(PATHS, MAXDAYS, c)
    pas, br = run_eval(tr)
    trf = sim_days(PATHS, 120, c)
    paid, brf = run_funded(trf)
    surv120 = (brf < 0).mean()
    sweep[c] = dict(p_pass=(pas >= 0).mean(), p_breach=(br >= 0).mean(),
                    med_days=float(np.median(pas[pas >= 0])) if (pas >= 0).any() else None,
                    p_survive_120=surv120, exp_payout_6mo=float(paid.mean()),
                    cvar5_payout=float(np.sort(paid)[:PATHS // 20].mean()),
                    exp_life_days=float(np.where(brf < 0, 120, brf).mean()))
RES["sizing"] = sweep
fig, ax = plt.subplots(1, 3, figsize=(12, 3.4))
ax[0].plot(sizes, [sweep[c]["p_pass"] * 100 for c in sizes], "o-", label="P(pass eval ≤60d)")
ax[0].plot(sizes, [sweep[c]["p_breach"] * 100 for c in sizes], "s-", label="P(breach in eval)")
ax[0].plot(sizes, [sweep[c]["p_survive_120"] * 100 for c in sizes], "^-", label="P(funded survives 120d)")
ax[0].set_xlabel("contracts (MES)"); ax[0].set_ylabel("%"); ax[0].legend(fontsize=7); ax[0].set_title("Survival vs size")
ax[1].plot(sizes, [sweep[c]["exp_payout_6mo"] for c in sizes], "o-", label="E[payout 6mo]")
ax[1].plot(sizes, [sweep[c]["cvar5_payout"] for c in sizes], "s-", label="CVaR5 payout")
ax[1].set_xlabel("contracts"); ax[1].set_ylabel("$ per account"); ax[1].legend(fontsize=7); ax[1].set_title("Payout vs size")
ax[2].plot(sizes, [sweep[c]["exp_life_days"] for c in sizes], "o-")
ax[2].set_xlabel("contracts"); ax[2].set_ylabel("days"); ax[2].set_title("Expected funded lifetime (cap 120d)")
fig.suptitle("Prop-firm survival Monte Carlo — 50K acct, 2K EOD trailing DD, 1K DLL, edge ~1.3 USD/trade/MES", fontsize=9)
fig.tight_layout(); fig.savefig(f"{OUT}/sim1_sizing_sweep.png"); plt.close(fig)

# ---------- 2. EOD vs intraday trailing, and edge sensitivity ----------
grid = {}
for pw in [0.40, 0.42, 0.44, 0.46]:
    for model in ["eod", "intraday"]:
        tr = sim_days(4000, MAXDAYS, 8, p_win=pw)
        pas, br = run_eval(tr, model)
        grid[(pw, model)] = (pas >= 0).mean()
RES["dd_model"] = {f"{k[0]}_{k[1]}": float(v) for k, v in grid.items()}
fig, ax = plt.subplots(figsize=(5.5, 3.4))
pws = [0.40, 0.42, 0.44, 0.46]
ax.plot(pws, [grid[(p, "eod")] * 100 for p in pws], "o-", label="EOD trailing DD")
ax.plot(pws, [grid[(p, "intraday")] * 100 for p in pws], "s-", label="Intraday trailing DD")
ax.set_xlabel("strategy win rate (avg win 1.75R, loss 1R)"); ax.set_ylabel("P(pass) %"); ax.legend()
ax.set_title("Edge sensitivity × drawdown model (8 MES contracts)")
fig.tight_layout(); fig.savefig(f"{OUT}/sim2_dd_model_edge.png"); plt.close(fig)

# ---------- 3. Multi-account diversification ----------
def multi_account(n_acc, rho, paths=3000, days=120, c=8):
    # correlated daily PnL across accounts via Gaussian copula on daily aggregates
    base = sim_days(paths, days, c).sum(axis=2)         # [paths, days] daily pnl
    mu, sd = base.mean(), base.std()
    z_common = rng.standard_normal((paths, days, 1))
    z_idio = rng.standard_normal((paths, days, n_acc))
    z = np.sqrt(rho) * z_common + np.sqrt(1 - rho) * z_idio
    # map to empirical daily pnl distribution by quantile
    from scipy.stats import norm
    u = norm.cdf(z); srt = np.sort(base.ravel())
    daily = srt[np.clip((u * len(srt)).astype(int), 0, len(srt) - 1)]  # [paths, days, n_acc]
    # funded sim per account with 1 trade/day granularity
    tr = daily[:, :, :, None]  # trades axis
    paid_tot = np.zeros(paths); alive_end = np.zeros(paths)
    for a in range(n_acc):
        paid, br = run_funded(tr[:, :, a, :])
        paid_tot += paid; alive_end += (br < 0)
    return paid_tot, alive_end

div = {}
for rho in [0.95, 0.5, 0.2]:
    for n in [1, 3, 5, 10]:
        paid, alive = multi_account(n, rho)
        div[(rho, n)] = dict(exp=float(paid.mean()), cvar=float(np.sort(paid)[:len(paid) // 20].mean()),
                             p_all_dead=float((alive == 0).mean()), sd=float(paid.std()))
RES["diversification"] = {f"rho{k[0]}_n{k[1]}": v for k, v in div.items()}
fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
for rho, m in zip([0.95, 0.5, 0.2], ["o-", "s-", "^-"]):
    ax[0].plot([1, 3, 5, 10], [div[(rho, n)]["p_all_dead"] * 100 for n in [1, 3, 5, 10]], m, label=f"ρ={rho}")
    ax[1].plot([1, 3, 5, 10], [div[(rho, n)]["cvar"] / div[(rho, n)]["exp"] for n in [1, 3, 5, 10]], m, label=f"ρ={rho}")
ax[0].set_title("P(every account breached by day 120)"); ax[0].set_xlabel("# funded accounts"); ax[0].set_ylabel("%"); ax[0].legend()
ax[1].set_title("Tail quality: CVaR5 / mean (higher = safer)"); ax[1].set_xlabel("# funded accounts"); ax[1].legend()
fig.suptitle("Scaling across accounts: copying one strategy (ρ≈0.95) vs diversified strategy book (ρ≈0.2)", fontsize=9)
fig.tight_layout(); fig.savefig(f"{OUT}/sim3_multi_account.png"); plt.close(fig)

# ---------- 4. Overfitting: max Sharpe from N random strategies ----------
T = 252 * 2
Ns = [1, 10, 50, 200, 1000, 5000]
maxS = {}
for N in Ns:
    r = rng.standard_normal((N, T)) * 0.01
    S = r.mean(1) / r.std(1) * np.sqrt(252)
    maxS[N] = float(np.percentile(S, 50) if N == 1 else S.max())
# DSR expected max (Bailey & Lopez de Prado): E[max] ≈ sqrt(2 ln N) for Gaussian
RES["overfit"] = {"max_sharpe_by_N": maxS, "expected_max_annualized": {N: float(np.sqrt(2 * np.log(max(N, 2)))) * np.sqrt(252) / np.sqrt(T) for N in Ns}}
fig, ax = plt.subplots(figsize=(5.5, 3.4))
ax.semilogx(Ns, [maxS[N] for N in Ns], "o-", label="best backtest Sharpe (zero true edge)")
ax.axhline(1.0, ls="--", c="r", label="typical 'go live' threshold")
ax.set_xlabel("# strategies / parameter sets tried"); ax.set_ylabel("annualized Sharpe (2y)")
ax.set_title("Why a backtest budget is mandatory"); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(f"{OUT}/sim4_overfitting.png"); plt.close(fig)

# ---------- 5. Dynamic strategy weighting under regime shift ----------
D = 500; K = 4
mus = np.array([[.08, .04, .02, -.02], [-.03, .02, .06, .05]]) / 100  # regime A (0-249), regime B (250-499)
sig = 0.01
r = np.zeros((D, K))
for d in range(D):
    reg = 0 if d < 250 else 1
    r[d] = mus[reg] + sig * rng.standard_normal(K)
eq = r.mean(1)
w = np.full(K, 1 / K); dyn = np.zeros(D); lam = 0.93; m = np.zeros(K); v = np.full(K, sig**2)
for d in range(D):
    dyn[d] = (w * r[d]).sum()
    m = lam * m + (1 - lam) * r[d]; v = lam * v + (1 - lam) * (r[d] - m) ** 2
    score = m / np.sqrt(v); w = np.exp(3 * score); w /= w.sum()
    w = 0.7 * w + 0.3 / K  # cap concentration
RES["weighting"] = {"equal_sharpe": float(eq.mean() / eq.std() * np.sqrt(252)), "dynamic_sharpe": float(dyn.mean() / dyn.std() * np.sqrt(252)),
                    "equal_total": float(eq.sum()), "dynamic_total": float(dyn.sum())}
fig, ax = plt.subplots(figsize=(6, 3.4))
ax.plot(np.cumsum(eq) * 100, label="equal weight"); ax.plot(np.cumsum(dyn) * 100, label="EW-Sharpe softmax allocator (30% floor)")
ax.axvline(250, ls="--", c="gray"); ax.text(252, ax.get_ylim()[0] + 0.5, "regime shift", fontsize=7)
ax.set_xlabel("day"); ax.set_ylabel("cum return %"); ax.legend(fontsize=7); ax.set_title("Dynamic signal weighting across 4 strategies")
fig.tight_layout(); fig.savefig(f"{OUT}/sim5_dynamic_weighting.png"); plt.close(fig)

# ---------- 6. Equity fan chart for the 3-contract funded account ----------
tr = sim_days(3000, 120, 8)
P, Dd, Tt = tr.shape
bal = np.full(P, float(START)); hwm = bal.copy(); dead = np.zeros(P, bool); eq_path = np.zeros((P, Dd))
for d in range(Dd):
    ds = bal.copy()
    for k in range(Tt):
        bal[~dead] += tr[~dead, d, k]
        floor = np.minimum(hwm - DD, START); dead |= (bal <= floor) | (bal - ds <= -DLL)
    hwm = np.maximum(hwm, bal); eq_path[:, d] = np.where(dead, np.nan, bal)
pct = np.nanpercentile(eq_path, [5, 25, 50, 75, 95], axis=0)
fig, ax = plt.subplots(figsize=(6.5, 3.4))
ax.fill_between(range(Dd), pct[0], pct[4], alpha=.15, label="5–95%"); ax.fill_between(range(Dd), pct[1], pct[3], alpha=.3, label="25–75%")
ax.plot(pct[2], c="k", label="median"); ax.axhline(START, ls="--", c="r", lw=.8, label="locked floor")
ax.set_title("Funded account equity fan (8 MES, survivors only)"); ax.set_xlabel("day"); ax.set_ylabel("$"); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(f"{OUT}/sim6_equity_fan.png"); plt.close(fig)

json.dump(RES, open("/home/claude/sim/results.json", "w"), indent=1, default=float)
print(json.dumps(RES, indent=1, default=float))

# ---------- 7. Two-regime sizing: aggressive eval size, conservative funded size ----------
EVAL_FEE = 150.0; RESET = 100.0
two = {}
for ev_c in [6, 8, 10, 12]:
    tr = sim_days(4000, MAXDAYS, ev_c); pas, br = run_eval(tr); p_pass = (pas >= 0).mean()
    for fu_c in [3, 4, 5, 6, 8]:
        trf = sim_days(4000, 120, fu_c); paid, brf = run_funded(trf)
        # expected payout per eval attempt, net of fee; expected attempts to get funded = 1/p_pass
        ev_cost = EVAL_FEE + (1 / max(p_pass, 1e-6) - 1) * RESET
        two[(ev_c, fu_c)] = dict(p_pass=float(p_pass), surv=float((brf < 0).mean()), payout=float(paid.mean()),
                                 ev_per_attempt=float(p_pass * paid.mean() - EVAL_FEE),
                                 ev_per_funded=float(paid.mean() - ev_cost))
RES["two_regime"] = {f"eval{k[0]}_funded{k[1]}": v for k, v in two.items()}
fig, ax = plt.subplots(figsize=(6, 3.6))
for ev_c, m in zip([6, 8, 10, 12], ["o-", "s-", "^-", "d-"]):
    ax.plot([3, 4, 5, 6, 8], [two[(ev_c, f)]["ev_per_funded"] for f in [3, 4, 5, 6, 8]], m, label=f"eval @ {ev_c} MES")
ax.set_xlabel("funded-stage contracts (MES)"); ax.set_ylabel("E[6-mo payout] − expected eval cost ($)")
ax.set_title("Two-regime sizing: size up to pass, size down to survive"); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig(f"{OUT}/sim7_two_regime_sizing.png"); plt.close(fig)
json.dump(RES, open("/home/claude/sim/results.json", "w"), indent=1, default=float)
print("TWO", {k: {kk: round(vv, 2) for kk, vv in v.items()} for k, v in RES["two_regime"].items()})

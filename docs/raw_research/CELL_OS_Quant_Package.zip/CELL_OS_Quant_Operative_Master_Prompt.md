# MASTER PROMPT — From CELL//OS to an Agentic Futures Quant Firm

> **How to use:** Paste everything below the line into Claude (Research / extended-thinking mode recommended). Fill the `[[BRACKETS]]` first. Expect a very long output — ask it to deliver section-by-section if it truncates.

---

## ROLE

You are a **Principal Quant Researcher and Head of Trading Infrastructure** at a top-tier futures prop firm, with a second hat as **Chief Agent Architect** for an agentic operating system. You have built systematic futures desks end-to-end (data → research → execution → risk → capital allocation) and you have designed multi-agent production systems that survive real markets. You are ruthlessly skeptical of overfitting, backtest theatre, and hype. You cite sources, name specific tools and their trade-offs, verify that every tool/version you recommend is current as of **September 2026**, and you flag uncertainty explicitly rather than bluffing.

## CONTEXT — THE PLATFORM YOU ARE BUILDING ON

I own an agentic organization operating system called **CELL//OS**. Its agents are called **AI Operatives**. Operatives are grouped into **Cells** (a role + tools + memory + budget + success criteria), Cells form **Cell-Meshes** (collaborative, hierarchical, or competitive topologies), and Meshes run **Missions** that are measured and evolved.

CELL//OS is a layered architecture (top to bottom):

1. **Experience Layer** — Mission Control, Briefing Room (intent & context), Agent Workbench, Org Studio, Org Standard (performance & health), Eval Dashboard, Observability Console.
2. **Interface & Integration Layer** — API Gateway, Webhooks, Connector Framework, Client SDKs.
3. **Cognitive Core Layer** — Intent Engine, Context Engine, Planning Engine, Execution Engine, Memory Engine (episodic/semantic), Learning Engine, Evaluation Engine (score & validate), Evolution Engine (mutate & evolve).
4. **Coordination & Platform Services Layer** — Identity & Access, Org Graph Service, Agent Registry, Capability Registry (skills & tools), Tool Execution, Knowledge Broker, Communication Service, Notification Service.
5. **Memory & Data Layer** — Graph DB (Neo4j), Vector DB, Document Store, Relational DB (Postgres), Time-Series DB (TimescaleDB), Data Warehouse (Snowflake), Lakehouse (Iceberg).
6. **Event & Telemetry Layer** — Event Bus (Kafka/NATS), Mission Events, Agent Events, Telemetry Collector, Telemetry Stream, Alerts.
7. **Runtime & Foundation Layer** — Observability Stack, Model Gateway (LLM routing), Secrets Manager, Config Service (feature flags), Policy Engine (guardrails), Sandbox Runtime (Docker/WASM), Backup & DR.
8. **Foundation (Substrate)** — Infra (cloud/on-prem), Zero-Trust Security, Private Network, Monitoring, FinOps, Compliance, CI/CD, Governance.

Cross-cutting components:
- **A vertical Domain Pane** — a domain-specific slice that cuts through every layer (for this mission: the *Futures Quant* domain pane).
- **THE CRUCIBLE** — "Survival is the benchmark." Ideas, agents, workflows, and orgs are tested adversarially; only the strong get promoted.
- **BLACKBOX** — "Put the problem in. See what evolves." Unknown in, useful out — an evolutionary/AutoML-style discovery engine.
- **THE EVOLUTION LOOP** — Mission → Execute → Evidence → Evaluate → Learn → Mutate → Promote (deploy what works, retire what doesn't).
- **User journey** — Onboarding → Build First Cell → Form Cell-Mesh → Operate → Scale to full CELL//OS.

**My goal:** use CELL//OS to (a) have Operatives trade futures for me at prop firms and (b) ultimately build a full agentic quant trading platform.

**My parameters (fill in):**
- Prop firm(s) / eval rules: `[[e.g., Apex/Topstep/MFF — daily loss limit, trailing drawdown, consistency rule, max contracts]]`
- Products: `[[e.g., ES/NQ/MES/MNQ, CL, GC, ZN, 6E — CME/ICE/Eurex]]`
- Latency tier: `[[intraday/scalping (sub-second) | intraday (seconds–minutes) | swing (hours–days) | mixed]]`
- Capital & risk budget: `[[…]]`
- Broker/data connectivity available: `[[e.g., Rithmic, CQG, Tradovate, Databento, dxFeed]]`
- Compute & budget: `[[cloud/on-prem, GPUs, monthly spend cap]]`
- Team size & skills: `[[…]]`
- Target timeline: `[[X weeks]]`
- Primary language stack: `[[Python/Rust/C++/…]]`

## MISSION

Produce a **complete technical blueprint** — a "0 → Agentic Futures Quant Firm in [[X]] weeks" walkthrough — that (1) surveys the cutting edge of quant research and infrastructure, (2) defines the correct method and order for optimization and measurement, (3) proposes modern architectures for feature engineering/ranking/selection, (4) gives a layer-by-layer Builder Guide for implementing this on CELL//OS, (5) makes everything scalable and parallelizable, and (6) proposes names.

Every recommendation must be **futures- and prop-firm-specific** where it matters: contract rolls and continuous-contract construction (back-adjusted vs ratio-adjusted, roll rules), session structure (RTH/ETH, Globex maintenance windows), tick size/value, margin and intraday margin, CME/ICE/Eurex data specifics (MBO/MBP-10, trade/quote, settlement), prop-firm constraints (daily loss, trailing drawdown, consistency, max position, news-trading rules, copy-trading prohibitions), and the reality that prop-firm evals are a **survival game with asymmetric payoffs** — model this explicitly.

---

# REQUIRED OUTPUT STRUCTURE

## SECTION 1 — THE CUTTING EDGE: Processes, Tools, Models, Agents, Frameworks, Pipelines, Data

Organize as a **taxonomy** with, for every item: what it is, when to use it, top 2–3 tool options (open-source first, then commercial), trade-offs, and how it maps to a CELL//OS layer or Operative.

### 1.1 Data pipelines a quant fund actually runs (enumerate ALL of them, and add ones I haven't thought of)
Cover at minimum, each as its own pipeline with ingestion → validation → normalization → storage → serving → lineage:
- Market data: L1/L2/L3 (MBO/MBP), trades, quotes, OHLCV at multiple resolutions, tick/volume/dollar/imbalance bars, session & holiday calendars, roll calendars, continuous contracts, settlement & open-interest, term-structure/curves, basis, options-on-futures surfaces (implied vol, skew), CVD/order-flow, liquidity/depth metrics.
- Reference data: contract specs, tick sizes, margins (initial/maintenance/intraday, and their change history), exchange fee schedules, symbol mapping across vendors.
- Macro & fundamentals: economic calendar (event timestamps with revisions), central-bank comms, COT reports, inventories (EIA/USDA), rates curves, FX, cross-asset (equities, credit, VIX/vol-of-vol).
- Alternative data: news/NLP, sentiment, satellite/shipping/weather (energy & ags), positioning, prediction markets, social — with a **value-of-information** screen so you don't collect junk.
- Execution data: fills, slippage, queue position, latency, rejections, partial fills, market impact — your own trading exhaust is a first-class dataset.
- Model & research artifacts: features, labels, model versions, hyperparameters, backtests, walk-forward folds, Monte Carlo runs, experiment metadata, decisions and their rationale.
- Agent telemetry: prompts, tool calls, reasoning traces, costs, latencies, evaluations, disagreements between Operatives.
- Risk & PnL: positions, exposures, Greeks (for options-on-futures), VaR/ES, drawdown states, prop-firm rule proximity ("distance to breach").
- **Data storage design:** specify the schema/partitioning/format per pipeline (Parquet/Arrow, Iceberg lakehouse, TimescaleDB vs ClickHouse vs QuestDB vs kdb+/q vs ArcticDB, DuckDB/Polars for research, feature store such as Feast/Hopsworks, vector DB for research memory, Neo4j for the strategy/feature/model lineage graph), point-in-time correctness, survivorship/lookahead-bias prevention, data quality gates (Great Expectations / Pandera / Soda), lineage (OpenLineage/Marquez), and orchestration (Dagster vs Prefect vs Airflow vs Temporal). Explain what to **store, derive, cache, or discard** and at what retention.

### 1.2 Model types — categorized, with the futures use-case for each
- Classical/statistical: ARIMA/GARCH families, Kalman/state-space, regime-switching (HMM/Markov-switching), cointegration/pairs, term-structure models, microstructure models (Kyle, Almgren-Chriss, queue models, Hawkes processes).
- Machine learning: gradient boosting (LightGBM/XGBoost/CatBoost) on tabular features, meta-labeling, triple-barrier labeling, sequence models (LSTM/TCN/Transformer variants — TFT, PatchTST, iTransformer), time-series foundation models (Chronos, TimesFM, Moirai, Lag-Llama — assess honestly whether they add alpha or just noise), probabilistic/quantile models (DeepAR, conformal prediction), Bayesian methods.
- Reinforcement learning: execution RL, position-sizing RL, offline RL, and why most trading RL fails (reward hacking, non-stationarity) — and the narrow cases where it works.
- Generative/simulation: agent-based market simulators, GAN/diffusion synthetic order-flow for stress testing, bootstrap/block-bootstrap, regime-conditional Monte Carlo.
- Genetic/evolutionary: genetic programming for signal discovery (the BLACKBOX engine), symbolic regression, CMA-ES/NSGA-II/III for multi-objective (Pareto) optimization.
- Ensemble & meta-models: stacking, Bayesian model averaging, online learning/bandits for dynamic strategy weighting, mixture-of-experts by regime, hierarchical risk parity/HRP for allocation.
- LLM/agentic models: where LLMs belong (research synthesis, code generation, feature hypothesis generation, news/event parsing, post-mortems, anomaly explanation) vs where they must **never** be in the hot path. Model Gateway routing policy by task (frontier reasoning vs fast/cheap vs local/private).

### 1.3 Model development pipeline (research → production)
Define the reference pipeline with stage gates: hypothesis registry → data & features (point-in-time) → labeling → CV that respects time (purged/embargoed K-fold, CPCV, walk-forward, nested) → model training → hyperparameter search (Optuna/Ray Tune, with a strict search-budget accounting for multiple-testing) → backtest → forward/paper test → shadow trading → capital allocation → live → monitoring → retirement. Specify tooling: MLflow / W&B for experiment tracking, model registry, DVC/LakeFS for data versioning, Ray/Dask for scale-out, containerized Sandbox Runtime for every research job, CI/CD for strategies (strategy-as-code with automated backtest regression tests).

### 1.4 Backtesting & simulation stack
Compare engines for futures: NautilusTrader, vectorbt (pro), backtrader, Zipline-reloaded, QuantConnect LEAN, hftbacktest, custom event-driven engine in Rust/C++ — by fidelity (tick/L2 replay, latency modeling, queue position, partial fills, roll handling, commissions/fees/exchange fees, margin calls, prop-firm rule simulation). Specify the **fidelity ladder** (vectorized → event-driven → L2 replay → agent-based) and when each is sufficient.

### 1.5 Execution, risk & connectivity
Broker/venue APIs (Rithmic, CQG, Tradovate, Interactive Brokers, direct CME iLink for the ambitious), FIX, order types that matter in futures (iceberg, stop-limit, OCO, bracket), smart execution (TWAP/VWAP/POV/adaptive), pre-trade risk checks, kill switches, prop-rule enforcement engine, reconciliation.

### 1.6 Agentic models, frameworks & team patterns
Compare LangGraph, CrewAI, AutoGen/AG2, OpenAI Agents SDK, Anthropic Agent SDK / Claude Code style agents, Semantic Kernel, DSPy (for prompt optimization), Temporal for durable workflows, and MCP as the tool-integration standard — and state which primitives CELL//OS should build natively vs wrap. Cover: role-specialized agents, planner/executor, critic/verifier, debate/adversarial pairs, tournament/selection (Crucible), evolutionary agents (Evolution Engine), memory architectures (episodic/semantic/procedural), and evaluation harnesses (LLM-as-judge with calibration, golden datasets, regression evals).

### 1.7 Observability, evaluation & governance tooling
OpenTelemetry, Prometheus/Grafana, Langfuse/Arize Phoenix/LangSmith for agent tracing, Evidently/NannyML/whylogs for drift, feature-flag/config service patterns, policy-as-code (OPA), audit trails, secrets, model cards, and compliance considerations for prop firms.

## SECTION 2 — OPTIMIZATION: THE CORRECT METHOD AND ORDER, AND HOW TO MEASURE IT

This is the most important section. Produce a **strict, ordered protocol** — a decision tree with gates — for going from raw idea to allocated capital without fooling yourself. Include:

1. **Hypothesis first** — economic rationale, expected edge source (risk premium, behavioral, structural, flow, microstructure), expected decay, capacity, and a pre-registered kill criterion *before* any backtest.
2. **Data hygiene gates** — point-in-time, lookahead, survivorship, roll artifacts, session leakage, timestamp alignment across vendors.
3. **Labeling** — fixed-horizon vs triple-barrier vs trend-scanning; meta-labeling for bet sizing.
4. **Feature evaluation before modeling** — stationarity, fractional differentiation, IC/ICIR, mutual information, feature importance stability (MDI/MDA/SFI), clustering redundant features, orthogonalization.
5. **Cross-validation that respects time** — purged K-fold with embargo, CPCV, walk-forward with anchored vs rolling windows, nested CV for hyperparameters; explicitly state how many backtests you're "allowed" and how to correct (Deflated Sharpe Ratio, Probability of Backtest Overfitting, White's Reality Check / SPA, Bonferroni/Holm/BH).
6. **Backtest → statistics** — Sharpe/Sortino/Calmar, tail metrics (CVaR, max DD, DD duration, ulcer), turnover & capacity, cost sensitivity curves, t-stats with HAC corrections, minimum backtest length, minimum track record length, bootstrap confidence intervals.
7. **Monte Carlo** — trade-order reshuffling, block bootstrap of returns, parameter perturbation, regime-conditional resampling, synthetic paths, and specifically **prop-firm survival simulation** (probability of passing eval and of breaching trailing drawdown, expected time-to-breach, optimal sizing under those rules — Kelly with drawdown constraints, drawdown-controlled bet sizing).
8. **Robustness** — parameter-surface smoothness (avoid isolated peaks), sensitivity heatmaps, cross-product/cross-timeframe transfer, regime breakdown analysis, stress tests (2020 March, 2022 rates, flash events, exchange outages).
9. **Multi-objective / Pareto optimization** — which objectives (return, DD, turnover, capacity, tail risk, prop-rule proximity, model complexity), NSGA-II/III vs Bayesian multi-objective, how to pick from the Pareto front, and why never to optimize a single scalar.
10. **Forward testing / paper / shadow** — minimum durations, statistical tests for live-vs-backtest divergence (tracking error, slippage attribution, hit-rate drift), promotion criteria.
11. **Portfolio-level allocation & dynamic signal weighting** — how real firms run many signals/strategies in parallel and weight them: ensemble/stacking, HRP, risk parity, Bayesian model averaging, online bandits/Thompson sampling with decay, regime-conditional weights, correlation-aware caps, kill-and-revive rules, and how weights are themselves validated (no allocator overfitting).
12. **Live monitoring & decay detection** — CUSUM/Page-Hinkley on rolling Sharpe, drawdown vs Monte Carlo envelope, feature drift (PSI/KS), prediction drift, slippage drift, "distance to prop-rule breach", automatic de-risking ladder, retirement rules, and post-mortem protocol.
13. **What to measure at each stage** — one table: stage → metrics → thresholds/gates → who (which Operative) owns it → what artifact is stored where in CELL//OS.

State explicitly what **not** to do (parameter sweeps on the full sample, re-running until Sharpe looks good, optimizing on in-sample DD, cherry-picking start dates, ignoring roll costs and fees, sizing to the eval instead of the edge).

## SECTION 3 — MODERN ARCHITECTURES FOR FEATURE ENGINEERING, RANKING & SELECTION (categorized)

Propose and categorize concrete architectures, each with a diagram-in-words, data flow, tooling, and how it plugs into the BLACKBOX/Evolution Engine:
- **Feature generation:** hand-crafted microstructure & order-flow features, automated feature synthesis (genetic programming / formulaic alpha mining à la Alpha101-style but futures-native), LLM-proposed hypotheses → auto-coded → auto-tested, representation learning (autoencoders, contrastive time-series encoders), cross-sectional features across the futures universe and curve.
- **Feature ranking & selection:** filter (IC/ICIR, MI), wrapper (permutation importance with purged CV, Boruta-style), embedded (L1, tree importance with clustering to correct substitution effects), stability selection across folds/regimes, orthogonalization vs existing factors, capacity-adjusted ranking, cost-adjusted ranking.
- **Signal ranking & strategy selection:** tournament/Crucible designs (elimination brackets, Elo/TrueSkill for strategies, survival analysis of strategies), multi-armed bandits for allocation, "strategy zoo" with lifecycle states (incubating → paper → shadow → live → probation → retired).
- **Regime architecture:** regime detection layer (HMM, clustering on vol/trend/liquidity, jump detection) feeding mixture-of-experts and allocator.
- **Anti-overfitting architecture:** the "research firewall" — separate Operatives for hypothesis generation vs evaluation with information barriers, holdout data that only the Evaluation Engine can touch, backtest budget accounting per hypothesis.

## SECTION 4 — BUILDER GUIDE: 0 → AGENTIC FUTURES QUANT FIRM ON CELL//OS IN [[X]] WEEKS

### 4.1 The Futures Quant Domain Pane
Define exactly what the vertical Domain Pane adds at **every** CELL//OS layer (Experience through Foundation): domain screens, domain connectors, domain skills in the Capability Registry, domain schemas in the Memory & Data Layer, domain events on the bus, domain policies in the Policy Engine, domain evals in the Evaluation Engine.

### 4.2 Layer-by-layer: what each layer/Operative does to improve trading-model performance
For each of the 8 layers: the concrete responsibilities, the Operatives that live there, the tools they get, the data they read/write, the metrics they emit, and specifically **how that layer's work feeds the performance of the trading model** (e.g., Context Engine → point-in-time feature assembly; Evaluation Engine → CPCV/Deflated Sharpe gate; Evolution Engine → parameter/feature mutation under a backtest budget; Policy Engine → prop-rule hard limits; Memory Engine → regime & post-mortem recall).

### 4.3 The Operative roster & team architecture
Design the Cells and the Cell-Mesh: e.g., Data Steward, Market-Structure Analyst, Feature Scientist, Hypothesis Generator, Model Developer, Backtest Engineer, Adversarial Reviewer / Red Team, Risk Officer, Prop-Rule Warden, Execution Trader, Allocator/CIO, Post-Mortem Analyst, Ops/SRE, Compliance. For each: role, model tier (via Model Gateway), tools, memory scope, budget, success criteria, escalation path, and what it is **forbidden** to do. Then specify the **mesh topology** (hierarchical with a CIO Operative? adversarial pairs? tournament? committee voting?) and argue — with evidence from agent-systems research and practice — which team architectures and agent types are **most reliable** for this domain, and which fail (e.g., unconstrained autonomous traders, single-agent end-to-end, LLM-in-hot-path). Include human-in-the-loop checkpoints and their triggers.

### 4.4 Monitoring for degradation — agent, strategy, and portfolio
A unified degradation-detection design across three levels: (a) **Operative quality** (eval-score drift, tool-error rates, cost creep, hallucinated data, disagreement rates, reasoning-trace anomalies), (b) **Strategy performance** (Section 2 §12 metrics), (c) **Portfolio/firm** (correlation spikes, concentration, aggregate distance-to-breach). Define alert tiers, automatic actions (de-risk, pause, quarantine, roll back model version), the dashboards in the Observability Console / Eval Dashboard, and the weekly Evolution Loop review ritual.

### 4.5 The week-by-week plan
A concrete plan for [[X]] weeks with milestones, deliverables, acceptance tests, and the CELL//OS journey stages (First Cell → Cell-Mesh → Operate → Scale). Include a minimal viable path (one product, one timeframe, one strategy family, paper trading) and the expansion path. Provide the **suite of tools** to install per week and a repo/module layout.

## SECTION 5 — SCALABILITY & PARALLELIZATION

Re-express every pipeline and the research loop as horizontally scalable, embarrassingly-parallel-where-possible designs: Ray/Dask clusters for backtests and Monte Carlo (thousands of parameter sets × folds × MC paths), GPU scheduling for sequence models, Kafka partitioning by product/session, lakehouse partitioning strategy, feature store online/offline split, stateless Operative workers with durable workflow orchestration (Temporal), sandbox pooling, caching (Arrow Flight/Redis), autoscaling and FinOps guardrails, multi-region/DR, and data-locality rules. Give capacity estimates (how many backtests/hour per node class) and the bottlenecks to expect in order.

## SECTION 6 — 20 PLATFORM NAMES

Twenty names that sound premium, quant-native, superior, and cutting-edge (think: institutional, mathematical, slightly menacing). For each: one-line rationale and a quick note on likely domain/trademark collision risk (state that this must be verified).

---

## FORMAT & QUALITY REQUIREMENTS

- Use clear headings, tables for comparisons, and numbered protocols for anything procedural. Include ASCII/mermaid diagrams for pipelines and the mesh topology.
- Be specific: name tools, libraries, algorithms, papers, and metrics. Prefer primary sources (papers, docs, exchange specs). Where you cite a tool, note its status as of 2026 and flag if it may be stale.
- Distinguish clearly between **established best practice**, **promising but unproven**, and **hype**.
- Every section must end with a short "**CELL//OS mapping**" box: which layers/engines/Operatives implement it and which artifacts/events it produces.
- Assume I am technical and building this myself; do not pad, do not moralize, and do not tell me trading is risky more than once.
- If output length is a constraint, deliver Section 1, then pause and continue with the next section on my "continue".

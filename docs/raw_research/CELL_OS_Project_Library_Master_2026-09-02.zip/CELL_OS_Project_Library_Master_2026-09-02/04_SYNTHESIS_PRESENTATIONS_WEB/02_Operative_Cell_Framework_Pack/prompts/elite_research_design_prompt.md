# Elite Research + Design Prompt — Agentic Engineering Platform / ORCA Framework

Copy this prompt into a new advanced reasoning, Claude, GPT, or deep-research session. Attach the full Agent Factory / Agent Army / Agentic Engineering repository or zip before running it.

---

You are a senior AI systems architect, agentic engineering researcher, platform engineer, technical strategist, product designer, and adversarial reviewer. You are helping design a frontier **Agentic Engineering Platform** that can create, configure, run, evaluate, govern, and improve synthetic software-delivery organizations.

The current naming hypothesis is:

- A normal autonomous worker is an **agent**.
- Our enhanced mission-bound worker is an **AI Operative**.
- The deployable technical unit is an **Operative Cell**.
- The framework is **ORCA: Operative Runtime, Certification & Assurance**.
- The larger platform is an **Agentic Organization Platform**.

Your job is to validate, improve, and operationalize this concept.

## Primary objective

Produce a professional-grade research/design/implementation artifact set that explains the theory, architecture, implementation plan, use cases, novelty claims, evaluation method, and product experience for the Agentic Engineering Platform.

The deliverable must be useful to:

1. Engineers building the platform.
2. Researchers evaluating agentic organization design.
3. Product stakeholders deciding roadmap and business value.
4. Operators using the platform to launch, supervise, compare, and certify agentic missions.
5. Future AI sessions ingesting the artifact pack to continue the work.

## Working thesis to test

This platform is not just “agents with better prompts.” It is an **organizational runtime** that compiles mission intent into versioned, certified, evidence-producing **Operative Cells**.

An Operative Cell is a mission-bound synthetic organization unit composed of:

- AI Operatives / seats
- role definitions
- model and tool permissions
- mission contract
- typed DAG / mission hypergraph
- context packet / knowledge snapshot
- memory and provenance policy
- evaluation criteria
- human/policy gates
- cost and time budgets
- observability stream
- evidence ledger
- rollback / recovery plan
- version lockfile
- post-mission learning writeback

## Source material to ingest

Analyze all attached artifacts and repository files. Preserve file-path citations for every claim. Group evidence into:

- observed in repo/docs
- derived from repo/docs
- external prior art
- design recommendation
- speculative frontier hypothesis

Specifically look for:

- agent definitions
- team definitions
- orchestration logic
- workflow DAGs
- prompt templates
- evaluation logic
- memory / knowledge services
- UI prototypes
- monitoring and observability
- approval gates
- cost controls
- GitHub/Jira/Slack/Prefect/Snowflake/Azure integrations
- research docs and generated packs
- gaps between design docs and implemented code

## Required research questions

Answer each question with evidence, implementation implications, and diagrams.

### 1. Naming and ontology

Is **AI Operative** technically precise enough?

Compare these candidate terms:

- Agent
- AI Operative
- Operative Cell
- Synthetic Organization Unit
- Mission-Bound Organization
- Agentic Organization Runtime
- Operative Runtime Unit
- Certified Operative Cell
- Agentic Assembly
- Agentic Institution

Recommend a final naming stack with definitions, boundaries, and examples.

### 2. Core entity definition

Define the smallest technical unit that is meaningfully different from an agent. Include:

- YAML schema
- lifecycle states
- inputs/outputs
- events
- metrics
- failure modes
- versioning model
- minimum viable implementation

### 3. Architecture

Create a north-star architecture for the Agentic Engineering Platform. Include:

- Mission Control UI
- Agent/Operative Factory
- Organization Compiler
- Org-IR / Cell-IR
- Context Compiler
- Knowledge Broker
- Collective Cognition Fabric
- Capability Registry
- Evaluation Service
- Simulation / Replay Service
- Evidence Ledger
- Policy/Gate Engine
- Observability Service
- Evolution Chamber
- Research Compiler / Research Army
- Self-Maintenance Corps

Use diagrams heavily.

### 4. Theory and prior art

Research and relate the system to:

- multi-agent systems
- automated design of agentic systems
- evolutionary multi-agent generation
- workflow optimization/meta-tools
- autonomic computing / MAPE-K
- control theory
- Kubernetes-style reconciliation
- Erlang/OTP supervision trees
- blackboard/global workspace architectures
- organizational science / holarchies / viable systems
- human-in-the-loop AI assurance
- software supply-chain provenance
- evaluations for coding agents

For each prior-art area, state:

- what it supports
- what it does not prove
- how it changes the architecture
- what experiments are needed

### 5. Novel concepts from this research program

Identify concepts that appear genuinely innovative or strong recombinations. At minimum assess:

- AI Operative
- Operative Cell
- Org-IR / Cell-IR
- Mission Hypergraph
- Mission Assurance Receipt
- Collective Cognition Fabric
- Organization Compiler
- Research Compiler
- Evolution Chamber
- Shadow Twin Organization
- Capability Readiness / Agent Health Score
- Last-Minute Skill-Up
- Agent Ghosts / Resurrection Capsules
- Terminal Genome
- Bounded Self-Hosting Reconciliation
- Temporal Echelons
- Capability Economy / Internal Market
- Meta-tool Compiler
- Operative Cell Genome Search

For each concept include:

- definition
- novelty rating
- technical value
- business value
- implementation difficulty
- risks
- first experiment
- whether it belongs in MVP, next, lab, or reject

### 6. Agent vs Operative vs Operative Cell comparison

Create a comparison chart showing:

- what a normal agent contains
- what an AI Operative adds
- what an Operative Cell contains
- what an Army / Organization adds
- how value compounds at each level

### 7. Use cases

Design use cases with required cell topology, workflow DAG, success criteria, metrics, and UI experience:

- connector migration
- incident triage
- data quality guardian
- API integration pod
- codebase refactor
- product/UI studio
- knowledge stewardship
- research compiler
- factory self-maintenance
- autonomous online business operator

### 8. Evaluation and certification

Design the evaluation framework. Include:

- RED→GREEN proof
- regression proof
- per-mission green criteria
- activity vs outcome metrics
- team credit assignment
- cost per accepted change
- shadow organization comparison
- human-gate rejection reasons
- replay and provenance evidence
- promotion gates for new cell versions

### 9. Implementation plan

Produce a phased roadmap:

- Phase A: Assurance substrate
- Phase B: Mission intelligence
- Phase C: Safe comparison
- Phase D: Bounded self-maintenance
- Phase E: Organizational scale
- Phase F: Optimization lab
- Phase G: frontier self-organization

For each phase include:

- build items
- data models
- API endpoints
- UI components
- tests
- success metrics
- risks
- dependencies
- estimated complexity

### 10. Product/web/presentation artifacts

Recommend the best artifact layout for communicating and implementing the platform:

- comprehensive markdown/doc
- interactive HTML explainer
- slide deck
- schema pack
- Mermaid diagram pack
- implementation backlog
- research prompt pack
- evaluator checklist
- architecture decision records

## Diagram requirements

Use Mermaid, ASCII, tables, and DAGs. Include at least:

1. Platform system map.
2. Agent vs AI Operative vs Operative Cell anatomy.
3. Mission lifecycle DAG.
4. Knowledge flow / Collective Cognition Fabric.
5. Evaluation and certification loop.
6. Shadow Twin comparison architecture.
7. Evolution Chamber loop.
8. Self-maintenance MAPE-K adaptation.
9. Research Compiler DAG.
10. Phase roadmap.

## Output format

Produce these artifacts:

```text
agentic-engineering-platform-pack/
├── README.md
├── 00_executive_summary.md
├── 01_naming_and_ontology.md
├── 02_core_framework.md
├── 03_architecture.md
├── 04_theory_and_prior_art.md
├── 05_novel_concepts.md
├── 06_agent_vs_operative_comparison.md
├── 07_use_cases.md
├── 08_evaluation_and_certification.md
├── 09_implementation_roadmap.md
├── 10_ui_webpage_spec.md
├── 11_presentation_outline.md
├── diagrams/
│   ├── platform_map.mmd
│   ├── operative_cell_anatomy.mmd
│   ├── mission_lifecycle_dag.mmd
│   ├── collective_cognition.mmd
│   ├── evaluation_loop.mmd
│   └── evolution_chamber.mmd
├── schemas/
│   ├── operative_cell.schema.yaml
│   ├── mission_contract.schema.yaml
│   ├── org_ir.schema.yaml
│   └── evidence_receipt.schema.yaml
├── prompts/
│   ├── deep_research_prompt.md
│   ├── adversarial_review_prompt.md
│   ├── implementation_bootstrap_prompt.md
│   └── presentation_prompt.md
└── backlog/
    ├── phase_a_assurance_substrate.md
    ├── phase_b_mission_intelligence.md
    └── phase_c_safe_comparison.md
```

## Quality bar

Do not produce a generic agent essay. The output must be:

- specific to this platform
- implementation-oriented
- visually rich
- grounded in supplied docs/code
- explicit about uncertainty
- clear about what is new vs prior art
- careful not to overclaim novelty
- structured enough for another AI session to continue
- strong enough to guide real engineering work

## Final answer required

End with:

1. Recommended final name stack.
2. The 5 most valuable innovations.
3. The first 10 implementation tasks.
4. The biggest risks.
5. The evidence still missing.
6. The artifact set that should be generated next.

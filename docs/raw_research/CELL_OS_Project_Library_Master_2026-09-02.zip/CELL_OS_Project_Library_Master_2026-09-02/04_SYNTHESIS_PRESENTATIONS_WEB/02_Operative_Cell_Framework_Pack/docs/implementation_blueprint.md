# Implementation Blueprint — ORCA / Operative Cell Framework

## Build order

The platform should not start by building exotic agent swarms. It should start by making every mission measurable, replayable, gated, and evidence-producing.

```mermaid
flowchart LR
  A[Phase A\nAssurance Substrate] --> B[Phase B\nMission Intelligence]
  B --> C[Phase C\nSafe Comparison]
  C --> D[Phase D\nBounded Self-Maintenance]
  D --> E[Phase E\nOrganizational Scale]
  E --> F[Phase F\nOptimization Lab]
  F --> G[Phase G\nFrontier Self-Organization]
```

## Phase A — Assurance substrate

**Goal:** Every mission has a contract, version, graph, evidence record, and pass/fail criterion.

Build:

- Mission Contract schema
- Cell-IR schema
- Cell blueprint registry
- version lockfile
- evidence ledger
- RED→GREEN evaluation record
- regression proof hooks
- human gate record
- minimal Mission Assurance Receipt

Minimum API:

```text
POST /missions/compile
POST /cells/launch
GET  /missions/{id}/graph
POST /missions/{id}/evidence
POST /missions/{id}/gate
GET  /missions/{id}/receipt
```

Success metrics:

- 100% of cell launches have versioned blueprint ID
- 100% of production-impacting changes have green criteria
- 100% of accepted changes have evidence receipt
- rollback/recovery path documented for every high-risk mission

## Phase B — Mission intelligence

Build:

- Mission Hypergraph
- Context Compiler
- capability readiness score
- agent health model
- knowledge broker retrieval policies
- dashboard critical path / blockers

Success metrics:

- lower time-to-first-useful-evidence
- fewer blocked/unknown states
- higher reuse of previous mission knowledge
- lower operator babysitting time

## Phase C — Safe comparison

Build:

- Shadow Twin cells
- builder/skeptic review flow
- counterfactual evidence store
- comparative scorecards
- promotion gate for new blueprints

Success metrics:

- live-vs-shadow agreement rate
- shadow-caught defects
- human gate precision
- cost per certified improvement

## Phase D — Bounded self-maintenance

Build:

- certification monitor
- failure classifier
- quarantine/fallback system
- last-certified-version router
- self-maintenance mission compiler
- canary deployment path

Success metrics:

- reduced MTTR
- fewer repeated failures
- fewer unsafe retries
- no self-editing without gate

## Phase E — Organizational scale

Build:

- multi-cell command model
- domain/client boundaries
- federation protocol
- policy inheritance
- cross-cell knowledge promotion

Success metrics:

- multiple workload repos managed safely
- client isolation preserved
- reusable cell blueprints across domains

## Phase F — Optimization lab

Build:

- replay dataset
- blueprint tournament harness
- meta-tool candidate miner
- capability registry scoring
- Pareto frontier dashboard

Success metrics:

- lower model/tool calls per accepted change
- improved success/cost ratio
- reliable promotion of better cell versions

## Phase G — Frontier self-organization

Research only until evidence is strong:

- capability economy
- evolutionary organization species
- stigmergic/morphogenetic coordination
- automatic topology mutation

Hard boundary:

> New organizational forms may be discovered automatically, but production promotion requires certification, replay evidence, and human/policy gates.

## Data model sketch

```mermaid
erDiagram
  MISSION ||--|| MISSION_CONTRACT : defines
  MISSION ||--|| OPERATIVE_CELL : launches
  OPERATIVE_CELL ||--|| CELL_BLUEPRINT : versioned_from
  OPERATIVE_CELL ||--o{ AI_OPERATIVE : contains
  OPERATIVE_CELL ||--o{ MISSION_NODE : executes
  MISSION_NODE ||--o{ EVIDENCE_RECORD : produces
  MISSION ||--o{ GATE_DECISION : requires
  MISSION ||--|| ASSURANCE_RECEIPT : emits
  OPERATIVE_CELL ||--o{ KNOWLEDGE_WRITEBACK : learns
  CELL_BLUEPRINT ||--o{ CERTIFICATION_RESULT : evaluated_by
```

## Minimum backend services

| Service | Responsibility |
|---|---|
| Mission Compiler | Converts brief/ticket into Mission Contract. |
| Cell Compiler | Converts contract + blueprint into Cell-IR/Org-IR. |
| Operative Runtime | Launches operatives, tools, and mission graph. |
| Context Compiler | Builds bounded context packets with provenance. |
| Knowledge Broker | Retrieves, ranks, promotes, and invalidates knowledge. |
| Evaluation Service | Runs mission-specific evals, RED→GREEN proofs, and regression checks. |
| Evidence Ledger | Stores evidence records, decisions, costs, diffs, and hashes. |
| Gate Engine | Enforces human/policy approvals and segregation of duty. |
| Capability Registry | Tracks certified blueprints, agents, tools, and performance. |
| Replay/Simulation | Replays missions and tests alternative cells. |
| Evolution Chamber | Searches for better prompts, tools, workflows, and topologies. |
| Observability | Emits events, metrics, traces, alerts, and dashboards. |

## UI surfaces

| Surface | Purpose |
|---|---|
| Mission Control | Launch, supervise, gate, and inspect missions. |
| Cell Builder | Compose operatives, tools, memory policies, and DAGs. |
| Blueprint Diff | Compare versions and certification status. |
| Evidence Inspector | Inspect tests, logs, artifacts, diffs, decisions, and provenance. |
| Shadow Arena | Compare primary vs shadow cells. |
| Evolution Chamber | Review candidate improvements and promotion evidence. |
| Knowledge Graph | Inspect collective cognition, contradictions, stale zones, and provenance. |
| Reliability Console | View platform self-health, quarantines, fallbacks, and maintenance missions. |

## First 10 implementation tasks

1. Define `mission_contract.yaml`.
2. Define `operative_cell.schema.yaml`.
3. Add Cell Blueprint Registry table/API.
4. Compile existing connector pipeline into a typed mission DAG.
5. Add mission evidence ledger table.
6. Add per-mission green criteria to launch flow.
7. Emit a simple Mission Assurance Receipt.
8. Add version lockfile for agent/model/tool/prompt/config.
9. Add Organization Preflight with credential/config/tool readiness checks.
10. Build a minimal dashboard: mission graph, blocker, cost, evidence, gate state.

# Visual Diagram Library

## 1. Naming stack

```mermaid
flowchart TB
  A[Agentic Organization Platform] --> B[ORCA Framework]
  B --> C[Operative Cell]
  C --> D[AI Operative]
  C --> E[Tools]
  C --> F[Mission Contract]
  C --> G[Evidence Ledger]
```

## 2. Standard agent vs Operative Cell

```text
STANDARD AGENT
prompt + model + tools

AI OPERATIVE
role + mission + scoped tools + health + metrics

OPERATIVE CELL
operatives + mission graph + contract + memory + evals + gates + evidence + recovery
```

## 3. Platform map

```mermaid
flowchart TB
  UI[Mission Control] --> Intent[Intent Contract]
  Intent --> Compiler[Organization Compiler]
  Compiler --> Registry[Blueprint Registry]
  Registry --> Runtime[Operative Runtime]
  Runtime --> Tools[Tool Layer]
  Runtime --> Eval[Evaluation]
  Runtime --> Evidence[Evidence Ledger]
  Runtime --> Cognition[Collective Cognition]
  Evidence --> Receipt[Assurance Receipt]
  Eval --> Gate[Gate Engine]
  Cognition --> Evolution[Evolution Chamber]
  Evolution --> Registry
```

## 4. Mission graph with evidence

```mermaid
flowchart LR
  A[Node: Reproduce Failure] --> B[Evidence: failing test]
  B --> C[Node: Implement Fix]
  C --> D[Evidence: diff]
  D --> E[Node: Regression Suite]
  E --> F[Evidence: all tests pass]
  F --> G[Gate Decision]
```

## 5. Mission assurance receipt

```mermaid
flowchart TB
  A[Mission Identity] --> R[Assurance Receipt]
  B[Blueprint Versions] --> R
  C[Execution Graph] --> R
  D[Test Evidence] --> R
  E[Policy/Gate Decisions] --> R
  F[Provenance] --> R
  G[Rollback Plan] --> R
```

## 6. Evolution chamber

```mermaid
flowchart TB
  Archive[Blueprint Archive] --> Generate[Generate Candidate Cells]
  Generate --> Replay[Replay Missions]
  Replay --> Score[Score Success / Cost / Risk]
  Score --> Select[Select Pareto Winners]
  Select --> Certify[Certification Gate]
  Certify --> Registry[Certified Registry]
  Registry --> Archive
```

## 7. Last-minute skill-up

```mermaid
flowchart LR
  M[Mission Requirements] --> Gap[Capability Gap Analysis]
  H[Operative Health Scores] --> Gap
  Gap --> Rec[Skill-Up Recommendation]
  Rec --> Action[Context Refresh / Tool Drill / Prior Case Pack / Budget Upgrade]
  Action --> Ready[Readiness Score]
```

## 8. Agent ghosts

```mermaid
flowchart LR
  Session[Completed Session] --> Transcript[Transcript Index]
  Session --> Diff[Diff + Artifacts]
  Session --> Evidence[Evidence]
  Transcript --> Ghost[Queryable Agent Ghost]
  Diff --> Ghost
  Evidence --> Ghost
  Ghost --> Future[Future Mission Context]
```

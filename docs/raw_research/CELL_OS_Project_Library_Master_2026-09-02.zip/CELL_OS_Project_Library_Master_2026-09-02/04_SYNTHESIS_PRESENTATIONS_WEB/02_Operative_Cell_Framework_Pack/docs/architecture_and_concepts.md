# ORCA — Operative Runtime, Certification & Assurance

## Executive summary

ORCA is a framework for building an **Agentic Engineering Platform** that creates, runs, evaluates, and improves mission-bound synthetic organizations called **Operative Cells**.

The central insight is that the useful technical unit is not the agent. The useful unit is a **certified cell**: a versioned organization package that knows its mission, tools, constraints, memory, evaluation criteria, evidence obligations, and recovery path.

## Agent vs AI Operative vs Operative Cell

```mermaid
flowchart LR
  A[Standard Agent\nPrompt + model + tools] --> B[AI Operative\nRole + mission context + tool scope + health + metrics]
  B --> C[Operative Cell\nOperatives + DAG + contract + memory + evals + gates + evidence]
  C --> D[Army / Organization\nMultiple cells + shared doctrine + cognition fabric + portfolio metrics]
```

| Capability | Standard Agent | AI Operative | Operative Cell | Army / Organization |
|---|---|---|---|---|
| Executes tasks | Yes | Yes | Yes | Yes |
| Role-specific identity | Weak | Strong | Strong | Strong |
| Tool permissions | Basic | Scoped | Policy-compiled | Federated |
| Mission contract | Prompt-only | Explicit | Typed and enforceable | Portfolio-level |
| Workflow model | Hidden reasoning | Role workflow | Mission graph / DAG | Multi-cell graph |
| Evaluation | Ad hoc | Per role | RED→GREEN + regression + receipt | Cross-cell KPIs |
| Memory | Chat/session | Context packet | Permissioned knowledge snapshot | Collective cognition |
| Governance | Manual | Tool scope | Gates, budgets, approvals | Institutional policy |
| Recovery | Retry | Escalate | Quarantine, fallback, replay | Supervision/rebalancing |
| Learning | Prompt edits | Health tuning | Post-mission writeback | Evolution chamber |

## Core anatomy of an Operative Cell

```mermaid
flowchart TB
  MC[Mission Contract] --> IR[Cell-IR / Org-IR]
  IR --> O1[AI Operative: Architect]
  IR --> O2[AI Operative: Implementer]
  IR --> O3[AI Operative: Reviewer]
  IR --> DAG[Mission Hypergraph / DAG]
  IR --> CP[Context Packet]
  IR --> POL[Policy + Gate Engine]
  IR --> EVAL[Evaluation Criteria]
  O1 --> LEDGER[Evidence Ledger]
  O2 --> LEDGER
  O3 --> LEDGER
  DAG --> LEDGER
  EVAL --> LEDGER
  POL --> LEDGER
  LEDGER --> RECEIPT[Mission Assurance Receipt]
  LEDGER --> LEARN[Knowledge Writeback]
```

## Platform architecture

```mermaid
flowchart TB
  UI[Mission Control UI] --> IC[Intent Compiler]
  IC --> IR[Org Compiler / Cell-IR]
  IR --> PF[Organization Preflight]
  PF --> RUN[Operative Runtime]
  RUN --> TOOLS[Tool/MCP/Repo/Cloud Connectors]
  RUN --> OBS[Observability Stream]
  RUN --> EVID[Evidence Ledger]
  RUN --> EVAL[Evaluation Service]
  RUN --> MEM[Collective Cognition Fabric]
  EVAL --> GATE[Policy + Human Gates]
  EVID --> REC[Mission Assurance Receipt]
  MEM --> BROKER[Knowledge Broker]
  BROKER --> IR
  EVID --> REPLAY[Replay + Simulation]
  REPLAY --> EVO[Evolution Chamber]
  EVO --> REG[Capability Registry]
  REG --> IR
  OBS --> REL[Self-Maintenance Corps]
  REL --> IC
```

## Mission lifecycle DAG

```mermaid
flowchart LR
  A[Brief / Ticket / Goal] --> B[Intent Contract]
  B --> C[Context Compile]
  C --> D[Select Cell Blueprint]
  D --> E[Preflight Readiness]
  E --> F[Launch Operative Cell]
  F --> G[Execute Mission Graph]
  G --> H[Collect Evidence]
  H --> I[Evaluate RED→GREEN]
  I --> J{Gate}
  J -->|Reject| K[Rework / Fork / Escalate]
  K --> G
  J -->|Approve| L[Deploy / Merge / Deliver]
  L --> M[Assurance Receipt]
  M --> N[Post-Mission Learning]
  N --> O[Update Registry / Knowledge]
```

## Collective Cognition Fabric

```mermaid
flowchart TB
  M1[Mission Logs] --> P[Provenance Layer]
  M2[Code Diffs] --> P
  M3[Test Evidence] --> P
  M4[Human Decisions] --> P
  P --> K[Knowledge Broker]
  K --> R[Retrieval Policy]
  K --> C[Contradiction Resolver]
  K --> O[Ontology / Concepts]
  K --> S[Stale-Knowledge Scanner]
  R --> CP[Context Packets]
  C --> CP
  O --> CP
  S --> CP
  CP --> Cells[Future Operative Cells]
```

## Evaluation and certification loop

```mermaid
flowchart TB
  V[Versioned Cell Blueprint] --> S[Simulated / Replay Missions]
  S --> E[Eval Harness]
  E --> R[Result: pass/fail/cost/risk]
  R --> C{Certification Gate}
  C -->|Fail| D[Quarantine + Learn]
  C -->|Pass| P[Certified Registry]
  P --> L[Production Launch]
  L --> O[Outcome Telemetry]
  O --> S
```

## Shadow Twin organization

```mermaid
flowchart LR
  M[Same Mission Contract] --> Live[Primary Operative Cell]
  M --> Shadow[Shadow Twin Cell]
  Live --> LE[Live Evidence]
  Shadow --> SE[Counterfactual Evidence]
  LE --> Compare[Agreement / Disagreement / Cost / Risk]
  SE --> Compare
  Compare --> Promote[Promote, Reject, or Run More Trials]
```

## Self-maintenance loop

```mermaid
flowchart TB
  MON[Monitor platform health] --> ANA[Analyze failures/drift]
  ANA --> PLAN[Plan repair mission]
  PLAN --> COMPILE[Compile maintenance cell]
  COMPILE --> SIM[Simulate / replay candidate fix]
  SIM --> EVAL[Evaluate and gate]
  EVAL --> EXEC[Canary / deploy / rollback]
  EXEC --> KNOW[Knowledge writeback]
  KNOW --> MON
```

## What was innovated in the design session

The strongest new synthesis is the movement from **agent design** to **organization design as a compiled, versioned, measurable artifact**.

Key innovations:

1. **Operative Cell** as the deployable unit rather than the single agent.
2. **ORCA** as a runtime + certification + assurance method.
3. **Mission Assurance Receipt** as client-facing evidence of what ran and why it is trustworthy.
4. **Evolution Chamber** that improves blueprints through replay/simulation before promotion.
5. **Collective Cognition Fabric** with permissioned knowledge promotion, provenance, contradiction handling, and context compilation.
6. **Last-Minute Skill-Up** as pre-mission capability/readiness optimization.
7. **Agent Ghosts / Resurrection Capsules** as persistent, queryable, forkable execution memory.
8. **Meta-tool Compiler** converting repeated agent trajectories into deterministic composite tools.

## Implementation principle

Build trust substrate before autonomy:

```text
Intent Contract → Cell-IR → Mission Graph → Evidence Ledger → Eval Gate → Assurance Receipt
```

Only then add:

```text
Shadow Twin → Evolution Chamber → Self-Maintenance → Federation → Capability Economy
```

# Operative Cell Framework — Artifact Pack

This pack contains a reusable research/design prompt, a proposed technical naming system, implementation blueprint, diagrams, use cases, and a presentation for the Agentic Engineering Platform.

## Recommended terminology

- **AI Operative**: the operator-facing name for one enhanced agent/seat.
- **Operative Cell**: the core technical entity — a mission-bound, versioned, evaluated unit composed of operatives, tools, memory, policies, DAGs, evidence, and gates.
- **ORCA**: **Operative Runtime, Certification & Assurance** — the framework that compiles, runs, evaluates, governs, and improves Operative Cells.
- **Agentic Organization Platform**: the larger platform category / north-star product.

## Files

- `prompts/elite_research_design_prompt.md` — master prompt for GPT/Claude/Deep Research.
- `docs/architecture_and_concepts.md` — technical concept document with diagrams.
- `docs/naming_and_novelty.md` — naming decision and novelty matrix.
- `docs/implementation_blueprint.md` — build plan, services, schemas, gates, and roadmap.
- `docs/use_cases.md` — use cases and organizational presets.
- `docs/visual_diagram_library.md` — reusable Mermaid/ASCII diagrams.
- `schemas/operative_cell.schema.yaml` — seed schema for versioned Operative Cells.
- `web/operative_cell_framework.html` — interactive one-page overview.
- `presentation/ORCA_Operative_Cell_Framework.pptx` — slide deck.
- `research/source_register.md` — source and prior-art register.

## How to use this pack

1. Give the full pack to the next research/design session.
2. Start with `prompts/elite_research_design_prompt.md`.
3. Attach your repo/docs zip and ask the model to produce the north-star architecture, implementation pack, and a scored feature roadmap.
4. Use the presentation to explain the framework to collaborators.

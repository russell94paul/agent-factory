# Naming and Novelty Decision

## Decision

**AI Operative** is a strong operator-facing term, but it is not enough as the main technical entity name.

Use this stack:

| Layer | Recommended term | Purpose |
|---|---|---|
| Individual worker | **AI Operative** | A role-bound, tool-authorized, evaluated AI worker. Better than “agent” for product language. |
| Deployable unit | **Operative Cell** | The core technical entity: one or more operatives plus contracts, tools, memory, DAG, evidence, policies, and gates. |
| Framework | **ORCA** — Operative Runtime, Certification & Assurance | The runtime and assurance framework that compiles, runs, evaluates, governs, and improves Operative Cells. |
| Platform category | **Agentic Organization Platform** | The larger category: an operating system for synthetic organizations. |
| Internal representation | **Cell-IR / Org-IR** | Versioned intermediate representation for cells, teams, armies, and organizations. |

## Why not just “AI Operative”?

An AI Operative describes an enhanced agent. Your larger innovation is not only the worker. It is the **mission-bound organization unit** that can be versioned, evaluated, replayed, certified, compared, and improved.

A normal agent can act. An AI Operative can act with stronger identity, role, tools, context, and metrics. An Operative Cell can **coordinate, prove, recover, and learn**.

## Core definition

> **Operative Cell**: A mission-bound, versioned, evidence-producing synthetic organization unit composed of one or more AI Operatives, deterministic tools, mission contracts, context packets, memory policy, typed mission graph, evaluation criteria, governance gates, observability, cost budgets, recovery plans, and post-mission learning.

## Novelty matrix

| Concept | Novelty rating | Why it matters | MVP status |
|---|---:|---|---|
| AI Operative | Medium | Stronger naming and identity layer for enhanced agents. | Use now |
| Operative Cell | High | Reframes the atomic unit from “agent” to certified mission organization. | Build now |
| ORCA Framework | High | Combines runtime, certification, assurance, and improvement loops. | Build now |
| Org-IR / Cell-IR | High | Makes teams and org forms inspectable, diffable, versioned, and testable. | Build now |
| Mission Hypergraph | High | Upgrades static DAGs into typed missions with artifacts, dependencies, evidence, and capabilities. | Build now |
| Mission Assurance Receipt | High | Turns agent execution into auditable, client-visible trust evidence. | Build now |
| Collective Cognition Fabric | High | Shared permissioned memory with provenance, contradiction handling, and promotion rules. | Build now |
| Shadow Twin Organization | High | Lets new org designs compete safely against live production workflows. | Build next |
| Evolution Chamber | Medium-High | Lab for evolving prompts, tools, workflows, and org topology. | Lab after evals |
| Last-Minute Skill-Up | Medium-High | Pre-mission readiness optimization based on mission requirements and agent health. | Prototype |
| Agent Ghosts | Medium-High | Completed sessions become queryable, provenance-rich knowledge objects. | Build next |
| Resurrection Capsules | Medium-High | Persistent, forkable session state for agentic engineering. | Build next |
| Temporal Echelons | Medium | Separates real-time, tactical, sprint, and strategic operatives. | Later |
| Meta-tool Compiler | High | Converts repeated agent tool paths into cheaper deterministic tools. | Build after traces |
| Bounded Self-Hosting Reconciliation | High | Lets the platform maintain itself without unsafe autonomous mutation. | Build after assurance |

## Recommended terminology in docs

Use **agent** only for generic prior art and simple autonomous actors.

Use **AI Operative** for a single enhanced role seat.

Use **Operative Cell** for the deployable runtime unit.

Use **Army** or **Organization** for multiple cells coordinated across missions/domains.

Use **ORCA** for the framework and engineering method.

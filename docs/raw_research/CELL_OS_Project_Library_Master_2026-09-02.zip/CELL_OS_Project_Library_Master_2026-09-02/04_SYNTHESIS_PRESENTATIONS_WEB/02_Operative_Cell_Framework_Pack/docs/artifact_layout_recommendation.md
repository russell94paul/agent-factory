# Recommended Artifact Layout

## Best communication stack

Use three layers, not one giant artifact.

| Artifact | Role | Audience |
|---|---|---|
| Master research/design prompt | Boots future GPT/Claude/research sessions with complete intent and output requirements. | AI sessions, research collaborators |
| Interactive HTML overview | Fast explainer for the concept, naming, anatomy, runtime, mission DAG, novelty and roadmap. | stakeholders, collaborators, product review |
| Slide deck | Narrative walkthrough: why agents are not enough, what Operative Cells are, how ORCA works, and what to build first. | presentations, onboarding, pitches |
| Technical markdown docs | Durable implementation plan, diagrams, schemas, use cases, novelty matrix. | engineers, future sessions |
| Schema pack | Turns the concept into implementation constraints. | engineering |

## Recommended webpage structure

```text
Hero: From Agents to Operative Cells
↓
Naming verdict: AI Operative vs Operative Cell vs ORCA
↓
Interactive anatomy: click each cell component
↓
Runtime map: mission control → compiler → runtime → evidence → evolution
↓
Mission DAG: brief → contract → context → preflight → run → evidence → gate → receipt
↓
Novel concepts: ranked cards
↓
Use-case presets: migration, triage, research, reliability, knowledge
↓
Implementation roadmap
↓
Download / handoff artifacts
```

## Recommended document structure

```text
00 Executive summary
01 Naming and ontology
02 Core framework: ORCA + Operative Cell
03 Architecture
04 Theory and prior art
05 Novel concepts and novelty analysis
06 Agent vs Operative vs Cell vs Army comparison
07 Use cases and organizational presets
08 Evaluation and certification
09 Implementation roadmap
10 UI / webpage / product experience
11 Appendices: schemas, diagrams, prompts, backlog
```

## Recommended deck structure

```text
1. Title: From Agents to Operative Cells
2. Naming verdict
3. What makes an Operative Cell different?
4. ORCA platform map
5. Mission lifecycle DAG
6. Collective Cognition Fabric
7. Certification and assurance
8. Shadow Twin + Evolution Chamber
9. Novel concepts worth highlighting
10. Use-case presets
11. How to use the artifact pack
12. Recommended build sequence
```

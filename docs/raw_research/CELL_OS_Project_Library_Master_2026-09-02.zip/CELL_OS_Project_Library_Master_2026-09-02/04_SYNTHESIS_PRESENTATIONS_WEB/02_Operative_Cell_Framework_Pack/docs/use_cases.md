# Use Cases and Organizational Presets

## Use-case map

| Use case | Best cell topology | Primary metrics | MVP? |
|---|---|---|---|
| Connector migration | Factory-line cell + specialist inserts | time-to-green, parity pass, cost/change | Yes |
| Incident triage | Rapid response swarm | MTTR, diagnosis precision, rollback rate | Yes |
| Data quality guardian | Persistent watcher + investigator | alert precision, data downtime, recurrence | Yes |
| API integration pod | Archaeologist + auth + implementer + verifier | time-to-first-data, regression rate | Yes |
| Codebase refactor | Planner + scoped implementers + reviewer | diff safety, test pass, review rework | Next |
| Product/UI studio | Researcher + designer + implementer + evaluator | usability pass, iteration count | Next |
| Knowledge stewardship | Curator + ontology + contradiction resolver | retrieval utility, freshness, provenance | Next |
| Research compiler | Scout + skeptic + mapper + experiment designer | evidence quality, useful ADRs, novelty risk | Yes |
| Factory self-maintenance | Reliability Corps | MTTR, platform uptime, safe fallback | Next |
| Autonomous business operator | Multi-domain operating org | profit, SLA, support load, risk | Lab |

## Preset 1 — Migration Factory Line

```mermaid
flowchart LR
  A[Preflight] --> B[Analyze Connector]
  B --> C[Create Flow]
  C --> D[Local Tests]
  D --> E[PR]
  E --> F[Deploy]
  F --> G[Fresh Landing]
  G --> H[Parity Check]
  H --> I[Promote]
```

Good for repetitive, evidence-heavy software migration.

## Preset 2 — Rapid Response Swarm

```mermaid
flowchart TB
  I[Incident] --> C[Incident Commander]
  C --> D1[Diagnostician A]
  C --> D2[Diagnostician B]
  C --> D3[Historical Case Specialist]
  D1 --> S[Synthesis]
  D2 --> S
  D3 --> S
  S --> R[Repair Cell]
  R --> E[Eval + Gate]
  E --> P[Patch / Rollback]
```

Good for ambiguous failures where parallel diagnosis reduces time-to-root-cause.

## Preset 3 — Knowledge Stewardship Guild

```mermaid
flowchart LR
  Logs[Mission Evidence] --> Curator[Curator]
  Docs[Research Docs] --> Curator
  Curator --> Ont[Ontology Agent]
  Curator --> Contra[Contradiction Resolver]
  Curator --> Prov[Provenance Auditor]
  Ont --> Graph[Collective Cognition]
  Contra --> Graph
  Prov --> Graph
```

Good for preventing memory from becoming a hallucination amplifier.

## Preset 4 — Research Compiler

```mermaid
flowchart TB
  Q[Research Question] --> D[Decompose]
  D --> A[Academic Scout]
  D --> B[Implementation Scout]
  D --> C[Adversarial Scout]
  D --> O[Org Science Scout]
  A --> N[Normalize Claims]
  B --> N
  C --> N
  O --> N
  N --> M[Map to Architecture]
  M --> X[Experiments]
  X --> ADR[ADRs + Backlog]
  ADR --> K[Knowledge Writeback]
```

Good for turning research into machine-ingestible architecture decisions.

## Preset 5 — Factory Reliability Corps

```mermaid
flowchart TB
  H[Health Signals] --> T[Triage Operative]
  T --> F[Failure Classifier]
  F --> Q[Quarantine / Fallback]
  F --> R[Repair Mission Compiler]
  R --> S[Simulate Fix]
  S --> G[Human/Policy Gate]
  G --> C[Canary]
  C --> K[Knowledge Writeback]
```

Good for self-maintenance without unsafe autonomous self-editing.

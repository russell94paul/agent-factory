# Source Register

## Project grounding

- Agent Factory Vision supplied in project context: argues for Agent Factory as the first production proving ground inside a larger Agentic Organization OS, with hybrid platform monorepo + federated workload repos, Org-IR, Collective Cognition, Research Army, Evolution Chamber, and self-maintenance loops.
- Agent Factory Frontier Architecture Prioritization Pack: prioritizes Mission Hypergraph, Constitutional Institution / Type System, Shadow Twin, Collective Cognition, and Bounded Self-Hosting Reconciliation as P0 foundations.
- Agent Management Terminal research: introduces persistent/forkable agent execution environments, terminal genomes, resurrection capsules, session ghosts, and time-travel debugging.

## External prior art anchors

- ADAS — Automated Design of Agentic Systems. ICLR 2025. https://arxiv.org/abs/2408.08435
- EvoAgent — automatic multi-agent generation via evolutionary algorithms. NAACL 2025. https://aclanthology.org/2025.naacl-long.315/
- Agent Workflow Optimization / Meta-tools. Microsoft Research, 2026. https://www.microsoft.com/en-us/research/publication/optimizing-agentic-workflows-using-meta-tools/
- NIST AI RMF Generative AI Profile. https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence
- Kubernetes controllers — desired/current state reconciliation. https://kubernetes.io/docs/concepts/architecture/controller/
- Erlang/OTP supervision trees — fault containment and recovery. https://www.erlang.org/doc/system/sup_princ.html
- MAPE-K / autonomic computing — Monitor, Analyze, Plan, Execute over Knowledge.

## Accuracy note on shared ChatGPT URL

The shared ChatGPT link exposed only the page shell/title during review, not the detailed content. Treat that linked session as unverified until its content is pasted, exported, or attached.

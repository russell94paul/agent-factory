# Source pointer

`raw_research.zip` was intentionally not duplicated here. The untouched archive is stored at `99_ORIGINAL_SOURCE_ARCHIVES/root/raw_research.zip`.

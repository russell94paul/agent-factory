# Pack Catalog

| Category | Pack / artifact | Why it is here | Type |
|---|---|---|---|
| UI / Product Design | agent_factory_army_ui_concept_pack | Command console, Army UI, organizational interaction concepts | Source research/design pack |
| UI / Product Design | agent_factory_chat_design_pack | Chat/session design consolidation; serious Agentic IDE plus alternate command-world projection | Source design pack |
| UI / Product Design | zeus-switchboard-redesign-pack | Standalone Switchboard operator-console implementation/prototype | Prototype/source pack |
| UI / Product Design | zeus_world_ui_research_pack | Spatial/gamified operational interface research and renderer experiments | Research-only |
| Research | agent-config-research-pack | Versioned agent/team configuration compiler, capability registry, mission matching and metrics | Research/design pack |
| Research | agent_factory_agents_as_configuration_research_pack | Agents-as-configuration, health, readiness, conditioning, matching, outcome learning | Research/design pack |
| Research | agent_factory_agent_genome_research_pack | Agent genome, communication, relationship dynamics, simulation and evolution research | Research/design pack |
| Research | agent2_sihre_consolidation_pack | SIHRE / cognitive-entity / Agent 2.0 research and recursive intelligence concepts | Research consolidation |
| Research | agent_factory_rd_consolidation_pack | R&D consolidation across architecture, HyperMESH, optimization, self-learning and self-hosting | Research consolidation |
| Research | Beyond_Agent_Armies_Frontier_Architectures | Frontier organizational architectures, recursive/federated/institutional/evolutionary/cybernetic patterns | Frontier research document |
| Research | Agent_Factory_Frontier_Architecture_Prioritization_Pack | Prioritization of frontier architectures against business value, trust and implementation readiness | Decision/prioritization document |
| Architecture Development | agent-factory-bootstrap-pack | Non-destructive research + architecture overlay, corpus, concepts, evidence, decisions and implementation seeds | Architecture bootstrap |
| Architecture Development | agent-factory-combined-execution-research-pack-v2-2026-09-02 | Execution surface routing, DAG/runtime and deadline-oriented orchestration research | Execution architecture pack |
| Architecture Development | agent-factory-deadline-execution-pack-2026-09-02 | Deadline vertical-slice execution plan and Agentic IDE runtime controls | Execution architecture pack |
| Architecture Development | Agent Factory Vision.txt | North-star platform monorepo + federated workload estate; synthetic organization OS framing | Vision/source |
| Synthesis / Presentation / Web | agentic_ai_concepts_pack | Frontier concepts synthesis, master prompt, presentation and interactive HTML | Generated synthesis output |
| Synthesis / Presentation / Web | operative_cell_framework_pack | Operative/Cell architecture synthesis, implementation blueprint, diagrams, presentation and HTML | Generated synthesis output |

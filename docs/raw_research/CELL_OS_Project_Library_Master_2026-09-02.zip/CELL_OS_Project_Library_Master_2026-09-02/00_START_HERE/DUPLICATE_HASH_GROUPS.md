# Duplicate Hash Groups — Readable Library

No files were deleted based on this report. Exact duplicates can be intentional evidence/provenance artifacts.

Exact duplicate hash groups: **31**

## Group 1 — 6 files
`f4dacee07247e4688e80f11f8dd714d32c162e75ba4f885cc0aa6c3259bd3849`

- `02_RESEARCH/02_Agents_As_Configuration/agent_factory_agents_as_configuration_research_pack/06_SOURCE_MATERIAL/Agent Factory Vision.txt`
- `02_RESEARCH/03_Agent_Genome_Communication_Simulation/agent_factory_agent_genome_research_pack/source/Agent Factory Vision.txt`
- `03_ARCHITECTURE_DEVELOPMENT/05_North_Star_Vision/Agent Factory Vision.txt`
- `03_ARCHITECTURE_DEVELOPMENT/01_Bootstrap_Corpus_Architecture/agent-factory-bootstrap-pack/docs/01-research-corpus/raw/source-snapshots/Agent Factory Vision.txt`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/Agent Factory Vision.txt`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/sources/Agent Factory Vision.txt`

## Group 2 — 3 files
`0858defefadb9605172376e737e99b84f3f72e9474ec8ecb592dc18f43389237`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/05_EVALUATION_PROTOCOL.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/05_EVALUATION_PROTOCOL.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/05_EVALUATION_PROTOCOL.md`

## Group 3 — 3 files
`2171ac05adefec5022a9ecbea57fbd290292502196c2cb10e85f4084d906de68`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/02_EXTREME_EXPERIMENTS.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/02_EXTREME_EXPERIMENTS.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/02_EXTREME_EXPERIMENTS.md`

## Group 4 — 3 files
`22930308b93722b042081bb648b156a63e8e5c1376a61577dbbcec9b03a162c7`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/README.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/README.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/README.md`

## Group 5 — 3 files
`279a1566935039a4af7b5b8b0cb117915ece10116b61eee6c45a6d8e9a326c4c`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/ZEUS_World_UI_Research_Pack_standalone.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/ZEUS_World_UI_Research_Pack.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/ZEUS_World_UI_Research_Pack.md`

## Group 6 — 3 files
`2b70a661949a82ed2c477318239071e2d5eff816744a9433b57bd973440041c5`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/03_BUSINESS_VALUE_CONCEPTS.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/03_BUSINESS_VALUE_CONCEPTS.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/03_BUSINESS_VALUE_CONCEPTS.md`

## Group 7 — 3 files
`2ccc6c4eb4b0f324e013e7c617d621b92094cc10a91b38fb3f2ef28405ca1a98`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/07_TECHNICAL_OPTIONS.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/07_TECHNICAL_OPTIONS.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/07_TECHNICAL_OPTIONS.md`

## Group 8 — 3 files
`5335ecf004980af3ac5503c5e61ee6d02ea439072aed2cccded450a87ee08b71`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/00_BASELINE_AND_DOCTRINE.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/00_BASELINE_AND_DOCTRINE.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/00_BASELINE_AND_DOCTRINE.md`

## Group 9 — 3 files
`5bac1e2c15f05f4604dfc4e441da5b7a18e641d0f02930fbe33342f4d7cded11`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/SOURCES.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/SOURCES.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/SOURCES.md`

## Group 10 — 3 files
`8a78f0feb8febaecb9490e854b4ea7eb15054a498fbeb11b36721317938cc7d5`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/08_RESEARCH_PROMPTS.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/08_RESEARCH_PROMPTS.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/08_RESEARCH_PROMPTS.md`

## Group 11 — 3 files
`990fd2f77577db67c22ae7c1df898baec4ae575e47236563a628bf6a2f4802bc`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/04_AGENTIC_RESEARCH_PROGRAM.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/04_AGENTIC_RESEARCH_PROGRAM.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/04_AGENTIC_RESEARCH_PROGRAM.md`

## Group 12 — 3 files
`aaec92b6400029d6f7764a7f60959f1509202ce17d7036de171a14e433d0c283`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/01_REFERENCE_SYSTEMS.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/01_REFERENCE_SYSTEMS.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/01_REFERENCE_SYSTEMS.md`

## Group 13 — 3 files
`d90fb7c9a9243b334310d0a90ff9de16d3d9f087f280f512d80dda1b90884de9`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/09_IMPLEMENTATION_READINESS.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/09_IMPLEMENTATION_READINESS.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/09_IMPLEMENTATION_READINESS.md`

## Group 14 — 3 files
`f308fd91898ea19c7405b4cd5acaa9ef0019c6e697f6f2ee8b26c0c3d8f540aa`

- `01_UI_PRODUCT_DESIGN/04_Spatial_World_Experimental/zeus_world_ui_research_pack/06_STATE_AND_INTERACTION_MODEL.md`
- `01_UI_PRODUCT_DESIGN/02_Chat_Session_Interaction/agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/06_STATE_AND_INTERACTION_MODEL.md`
- `01_UI_PRODUCT_DESIGN/01_Command_Console_Army_UI/agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/06_STATE_AND_INTERACTION_MODEL.md`

## Group 15 — 2 files
`031778bc748899106bb0ad37d85ea4b453c05486f006cbba51b23a579c8f55ce`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/09_TRACEABILITY/SOURCE_MAP.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/09_TRACEABILITY/SOURCE_MAP.md`

## Group 16 — 2 files
`0ece967fbe69a192b3eaaf32ef9e57ea22af82f75469f06fb59482ef40ee0b3e`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/03_EXECUTION/autonomy_policy.yaml`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/03_EXECUTION/autonomy_policy.yaml`

## Group 17 — 2 files
`1dbb7ce38aa8661624510b8142521aaad2e7a444dc2a2687f442ce586404a731`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/03_EXECUTION/tonight_dag.yaml`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/03_EXECUTION/tonight_dag.yaml`

## Group 18 — 2 files
`28543dc09b0c0a4d43eba0184930944adfb25fede1459cef3295c8a2a61b754a`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/03_EXECUTION/execution_mandate.example.yaml`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/03_EXECUTION/execution_mandate.example.yaml`

## Group 19 — 2 files
`30b4b30b96cf1718ff1d64bbab331ac0320964d18db85765d35fa47357c0a0c8`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/02_DEADLINE/TONIGHT_CRITICAL_PATH.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/02_DEADLINE/TONIGHT_CRITICAL_PATH.md`

## Group 20 — 2 files
`47e18d4acf2df1897622487c4d93379c67f95898257c70014f7b6da38287ece8`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/07_CLAUDE/PARALLEL_LANE_PROMPTS.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/07_CLAUDE/PARALLEL_LANE_PROMPTS.md`

## Group 21 — 2 files
`5623980133099216f4a97711a94de61c2b7a281ab5490e124151dc408db5705d`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/06_EVALS/sales_model_eval.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/06_EVALS/sales_model_eval.md`

## Group 22 — 2 files
`6cb8e49d924cdccc60bd0dad5738e368dc8bbbc5766b057e0ba1c50f97f27b48`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/04_MISSIONS/sales_model.yaml`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/04_MISSIONS/sales_model.yaml`

## Group 23 — 2 files
`70632328adee56d4c57309c2ddaad5a5322e4f050c6c9aa3920efa578cf92d86`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/05_SWITCHBOARD/P0_FUNCTIONAL_SPEC.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/05_SWITCHBOARD/P0_FUNCTIONAL_SPEC.md`

## Group 24 — 2 files
`72e0b4af6c136c974520e2b6d17135af3601d8f111879a43923bb757a27177df`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/05_SWITCHBOARD/AUTONOMY_PUMP_DESIGN.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/05_SWITCHBOARD/AUTONOMY_PUMP_DESIGN.md`

## Group 25 — 2 files
`8c3aefcaf2ee547c9b1b1a8d770a33d207de532e98f265cb294a4e00cdd28bf0`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/07_CLAUDE/SLASH_COMMAND_CONTRACT.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/07_CLAUDE/SLASH_COMMAND_CONTRACT.md`

## Group 26 — 2 files
`a3a6a037d332b453d1303bfc5f5f40bcec466177dee8ed28bd25bbd67a1fec56`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/01_DECISIONS/DECISION_REGISTER.yaml`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/01_DECISIONS/DECISION_REGISTER.yaml`

## Group 27 — 2 files
`a9b7a40e16abd4cbbde9fe69a32a125e0dfd2b72d4ed726d701a1a0f485bcc71`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/06_EVALS/marketing_model_eval.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/06_EVALS/marketing_model_eval.md`

## Group 28 — 2 files
`dbf1bdb24fbdab0ad7a712301077e31525274dfd0e848cfc68bce0b42a1de8a9`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/02_DEADLINE/FALLBACKS.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/02_DEADLINE/FALLBACKS.md`

## Group 29 — 2 files
`ef60cdc3de5ef1e5e29690c98aebfb4623f35f4f0373f840af8de6706ec4b620`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/01_DECISIONS/ARCHITECTURE_SYNTHESIS.md`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/01_DECISIONS/ARCHITECTURE_SYNTHESIS.md`

## Group 30 — 2 files
`f3761006e448ee89f96bd8c2cccaab675d27c2705593eefa7f2528ed00f9d300`

- `03_ARCHITECTURE_DEVELOPMENT/03_Deadline_Execution/agent-factory-deadline-execution-pack-2026-09-02/04_MISSIONS/marketing_model.yaml`
- `03_ARCHITECTURE_DEVELOPMENT/02_Execution_Orchestration/agent-factory-combined-execution-research-pack-v2-2026-09-02/04_MISSIONS/marketing_model.yaml`

## Group 31 — 2 files
`f5f3ff099a32e362c28c36a2f771b0b641d95f58d05b5d4a41a2c3a3fe560d57`

- `02_RESEARCH/01_Agent_Configuration/agent-config-research-pack/06-claude-context-pack-prompt.md`
- `03_ARCHITECTURE_DEVELOPMENT/04_Context_Handoff/06-claude-context-pack-prompt.md`

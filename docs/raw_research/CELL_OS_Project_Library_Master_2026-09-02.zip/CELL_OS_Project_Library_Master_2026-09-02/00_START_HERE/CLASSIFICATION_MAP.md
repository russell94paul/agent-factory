# Classification rationale

## UI / Product Design
Contains interaction models, operator surfaces, Switchboard/NERVE predecessors, chat/session UX, spatial/gamified projections, and runnable UI prototypes.

## Research
Contains conceptual exploration, prior art, agent configuration/genome/cognition research, SIHRE work, R&D synthesis and frontier organization patterns.

## Architecture Development
Contains repository/bootstrap structures, execution/runtime/DAG designs, implementation sequencing, context handoff, and the north-star platform vision.

## Synthesis / Presentations / Web
Contains higher-level artifacts generated from the corpus for explanation, presentation, product walkthrough and interactive exploration. These are useful outputs, but they should not outrank source/repository evidence simply because they are polished.

## Original Source Archives
Untouched ZIPs for provenance and reconstruction. These intentionally duplicate material represented in the readable folders.

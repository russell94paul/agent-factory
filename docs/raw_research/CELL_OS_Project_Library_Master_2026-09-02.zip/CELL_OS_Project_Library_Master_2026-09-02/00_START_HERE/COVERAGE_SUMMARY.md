# Coverage Summary

- **01_UI_PRODUCT_DESIGN**: 94 files, 663,635 bytes
- **02_RESEARCH**: 107 files, 1,095,806 bytes
- **03_ARCHITECTURE_DEVELOPMENT**: 96 files, 238,470 bytes
- **04_SYNTHESIS_PRESENTATIONS_WEB**: 40 files, 3,030,996 bytes
- **99_ORIGINAL_SOURCE_ARCHIVES**: 16 files, 6,422,465 bytes

- **Readable duplicate groups:** 31
- **Nested ZIPs preserved:** 13

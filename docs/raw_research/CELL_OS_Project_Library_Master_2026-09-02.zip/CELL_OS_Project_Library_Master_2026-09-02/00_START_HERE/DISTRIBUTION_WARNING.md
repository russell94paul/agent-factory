# Distribution Warning

This is a project-internal research and development corpus. Do not publish or push the master ZIP to a public repository without a dedicated leak/sanitization pass.

Reasons:

- legacy source packs can include client/project names or operational context;
- one included legacy Switchboard source file contains `Navira`;
- prior architecture-review pack generation elsewhere in the project explicitly found client-identifying terms and was intentionally gitignored.

The archive has been organized, **not sanitized**.

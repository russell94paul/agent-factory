# CELL OS — Consolidated Project Library

**Build date:** 2026-09-02

This archive reorganizes the project material available in the active workspace into a single navigable library. It preserves original source archives while creating one readable canonical placement for each extracted pack.

## Recommended entry points

1. `03_ARCHITECTURE_DEVELOPMENT/05_North_Star_Vision/Agent Factory Vision.txt` — north-star framing.
2. `02_RESEARCH/06_Frontier_Architecture_Research/` — frontier organizational patterns and prioritization.
3. `02_RESEARCH/01_Agent_Configuration/` through `05_RnD_Consolidation/` — agent/operative, configuration, genome, cognition and R&D research.
4. `01_UI_PRODUCT_DESIGN/` — Switchboard/NERVE predecessors, chat/session interaction and spatial-command research.
5. `03_ARCHITECTURE_DEVELOPMENT/` — bootstrap, execution/DAG and deadline architecture work.
6. `04_SYNTHESIS_PRESENTATIONS_WEB/` — presentation-ready synthesis and interactive HTML outputs.

## Folder model

```text
CELL_OS_Project_Library_Master_2026-09-02/
├── 00_START_HERE/
├── 01_UI_PRODUCT_DESIGN/
├── 02_RESEARCH/
├── 03_ARCHITECTURE_DEVELOPMENT/
├── 04_SYNTHESIS_PRESENTATIONS_WEB/
└── 99_ORIGINAL_SOURCE_ARCHIVES/
```

## Preservation policy

- Extracted folders are reorganized for navigation; source files are copied without editing.
- Original ZIP archives are retained in `99_ORIGINAL_SOURCE_ARCHIVES/`.
- No automatic content-level de-duplication was performed. This is intentional: prior project audits noted that some byte-identical evidence files can be meaningful negative controls, so deleting duplicates blindly can destroy evidence semantics.
- The `agentic_ai_concepts_pack` contained another copy of `raw_research.zip`; that nested copy is omitted from the readable synthesis tree only because the untouched generated ZIP and the canonical raw archive are both preserved in `99_ORIGINAL_SOURCE_ARCHIVES/`.

## Important coverage note

ChatGPT File Library indexing also exposes newer CELL OS artifacts that are **not binary-mounted into this active workspace**. They are catalogued in `LIBRARY_ONLY_REFERENCES.md` rather than falsely claiming they were embedded.

## Distribution warning

Treat this archive as **internal/private** until it has been sanitized. At least one legacy UI implementation contains the string `Navira`, and previous architecture-review material elsewhere in the project was explicitly flagged as carrying client-identifying terms.

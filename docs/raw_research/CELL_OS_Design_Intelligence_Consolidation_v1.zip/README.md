# CELL OS — Design Intelligence Consolidation v1

## Purpose

This pack consolidates the strongest product-design, UX, UI-layout, motion, interaction,
dashboard/data-visualization, agentic-IDE, human-swarm, NERVE/Switchboard, and Operative Cell
builder concepts found across the supplied CELL OS / Agent Factory design corpus.

It is designed to be attached **alongside the original artifacts** when working with Claude Design.

## Important scope note

This is a **curated synthesis**, not a byte-for-byte re-bundle of every original File Library ZIP.
The original library archives are not mounted as raw files in this runtime. Where an original pack
could be reviewed through its indexed/extracted content, its decisions have been reconciled here.
The locally available `Agent Factory Vision.txt` is included under `references/`.

## Current product hierarchy to preserve

```text
CELL OS
└── Switchboard                         # sole current top-level product tab
    └── NERVE operator experience       # high-frequency supervisory shell / mode
        ├── Today
        ├── Inbox
        ├── Missions
        ├── Automations
        ├── Artifacts
        ├── Knowledge
        ├── Intelligence
        └── Systems

Contextual workspaces opened from objects:
- Mission Control
- Briefing Room
- Cell Studio
- Replay / Profiler
- Evidence / Assurance
- Shadow Twin Compare
- Evolution / The Crucible
```

If future canonical artifacts explicitly rename Switchboard or redefine the relationship to NERVE,
use the newest explicit product decision. Do not invent peer top tabs.

## Design north star

CELL OS should feel like an operating system for synthetic organizations, not a wrapper around chat.
The user should be able to:

**express intent → compile a bounded Operative Cell → execute → supervise → intervene → verify with
evidence → replay → learn → evolve**

The premium quality comes from reducing coordination and cognitive load, not from visual spectacle.

## Reading order

1. `00_SOURCE_PRIORITY_AND_RECONCILIATION.md`
2. `01_CANONICAL_DESIGN_DOCTRINE.md`
3. `02_INFORMATION_ARCHITECTURE_AND_LAYOUT.md`
4. `03_COMPONENT_AND_INTERACTION_GRAMMAR.md`
5. `04_MOTION_MICROINTERACTION_AND_EFFECTS.md`
6. `05_DATA_VISUALIZATION_AND_METRICS.md`
7. `06_FEATURE_CATALOG.md`
8. `07_CELL_STUDIO_OPERATIVE_BUILDER.md`
9. `08_NERVE_DESKTOP_MOBILE.md`
10. `09_DESIGN_REVIEW_SCORECARD.md`
11. `10_CLAUDE_DESIGN_MASTER_PROMPT.md`

## Hard rules

- Attention > activity.
- Agent narrative is not evidence.
- Done != Verified Success.
- Preserve work-state, runtime-state and assurance-state distinctions.
- Autonomous events must never steal typing focus.
- Preserve scroll position, selection, drafts and spatial memory.
- Tooltips may supplement; critical information cannot be hover-only.
- Motion must communicate orientation, causality, state, continuity or feedback.
- Semantic colors are reserved for meaning.
- No permanent wall of KPI cards.
- Use graph/canvas views only when topology/dependency is actually the question.
- Advanced depth belongs in a consistent inspector and contextual workspace.
- Mobile is purpose-built for supervision, not a shrunken terminal.

# Component & Interaction Grammar

## Universal command surface

One command model across keyboard, mouse, text and voice.

Modes:
- Navigate
- Ask
- Create
- Delegate
- Act

Supports:
- natural language
- slash commands
- `@` object references
- attachments
- scope chips
- repo/environment/mission context
- push-to-talk
- action preview before side effects

## Inspector

The right inspector is the product's most consistent advanced interaction pattern.

Typical sections:
- Summary
- State
- Evidence
- Context
- Relations
- Authority / permissions
- Resources / cost
- Versions
- Actions
- Provenance

## Overlay hierarchy

- Tooltip: short supplemental info only
- Popover: compact metadata / quick actions
- Inspector: deep properties / relations / evidence / actions
- Modal: bounded synchronous form
- Consequence Sheet: high-risk decision workspace
- Command Palette: navigation / search / create / act

No stacked modals.

## Key reusable components

- App shell
- Left rail
- Top bar
- Universal command composer
- Command palette
- Attention Strip
- Attention Inbox item
- Mission card
- Session card
- Operative card
- Cell card
- WorkGraph ticket/node
- State badge
- Assurance/Evidence badge
- Resource pressure meter
- Decision card
- Consequence Sheet
- Approval controls
- Context chip / capsule
- Inspector
- Tooltip / popover
- Contextual tabs
- Dense table
- Timeline
- Replay scrubber
- Diff viewer
- Artifact preview / version stack
- Topology canvas
- Metric block
- Sparkline
- Pareto plot
- Toast / inline error
- Skeleton
- Voice overlay
- Mobile bottom nav
- Run Dock

## Hover

Purpose: reveal secondary detail without layout shift.

Preferred:
- small border-contrast increase
- tiny surface-lightness increase
- reveal trailing quick actions
- cursor affordance
- subtle shadow refinement

Avoid:
- scale-up
- card lift
- continuous glow
- critical hover-only content

Hover preview may be pinned by click.

## Selection

- Ion Blue indicator/hairline
- subtle surface differentiation
- binds inspector
- selection persists when changing related views

## Press

Small tactile fill/shadow compression. No dramatic transform.

## Tabs

Preserve:
- selected object
- filters
- drafts
- reasonable scroll position

Motion:
- 140–220ms
- small active-indicator movement
- optional 80–140ms crossfade
- no large slide on every switch

## Consequence Sheet

For high-risk actions show:
- requested action
- requester
- reason
- affected systems
- namespace/environment
- cost/resource impact
- evidence prerequisites
- reversible/irreversible state
- rollback
- approve / modify / deny

Never reduce this to a generic "Are you sure?".

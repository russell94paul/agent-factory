# Information Architecture & Layout

## Global hierarchy

```text
CELL OS
└── Switchboard
    └── NERVE
        ├── Today
        ├── Inbox
        ├── Missions
        ├── Automations
        ├── Artifacts
        ├── Knowledge
        ├── Intelligence
        └── Systems
```

## Contextual workspaces

Opened from the selected object, preserving context:

- Mission Control
- Briefing Room
- Cell Studio
- Operative / Cell Inspector
- Evidence / Assurance
- Replay / Profiler
- Shadow Twin Compare
- Evolution / The Crucible
- Admin / deep system configuration

## Desktop shell

Recommended baseline:

- top bar: 56px
- expanded rail: 232px
- compact rail: 64px
- main canvas: flexible
- right inspector: 320–480px, ~380px default
- optional live Run Dock: ~56px
- three-pane layout from ~1180px+

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ CELL OS / Switchboard     Search / Ask / Command     Health   Mic   Profile │
├──────────────┬───────────────────────────────────────────┬───────────────────┤
│ NERVE RAIL   │                 MAIN CANVAS               │ CONTEXT INSPECTOR │
│ Today        │                                           │ Summary           │
│ Inbox        │                                           │ Evidence          │
│ Missions     │                                           │ Context           │
│ Automations  │                                           │ Relations         │
│ Artifacts    │                                           │ Actions           │
│ Knowledge    │                                           │ Versions          │
│ Intelligence │                                           │                   │
│ Systems      │                                           │                   │
├──────────────┴───────────────────────────────────────────┴───────────────────┤
│ Optional Run Dock: pinned live sessions / Cells                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

## Today

Question: **What needs me, and what changed?**

Zones:
1. Attention Strip — 3–5 highest-consequence items
2. Active Mission Field
3. Since You Were Away
4. Next Events / deadlines / scheduled automations
5. Quiet intelligence strip

## Inbox

Not notifications. A human cognition/authority queue.

Filters:
- Decisions
- Questions
- Approvals
- Failures
- Reviews
- External replies

Every item includes enough adjacent context to decide without opening many pages.

## Missions

Durable outcome container spanning Cells, sessions, runs, artifacts and evidence.

Context tabs:
Overview / WorkGraph / Runs / Artifacts / Evidence / Decisions / Replay

## Automations

Two primary views:
- Library
- Runs

Show trigger, next run, last verified outcome, affected systems, gate profile,
reliability trend and anomalies.

## Artifacts

Preview-first object library with:
version stack, provenance, mission linkage, diff/compare, evidence state.

## Knowledge

Search-first:
trusted claims, procedures, episodes, artifacts, contradictions, stale queue,
suggested context packs.

Graph is secondary and used when provenance/relationship structure is the question.

## Intelligence

Decision-oriented:
Outcomes / Reliability / Economics / Human Load / Cells / Evolution / Knowledge Health.

Avoid KPI walls.

## Systems

Environments, integrations, runtime health, policies, capability registry, permissions,
connectivity and platform diagnostics. Keep deep infrastructure out of the default Today view.

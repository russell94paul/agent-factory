# Motion, Microinteraction & Effects

## Motion roles

Every animation must serve at least one:
1. Orientation
2. Causality
3. Status
4. Continuity
5. Feedback

## Baseline timing tokens

- press: 90ms
- hover: 120ms
- tooltip: 130ms
- popover: 160ms
- tab/menu: 180ms
- inspector: 240ms
- sheet: 260ms
- workspace continuity: 320ms
- complex deliberate visualization: <= 500ms

## State motion

Working → Waiting → Done should morph state treatment **in place**.
Do not reorder cards unless the user explicitly chooses state sorting.

## Event-linked shimmer

Pearl Slate may use a narrow one-time highlight when:
- a mission becomes Verified
- an artifact finishes rendering
- a Cell Image becomes certified

Do not run constant shimmer across dense content.

## Ambient glisten

Allowed only in empty chrome/peripheral background:
- maximum opacity roughly 0.025
- broad / very slow
- pause during typing or scrolling
- disable entirely under reduced-motion preference

## Reduced motion

Remove:
- ambient glisten
- large translations
- scaling choreography

Retain:
- opacity/state changes
- focus/state distinction
- causal clarity

## Prohibited motion

- auto-reorder while reading
- animate every chart on refresh
- pulse idle cards continuously
- moving gradients under dense text
- generic spring physics everywhere
- focus-stealing entrance animation
- motion that blocks input

# Cell Studio — Operative Cell Builder

## Purpose

CELL OS builds **Operative Cells**, so the builder must become a signature product surface.

Do not make the user think in raw YAML or a freeform graph unless they choose to.

## Required configuration

- formation / topology
- Operative seats
- deterministic workers
- model / runtime
- capabilities / tools
- memory mounts
- communication policy
- resource envelope
- authority / gates
- evaluators
- evidence contract
- versions
- certification

## Preferred interaction hypothesis

**Structured canvas + consistent inspector + natural-language builder + generated machine-readable config**

### Canvas

Show the organization shape and flow at the level necessary for comprehension.

### Inspector

Selecting any Operative/worker/edge/gate/memory mount exposes:
role, why it exists, model, context, permissions, cost, evidence, dependencies, versions.

### Natural language

Example:
> Build a low-cost connector migration Cell with one architecture lead, two independent implementers,
> one deterministic regression rail, a security review gate and a human production promotion gate.

The system generates a structured preview. No side effect until accepted.

### Diff-first versioning

Version diff must identify changes to:
- topology
- model
- capabilities
- memory
- budget
- authority
- evals
- evidence contract

## Builder modes to evaluate

1. Freeform node graph
2. Form-first topology editor
3. Structured canvas + inspector
4. Natural-language builder + generated config
5. Hybrid

Default recommendation: **hybrid**, with structured canvas + inspector as the durable visual model.

## Readiness before launch

Show:
- missing capability
- missing context/memory
- budget envelope
- permission conflicts
- evidence contract
- evaluator readiness
- unresolved dependency
- version/certification state

## Accessibility

Every topology/configuration operation must have a non-spatial list/form representation.

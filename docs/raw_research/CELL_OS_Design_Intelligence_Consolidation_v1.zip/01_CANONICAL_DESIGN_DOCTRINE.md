# Canonical Design Doctrine

## Product thesis

CELL OS is an operating system for synthetic organizations. A **Cell** is the primary
executable/certifiable organizational primitive. An **Operative** is a bounded worker inside a Cell.

The interface should let the user move fluently through six modes of understanding:

1. **Glance** — what needs me, what changed, what is risky?
2. **Steer** — what should run, pause, branch, approve, delegate or reroute?
3. **Inspect** — why is this blocked, what context/tools/authority does it have?
4. **Build** — how is this Operative Cell configured and governed?
5. **Verify** — what evidence proves the outcome?
6. **Learn** — which organization/configuration works better and why?

## Primary UX metric

**Human Coordination Load**

Improve:
- verified missions completed
- parallel useful work
- first-pass success
- evidence completeness
- automation reliability
- knowledge reuse

Reduce:
- manual routing
- context copying
- status checking
- unnecessary questions
- intervention minutes
- missed blockers
- duplicate work
- time-to-green
- cost per accepted outcome

## Interaction doctrine

- Attention > Activity.
- Conversation is one projection, not canonical state.
- Context travels with the mission.
- Artifacts and evidence are first-class objects.
- Human attention is a scarce system resource.
- The system should automatically start safe, dependency-ready work where policy permits.
- Interrupt humans for judgment, authority, consequential ambiguity, risk, or external dependency.
- Every consequential action exposes scope, rationale, authority, evidence prerequisites and reversibility.
- Preserve spatial memory. State changes should occur in place.
- Async updates never steal focus or jump reading position.
- Raw events/logs/tool calls are available, but progressively disclosed.
- Keyboard, mouse, natural language and voice use the same command grammar.

## State integrity

### Session semantic state
Working / Waiting / Blocked / Reviewing / Paused / Done / Failed

### Work state
BACKLOG / READY / IN_PROGRESS / IN_REVIEW / BLOCKED / NEEDS_CHANGES / DONE

### Runtime attempt state
NEW / QUEUED / READY / RUNNING / WAITING / HUMAN_GATE / BLOCKED /
VERIFYING / FAULTED / SUSPENDED / QUARANTINED /
SUCCESS / FAILED / TERMINATED / ROLLED_BACK

### Assurance state
UNPROVEN / EVIDENCE_PENDING / VERIFYING / VERIFIED_SUCCESS /
REJECTED / HUMAN_DECISION_REQUIRED

**Done is never visually equivalent to Verified Success.**

## Visual direction — Pearl Slate

Qualities:
- machined
- calm
- intelligent
- tactile
- premium
- slightly alive

Palette:
- Pearl base `#E7EAED`
- Pearl high `#F3F5F6`
- Pearl low `#D7DDE2`
- Slate 950 `#10161D`
- Slate 900 `#151D26`
- Slate 850 `#1B2530`
- Slate 800 `#222E3A`
- Ion Blue `#4EB8F4`
- Verified `#75C79B`
- Waiting/Human `#E9B768`
- Risk/Failure `#E37676`
- Experimental `#9D7BEE`
- Provenance `#77A9D8`

Rules:
- semantic colors are never decorative
- no neon default
- no gratuitous glassmorphism
- no moving gradient behind dense content
- no floating/scaling cards on hover
- restrained 1px borders and carefully tuned depth
- premium feel comes from tolerances, rhythm, continuity and responsiveness

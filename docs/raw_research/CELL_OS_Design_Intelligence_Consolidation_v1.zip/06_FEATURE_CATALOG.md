# Consolidated Feature Catalog

## P0 — the product should feel dramatically better with these

1. **NERVE Today / Command Deck** — attention-first home.
2. **Unified Attention Inbox / Needs You** — one human cognition/authority queue.
3. **Since You Were Away** — semantic change recap, not transcript summary.
4. **Universal Command Composer** — Ask / Navigate / Create / Delegate / Act.
5. **Command Palette** — keyboard-first navigation and action.
6. **Push-to-Talk / Voice Brief** — same command grammar as text.
7. **Multi-Session Constellation** — stable spatial positions; semantic state at a glance.
8. **Mission-centric navigation** — sessions/tools remain lower-level.
9. **Run All Safe Work** — launch dependency-ready work within policy.
10. **DAG Auto-Advance** — advance automatically after evidence/success checks.
11. **Decision Ledger** — consequential choices with rationale/evidence/owner.
12. **Evidence Lens** — universal "show me the proof".
13. **Consequence Sheet** — proper high-risk approval UX.
14. **Artifact Library** — artifacts as first-class versioned/provenanced objects.
15. **Replay Spine** — causal timeline, inspect why/when/how.
16. **Stable Inspector** — one deep interaction pattern across the product.
17. **Context Capsules** — scoped context packet with provenance/freshness.
18. **Blackbox Intake** — unstructured request → Mission Contract.
19. **Scoping Queue** — confidence, unknowns, missing evidence, next questions.
20. **Client Clarification Loop** — ask only what the system cannot infer.
21. **Automation Center** — library + runs + health.
22. **Automation Suggestions** — repeated human workflow → candidate playbook.
23. **Workflow Distillation** — repeated stable agent/tool trace → deterministic meta-tool candidate.
24. **WorkGraph Mission Board** — work/runtime/evidence semantics, not a generic ticket clone.

## P1 — signature differentiation

25. **Cell Studio / Operative Cell Builder**
26. **Formation Recommender**
27. **Mission Context Compiler / Second Brain**
28. **Collision Detection** — overlapping code/work/assumptions/resources.
29. **Smart Handoff** — objective/state/evidence/artifacts/unresolved questions.
30. **Summon Specialist** — context-prepared expert insertion.
31. **Parallel Strategy Fork / Best-of-N**
32. **Briefing Room** — decision-oriented executive view.
33. **Shadow Twin Compare**
34. **The Crucible / Evolution Arena**
35. **HyperMESH Knowledge Explorer**
36. **Cell Health Vitals** — assurance, resource, coordination, context, uncertainty.
37. **Cognitive Pressure / PSI** — show what is actually limiting throughput.
38. **Epistemic Coherence Alerts** — warn when active missions rely on stale/invalidated context.
39. **Interface-generated Operating Playbooks**
40. **Mobile approval with adjacent evidence**
41. **Email / meeting intake intelligence** — input routing into mission context.
42. **Professional client delivery workspace** — package verified artifacts and decisions.

## Experimental / research-only until proven

43. **Semantic Zoom** across organization → Cell → Operative → execution.
44. **Spatial command view** as an alternate projection, never a second truth model.
45. **Direct manipulation compiled into typed commands**.
46. **Context logistics / supply-line visualization**.
47. **Formation-as-visual-topology compiler**.
48. **Ghost mission overlays / historical execution comparison**.
49. **Adaptive battlefield / task-oriented spatial layout**.
50. **Stigmergic terrain / process-mined recurrent pathways**.
51. **Persistent social/avatar world** only if it improves comprehension, collaboration or learning.

## Product kill rule

A feature should not remain in the primary interface unless it materially improves at least one:
- time to correct action
- human coordination load
- situation awareness
- error prevention
- verified outcome quality
- interruption recovery
- context switching
- accessibility
- safe autonomy

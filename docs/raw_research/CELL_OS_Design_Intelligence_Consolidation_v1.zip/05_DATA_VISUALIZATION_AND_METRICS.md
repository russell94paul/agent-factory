# Data Visualization & Metrics

## Principle

Switchboard/NERVE is an **action interface first**.
Persistent charts should exist only when they answer a recurring decision.

Use:
- compact metric + target/baseline
- hover/inspect for detail
- click for drilldown
- anomaly-triggered visualization
- contextual side drawer / workspace
- linked evidence

## Chart grammar

- trend → line
- rank → horizontal bar
- target → bullet / target band
- distribution → histogram / box / violin when audience supports it
- operational time → timeline / lanes
- multi-agent comparison → sortable table + sparklines / small multiples
- dependency → graph only when structure is the question
- evolution → Pareto scatter + linked candidate table

## Rules

Every important metric has at least one:
- target
- baseline
- expected band
- previous period
- annotation

Never make tooltips the only interpretation.

Clicking metrics should drill into underlying missions, runs, artifacts or evidence.

## Core outcome metrics

- Verified Mission Success
- Time-to-Green
- False-Green Rate
- Rework
- Accepted Output Rate
- First-Pass Success

## Human burden

- Decisions Waiting
- Intervention Minutes
- Approvals per Accepted Mission
- Clarification Loops
- Context Reacquisition Time
- Missed Important Item Rate

## Coordination

- Blocked Minutes
- Handoff Loss
- Duplicate Work
- Waiting by Source
- Critical-Path Delay
- Collision / overlap rate

## Economics

- Cost per Accepted Outcome
- Model / Tool Cost
- Context Load Cost
- Automation Savings

## Assurance

- Evidence Completeness
- Replay Success
- Receipt Coverage
- Regression Escape / false promotion

## Knowledge

- Provenance Coverage
- Context Faults
- Stale Context Use
- Contradiction Queue
- Knowledge Reuse

## Evolution

- Outcome / cost / time / rework / intervention frontier
- Shadow discovery rate
- Promotion regression
- configuration delta vs champion

# Design Review Scorecard

Score major concepts 1–10:

| Dimension | Question |
|---|---|
| Five-second comprehension | Can the user identify important state immediately? |
| Attention routing | Does the UI expose what needs human cognition without noise? |
| Task speed | Does it reduce actions/time? |
| Interruption recovery | Can the user return without rereading history? |
| Trust calibration | Are fact/inference/proposal/action/verification distinguishable? |
| Error prevention | Are dangerous mistakes hard to make? |
| Reversibility | Is rollback/undo clear? |
| Information architecture | Does navigation match user mental models? |
| Spatial memory | Does state stay stable enough to learn? |
| Accessibility | Is the core workflow keyboard/screen-reader/reduced-motion capable? |
| Premium aesthetic | Is it coherent, precise and restrained? |
| Density handling | Can experts supervise many objects without chaos? |
| Mobile supervisory value | Can meaningful work be supervised on the go? |
| Technical feasibility | Can the design map to real typed state and events? |
| Architectural truth | Does it preserve WorkGraph/Kernel/Evidence semantics? |

## Hard failures

Reject/redesign if any is true:
- async focus theft
- critical state hidden
- chat treated as canonical state
- color-only status
- critical hover-only information
- modal stacking
- Done shown as Verified
- consequential action without scope preview
- UI requires decorative motion to remain understandable
- world/spatial mode creates a separate truth model
- freeform graph is the only way to configure critical Cells

## Final acceptance questions

1. What needs me?
2. What changed?
3. What is blocked?
4. What is risky?
5. What finished?
6. What is actually verified?
7. Which mission/Cell owns it?
8. Why is the system asking me?
9. What happens if I approve?
10. Can I undo/rollback?
11. Where did the evidence come from?
12. Can I get back to what I was doing?
13. Can I do the core task by keyboard/mobile?
14. Can I inspect/build a Cell without internal service knowledge?
15. Does the UI still feel coherent with decorative effects disabled?

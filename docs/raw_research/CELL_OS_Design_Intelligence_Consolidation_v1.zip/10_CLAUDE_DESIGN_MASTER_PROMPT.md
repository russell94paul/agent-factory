# CLAUDE DESIGN MASTER PROMPT — CELL OS / Switchboard / NERVE

You are the **Principal Product Design & Interaction Intelligence Lead** for CELL OS.

You are supported conceptually by:
- Principal Product Designer
- HCI / Human Factors Researcher
- Information Architect
- AI-native Developer Tools Designer
- Agentic Systems Architect
- Motion / Interaction Designer
- Data Visualization Designer
- Accessibility Specialist
- Design Systems Engineer
- Mobile Product Designer
- Product Strategist
- Reliability / Trust UX Researcher
- Critical Red-Team Reviewer

Your task is to use **all attached artifacts**, including every ZIP and its nested contents, to
design the most coherent, premium, fast, intuitive and technically truthful version of CELL OS.

Do not simply make the existing interface prettier. Reconcile the product model, interaction model,
information architecture, layout, components, motion, data visualization, mobile behavior and
future Operative Cell builder into one system.

---

## 0. FIRST ACTION — ARTIFACT RECONCILIATION

Before designing, recursively inspect all supplied archives and files.

Produce an **Artifact Reconciliation Ledger**.

For every artifact classify it as:

- `CANONICAL` — current product/runtime/design source
- `MERGE` — contains active concepts that should be incorporated
- `REFERENCE` — useful pattern/research only
- `SUPERSEDED` — older naming/theme/layout replaced by a newer decision
- `CONFLICT` — materially disagrees with another current artifact
- `UNKNOWN` — insufficient evidence

For every material concept record:
- source file
- concept
- maturity/status
- keep/adapt/reject
- reason
- conflicting source if any

Never silently blend contradictions.

Newest explicit product decisions beat older aesthetic experiments.
Repository/runtime evidence beats design intent when determining what exists.

---

## 1. PRODUCT DEFINITION

**CELL OS — Operating System for Synthetic Organizations**

CELL OS compiles intent into bounded **Operative Cells**, mediates privileged capabilities,
allocates context/resources, coordinates work, records evidence, supports replay/shadow evaluation,
and learns which organizational configurations work best.

The **Cell** is the primary executable/certifiable organizational primitive.
An **Operative** is a bounded intelligent worker within a Cell.

CELL OS is **not** a multi-agent chat wrapper.

North-star flow:

`intent → mission contract → compile Cell → execute → supervise → intervene → verify → replay → learn → evolve`

---

## 2. CURRENT PRODUCT HIERARCHY

Treat this as the current working IA unless a newer explicit attached artifact supersedes it:

```text
CELL OS
└── SWITCHBOARD                      # sole current top-level product tab
    └── NERVE                        # high-frequency supervisory/operator experience
        ├── Today
        ├── Inbox
        ├── Missions
        ├── Automations
        ├── Artifacts
        ├── Knowledge
        ├── Intelligence
        └── Systems
```

Deep tools are **contextual workspaces**, not peer top tabs:

- Mission Control
- Briefing Room
- Cell Studio
- Cell / Operative Inspector
- Evidence / Assurance
- Replay / Profiler
- Shadow Twin Compare
- Evolution / The Crucible
- Admin / deep configuration

Do not turn architecture modules into permanent navigation items just because they exist technically.

---

## 3. NERVE

NERVE = **Navigation, Execution, Routing, Verification & Escalation**.

NERVE must solve the high-frequency operator problem:

> A user can leave many sessions/Cells working, return later, understand what changed,
> resolve the few decisions that matter, prove outcomes, and continue without rereading transcripts.

NERVE is not a remote-terminal skin.

Design desktop and mobile as distinct responsive experiences over the same state.

---

## 4. DESIGN DOCTRINE

Non-negotiable:

- **Attention > Activity**
- human attention is scarce
- agent narrative is not evidence
- `Done != Verified Success`
- work, runtime and assurance states remain distinct
- context travels with the mission
- artifacts/evidence are first-class
- progressive disclosure beats telemetry walls
- autonomous events never steal typing focus
- preserve draft text, selected object, reasonable scroll position and spatial memory
- critical information is never hover-only
- keyboard, mouse, natural language and voice use one command grammar
- consequential commands show a structured preview before execution
- graphs are used when topology/dependency is the question, not as decoration
- mobile is supervisory, not a miniature desktop terminal

Primary product metric:
**Human Coordination Load**

The system improves when verified outcomes and useful parallelism rise while manual routing,
context copying, status checking, interruptions, duplicate work and time-to-green fall.

---

## 5. VISUAL DIRECTION — START FROM PEARL SLATE, BUT TEST IT

Current recommended direction: **Pearl Slate**

Character:
- precision-machined
- calm
- tactile
- intelligent
- expensive through tolerances
- slightly alive, never noisy

Base palette:
- Pearl `#E7EAED`
- Raised Pearl `#F3F5F6`
- Cool Pearl `#D7DDE2`
- Slate 950 `#10161D`
- Slate 900 `#151D26`
- Slate 850 `#1B2530`
- Slate 800 `#222E3A`
- Ion Blue `#4EB8F4`
- Verified `#75C79B`
- Waiting/Human `#E9B768`
- Risk `#E37676`
- Experimental `#9D7BEE`
- Provenance `#77A9D8`

Avoid:
- neon-cyberpunk default
- gratuitous glassmorphism
- glow everywhere
- card soup
- moving gradients behind dense content
- giant marketing typography inside operational screens
- hover-scale/floating cards
- decorative semantic colors

However, do not worship Pearl Slate. Create at least **two materially different alternative visual
directions**, prototype the same screen in each, score them, and select a winner.

---

## 6. LAYOUT SYSTEM

Use a stable professional shell:

- top bar
- left navigation rail
- main canvas
- consistent right inspector
- optional live Run Dock

Starting dimensions:
- top bar ~56px
- rail ~232px expanded / 64px compact
- inspector ~320–480px
- live dock ~56px
- three-pane layout from roughly 1180px

Do not force every page into a marketing-style card grid.

Use the layout appropriate to the question:
- lanes for sessions/state
- timeline for replay
- table for dense comparison
- graph for dependency/topology
- structured canvas for Cell Studio
- split view for planning/inspection

---

## 7. REQUIRED SIGNATURE EXPERIENCES

Fully design and connect:

1. NERVE Today / Command Deck
2. Unified Attention Inbox / Needs You
3. Since You Were Away
4. Multi-Session Constellation
5. Universal Command Composer
6. Voice Brief / Push-to-Talk
7. Decision Ledger
8. Mission Context Capsules
9. Blackbox Intake
10. Scoping Queue
11. Client Clarification Loop
12. WorkGraph Mission Board
13. Run All Safe Work
14. DAG Auto-Advance
15. Live Mission Control
16. Artifact Library
17. Evidence Lens
18. Consequence Sheet
19. Replay Spine
20. Automation Center
21. Automation Suggestions / Playbooks
22. Workflow Distillation / deterministic meta-tool candidates
23. HyperMESH Knowledge Explorer
24. Cell Studio / Operative Cell Builder
25. Formation Recommender
26. Shadow Twin Compare
27. The Crucible / Evolution Arena
28. Cognitive Pressure / PSI
29. Cell Health Vitals
30. Epistemic Coherence Alerts
31. Mobile approval with adjacent evidence
32. Professional client delivery workspace

Also mine older Agent Factory/Army/ZEUS research for high-value mechanisms such as:
semantic zoom, context logistics, collision detection, smart handoffs, specialist hot-drop,
direct manipulation compiled to typed commands, replay, macro human-swarm control and
spatial memory.

These are **patterns**, not permission to restore obsolete branding or make a battlefield the default UI.

---

## 8. CELL STUDIO — MAKE THIS A CATEGORY-DEFINING BUILDER

CELL OS actually builds Operative Cells.

Research and prototype the best way to configure:
- formation/topology
- Operative seats
- deterministic workers
- model/runtime
- capabilities/tools
- memory mounts
- communication policy
- resource envelopes
- authority/gates
- evaluators
- evidence contract
- versions
- certification

Compare:
1. freeform graph
2. form-first
3. structured canvas + inspector
4. natural-language builder + generated config
5. hybrid

Default hypothesis:
**hybrid = structured canvas + inspector + natural-language generation + machine-readable diffable config**

Do not choose a node editor merely because it looks agentic.

Show readiness and effective permissions before launch.

Version diff must make topology/model/capability/memory/budget/authority/eval changes obvious.

---

## 9. MOTION & MICROINTERACTION SYSTEM

Animation is allowed only for:
- orientation
- causality
- status
- continuity
- feedback

Baseline timing:
- press ~90ms
- hover ~120ms
- tooltip ~130ms
- popover ~160ms
- tabs/menu ~180ms
- inspector ~240ms
- sheet ~260ms
- workspace continuity ~320ms
- complex deliberate visualization <= 500ms

State changes should morph **in place**.
Do not automatically reorder active cards while the user is reading.

Pearl glisten:
- peripheral background only
- extremely low opacity
- pause while typing/scrolling
- disabled for reduced motion
- event-linked shimmer is preferable to constant ambient motion

Prototype reduced-motion behavior explicitly.

---

## 10. HOVER / TOOLTIP / INSPECTOR / MODAL RULES

Tooltip:
short supplemental info.

Popover:
compact metadata / quick action.

Inspector:
deep properties, relations, context, evidence, versions and actions.

Modal:
bounded synchronous form only.

Consequence Sheet:
high-risk decision with scope, requester, environment, evidence, cost, reversibility and rollback.

Hover must add clarity without layout shift.
No critical instruction or state may exist only on hover.

---

## 11. DATA VISUALIZATION

Do not build a conventional analytics homepage.

Every key metric needs a target, baseline, expected band, previous period or annotation.

Chart grammar:
- trend → line
- rank → horizontal bar
- target → bullet/target band
- operational time → timeline/lane
- multi-agent → sortable table + sparklines/small multiples
- dependency → graph only when structure is the question
- evolution → Pareto plot + linked candidate table

Clicking a metric should reveal the missions/runs/evidence that produced it.

Prioritize:
verified success, time-to-green, false-green, rework, blocked time,
human intervention, cost/accepted outcome, automation reliability,
evidence completeness, knowledge freshness, formation performance and
shadow/promotion regressions.

---

## 12. MOBILE

Do not miniaturize desktop.

Mobile priority:
1. Needs You
2. blocked/failed/risky
3. since-you-were-away
4. pinned mission/session status
5. evidence-aware decision
6. voice brief/navigation

Bottom navigation:
Today / Inbox / Missions / More

Test scenarios:
- silent permission wait while user is away
- one consequential decision among many working sessions
- deployment failure
- returning after two hours
- "Read me what needs me"
- safe pause/approve action from phone

---

## 13. ACCESSIBILITY / HUMAN FACTORS

Target WCAG 2.2 AA.

Explicitly test:
- keyboard-only
- visible focus
- logical focus order
- 200% zoom/reflow
- reduced motion
- screen reader structure
- meaningful async announcements
- no color-only state
- no hover-only critical information
- dismissible/hoverable/persistent hover content
- safe pointer targets
- no focus stealing
- mobile approval parity

Evaluate:
- attention overload
- alert fatigue
- automation bias
- accidental approval
- ambiguity of confidence
- spatial disorientation
- interruption recovery

---

## 14. INFORMATION-ARCHITECTURE TOURNAMENT

Do not simply accept the current IA.

Compare at least four materially different models:

1. Switchboard/NERVE unified shell
2. multi-app suite
3. mission-centric object OS
4. command-first adaptive workspace

For each:
- mental model
- nav
- desktop/mobile
- contextual workspaces
- command behavior
- discoverability
- expert speed
- spatial memory
- implementation complexity
- risks
- score

Select a winner.

Constraint:
do not create unnecessary peer top tabs if the same function works better contextually.

---

## 15. REQUIRED SCREEN SPECIFICATION

Fully specify:

### NERVE
- Today
- Inbox
- Missions
- Mission Detail
- Multi-session
- Session Detail
- Automations
- Artifacts
- Knowledge
- Intelligence
- Systems

### Contextual
- Mission Control
- Briefing Room
- Cell Studio
- Cell/Operative Inspector
- Evidence/Assurance
- Replay/Profiler
- Shadow Twin Compare
- Evolution/Crucible

### Mobile
- Today
- Inbox approval
- multi-session state
- voice brief
- mission glance

For every screen define:
- primary user job
- top actions
- information hierarchy
- layout zones
- objects
- default view
- filters/search
- contextual tabs
- inspector behavior
- keyboard behavior
- hover
- empty/loading/error/degraded/offline
- blocked/waiting
- gate/permission
- success/verified
- responsive behavior
- motion
- accessibility
- telemetry needed to evaluate the design

---

## 16. COMPONENT SYSTEM

Define anatomy, variants, states, hover, focus, keyboard, motion, accessibility and "when not to use" for:

App shell, rail, top bar, command composer, command palette, Attention Strip,
Inbox item, Mission card, Session card, Operative card, Cell card, WorkGraph node,
state badge, evidence badge, resource meter, Decision card, Consequence Sheet,
approval controls, Context Capsule, Inspector, tooltip, popover, tabs, table,
timeline, replay scrubber, diff viewer, artifact preview, version stack, topology canvas,
metric block, sparkline, Pareto plot, toast, inline error, skeleton, voice overlay,
mobile nav and Run Dock.

---

## 17. DESIGN EVALUATION

Score every major concept 1–10 on:
- five-second comprehension
- attention routing
- task speed
- interruption recovery
- trust calibration
- error prevention
- reversibility
- information architecture
- spatial memory
- accessibility
- premium aesthetic
- density handling
- mobile supervisory value
- technical feasibility
- architectural truth

Hard reject/redesign:
- focus theft
- hidden critical state
- chat as canonical state
- color-only status
- critical hover-only content
- modal stacking
- misleading Done vs Verified
- unsafe side effect without preview
- decorative motion required for comprehension
- second source of truth in spatial/avatar mode

---

## 18. REQUIRED FINAL DELIVERABLE

Return a cohesive **CELL OS Product Design System & Experience Specification**, not a moodboard.

Produce:

1. Executive design thesis
2. Artifact reconciliation ledger
3. Current UX friction audit
4. Source-grounding / implementation-truth table
5. Product mental model
6. IA tournament
7. selected IA
8. desktop shell spec
9. mobile shell spec
10. page-by-page specs
11. Cell Studio deep spec
12. component library
13. command/chat/voice grammar
14. motion and microinteraction system
15. hover/tooltip/inspector/modal system
16. design tokens
17. data-visualization grammar
18. empty/loading/error/degraded-state system
19. accessibility/human-factors spec
20. feature ranking: P0 / P1 / P2 / Research
21. implementation dependencies / state/events required
22. measurable UX experiments
23. "what not to build" list
24. contradictions and unresolved decisions
25. final prototype storyboard

For the final storyboard, show at minimum:

**Intake → Mission → Cell compilation → parallel execution → Needs You → evidence-aware decision →
Verified Success → artifact delivery → replay/learning → automation/distillation suggestion**

The result should feel like an **iPhone-class operating experience for synthetic organizations**:
simple on the surface, deep when inspected, extremely fast, beautifully restrained, and trustworthy
under real operational pressure.

Do not stop at aesthetic description. Specify behavior precisely enough that a frontend engineer,
motion designer and agent-runtime engineer could build from it.

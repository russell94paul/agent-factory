# Source Priority & Reconciliation

## Priority 0 — explicit current product decisions

Use the newest explicit user/product decisions first.

Current working hierarchy:

- Product: **CELL OS**
- Current sole top-level product tab: **Switchboard**
- NERVE: high-frequency supervisory/operator experience within the Switchboard product surface
- Side navigation: Today / Inbox / Missions / Automations / Artifacts / Knowledge / Intelligence / Systems
- Deep tools are contextual workspaces, not peer global apps.

## Priority 1 — canonical CELL OS design/runtime sources

Treat these as product/runtime doctrine and architecture truth **only to the maturity they claim**:

- `CELL_OS_Master_Research_Design_Development_Operations_User_Guide_v0.2.docx`
- `CELL_OS_Product_Technical_Design_v0.1.docx`
- `CELL_OS_Delivery_Backlog_v0.2.xlsx`
- `CELL_OS_Roadmap_Tasks_Milestones_v0.1.xlsx`
- `CELL_OS_Design_Build_Operate_Pack_v0.1.zip`
- `Agent Factory Vision.txt`
- CELL OS architecture diagram(s)

Preserve maturity labels:
`PLANNED / PROTOTYPE / IMPLEMENTED / CERTIFIED / FRONTIER`.

Never present a design proposal as repository/runtime fact.

## Priority 2 — canonical interface synthesis

Treat these as the strongest current design guidance:

- `01_CELL_OS_ELITE_INTERFACE_SPEC_v1.md`
- `02_CELL_OS_MASTER_DESIGN_RESEARCH_PROMPT_v1.md`
- `03_CELL_OS_DESIGN_SYSTEM_TOKENS_v1.json`
- `04_CELL_OS_AGENT_INPUT_CONTRACT_v1.yaml`
- `05_CELL_OS_SCREEN_STATE_AND_QA_CHECKLIST_v1.md`
- `06_SOURCE_SYNTHESIS_AND_DESIGN_DECISIONS_v1.md`
- `CELL_OS_NERVE_Design_Intelligence_MetaSkill_v1.zip`

## Priority 3 — useful predecessor research / pattern library

Mine these for interaction mechanisms, HCI hypotheses and feature ideas:

- Switchboard Mission Control UX master prompt
- Agent Factory / Army UI master concepts
- ZEUS World UI research pack
- Agentic IDE / Mission Command concepts
- spatial / semantic zoom research
- human-swarm control
- context logistics
- collision detection
- replay / counterfactual command
- direct manipulation / typed command compilation
- gamification research

Do **not** let predecessor naming/theme override current CELL OS/NERVE language.

## Superseded or reference-only directions

- Zeus/Olympus mythology as the primary UI theme
- fixed military hierarchy as product ontology
- persistent battlefield/world view as the default operator UI
- agent/session transcript as the product's source of truth
- conventional dashboard filled with equal-weight KPI cards
- freeform node graph as the only Cell configuration method
- neon cyberpunk / excessive glass / constant glow as the default visual identity

Useful mechanisms from superseded research may still survive:
semantic zoom, formations, human-swarm macro control, context logistics, target lock,
collision prevention, direct manipulation, replay and spatial memory.

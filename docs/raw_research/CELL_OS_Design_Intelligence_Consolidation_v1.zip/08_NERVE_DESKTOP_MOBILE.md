# NERVE — Desktop & Mobile

## Meaning

NERVE: **Navigation, Execution, Routing, Verification & Escalation**

Role:
High-frequency supervisory experience for many sessions/Cells, decisions, evidence and interventions.

It is not a transcript viewer.

## Desktop

### Today
- Needs You
- Active Missions
- Since You Were Away
- Next Events
- Quiet Intelligence

### Multi-session
- stable card positions
- semantic state changes in place
- pinned sessions
- waiting/blocked reason
- mission/Cell ownership
- latest meaningful change
- next requested decision
- artifact/evidence delta

### Run Dock
Optional small persistent strip for a few pinned live sessions.

## Mobile

Bottom nav:
Today / Inbox / Missions / More

Priority:
1. human-required work
2. blockers/failures/risk
3. since-you-were-away
4. pinned mission/session state
5. evidence-aware decisions
6. voice brief/navigation

### Voice

Examples:
- "Read me what needs me."
- "What changed since lunch?"
- "Open the most urgent blocked mission."
- "Pause anything touching production."
- "Approve only if all required evidence is verified."

Show transcription and structured action preview before consequential execution.

### Mobile anti-patterns

- terminal as home
- full desktop rail squeezed into phone
- tiny charts
- transcript-first navigation
- approval buttons without evidence/scope

const pptxgen = require('pptxgenjs');
const {
  warnIfSlideHasOverlaps,
  warnIfSlideElementsOutOfBounds,
} = require('/home/oai/skills/slides/pptxgenjs_helpers');

const pptx = new pptxgen();
pptx.layout = 'LAYOUT_WIDE';
pptx.author = 'OpenAI';
pptx.subject = 'ORCA Agentic Engineering Operating System';
pptx.title = 'ORCA — Agentic Engineering OS';
pptx.company = 'Agent Factory Research';
pptx.lang = 'en-US';
pptx.theme = {
  headFontFace: 'Aptos Display',
  bodyFontFace: 'Aptos',
  lang: 'en-US',
};
pptx.defineLayout({ name: 'LAYOUT_WIDE', width: 13.333, height: 7.5 });
pptx.layout = 'LAYOUT_WIDE';
pptx.defineSlideMaster({
  title: 'ORCA_MASTER',
  background: { color: '060914' },
  objects: [
    { rect: { x: 0, y: 0, w: 13.333, h: 7.5, fill: { color: '060914' }, line: { color: '060914' } } },
    { rect: { x: 0.15, y: 0.15, w: 13.03, h: 7.2, fill: { color: '060914', transparency: 100 }, line: { color: '25375F', transparency: 22, width: 1 } } },
  ],
  slideNumber: { x: 12.25, y: 7.1, color: '566B98', fontSize: 8 },
});

const C = {
  bg:'060914', panel:'0D1428', panel2:'121B35', ink:'EEF6FF', muted:'99A8C7', cyan:'48E8FF', violet:'9D70FF', mint:'6FFFC2', amber:'FFD166', red:'FF6B8A', blue:'7DA7FF', line:'25375F'
};

function slide() { const s = pptx.addSlide('ORCA_MASTER'); return s; }
function title(s, t, sub) {
  s.addText(t, { x:0.55,y:0.35,w:8.4,h:0.5, fontFace:'Aptos Display', fontSize:24, bold:true, color:C.ink, margin:0 });
  if (sub) s.addText(sub, { x:0.58,y:0.92,w:7.8,h:0.35, fontSize:10.5, color:C.muted, margin:0 });
  s.addShape(pptx.ShapeType.line, { x:0.56,y:1.32,w:1.65,h:0, line:{ color:C.cyan, width:2 } });
}
function label(s, txt, x, y, w, color=C.mint) { s.addText(txt.toUpperCase(), {x,y,w,h:0.22,fontSize:8.5,bold:true,color,margin:0,breakLine:false,fit:'shrink'}); }
function box(s, txt, x, y, w, h, fill=C.panel2, line=C.line, opts={}) {
  s.addShape(pptx.ShapeType.roundRect, {x,y,w,h, rectRadius:0.08, fill:{color:fill, transparency: opts.transparency??0}, line:{color:line, transparency: opts.lineTrans??0, width:1.1}});
  s.addText(txt, {x:x+0.13,y:y+0.11,w:w-0.26,h:h-0.2,fontSize:opts.fs??12.5,bold:opts.bold??false,color:opts.color??C.ink,margin:0,fit:'shrink',valign:'mid',align:opts.align??'center'});
}
function bullet(s, lines, x, y, w, h, fs=14) {
  s.addText(lines.map(l=>({text:l,options:{bullet:{indent:10},hanging:4}})), {x,y,w,h,fontSize:fs,color:C.ink,margin:0.03,breakLine:false,fit:'shrink'});
}
function arrow(s, x1,y1,x2,y2,color=C.blue) {
  s.addShape(pptx.ShapeType.line, {x:x1,y:y1,w:x2-x1,h:y2-y1,line:{color, width:1.4, beginArrowType:'none', endArrowType:'triangle'}});
}
function small(s, txt, x,y,w,h, color=C.muted, fs=10) { s.addText(txt,{x,y,w,h,fontSize:fs,color,margin:0,fit:'shrink'}); }
function bar(s, x, y, w, labelText, val, color) {
  small(s,labelText,x,y,w,0.2,C.ink,10.5); s.addShape(pptx.ShapeType.rect,{x,y:y+0.28,w,h:0.11,fill:{color:'1A2442'},line:{color:'1A2442'}}); s.addShape(pptx.ShapeType.rect,{x,y:y+0.28,w:w*val,h:0.11,fill:{color},line:{color}});
}
function validate(s){ warnIfSlideHasOverlaps(s,pptx,{ignoreLines:true,ignoreDecorativeShapes:true}); warnIfSlideElementsOutOfBounds(s,pptx); }

// 1
{
 const s=slide();
 s.addText('ORCA', {x:0.7,y:1.45,w:6.0,h:1.15,fontFace:'Aptos Display',fontSize:76,bold:true,color:C.cyan,margin:0});
 s.addText('Agentic Engineering Operating System', {x:0.78,y:2.62,w:6.8,h:0.58,fontSize:24,bold:true,color:C.ink,margin:0});
 s.addText('Operative Runtime, Context & Assurance — a framework for compiling missions into certified Operative Cells.', {x:0.8,y:3.35,w:6.2,h:0.8,fontSize:18,color:'C9D8F7',margin:0,fit:'shrink'});
 const cx=9.95, cy=3.7;
 ['Mission','Context','Evidence','Gate','Certify','Learn'].forEach((t,i)=>{ const a=(-90+i*60)*Math.PI/180, x=cx+2.05*Math.cos(a), y=cy+2.05*Math.sin(a); box(s,t,x-0.42,y-0.18,0.84,0.36,i%2?C.panel2:'0F2B2B',i%2?C.violet:C.mint,{fs:7.7,bold:true});});
 box(s,'Operative\nCell',cx-0.56,cy-0.4,1.12,0.8,'111B36',C.cyan,{fs:12.5,bold:true});
 label(s,'Frontier synthesis from consolidated research corpus',0.83,5.55,4.6,C.mint);
 small(s,'Status: research is intentionally treated as hypotheses until validated by held-out mission evidence.',0.83,5.9,6.7,0.4,C.muted,11.5);
 validate(s);
}

// 2
{
 const s=slide(); title(s,'Why “agent” is too small','The unit deployed into serious engineering work needs context, evidence, governance and certification.');
 label(s,'standard agent',0.75,1.65,2.4,C.cyan); label(s,'operative cell',7.1,1.65,2.4,C.mint);
 box(s,'Model',0.72,2.1,1.55,0.55,'111B36',C.cyan,{bold:true}); arrow(s,2.35,2.37,3.08,2.37); box(s,'Prompt',3.13,2.1,1.55,0.55,'111B36',C.cyan,{bold:true}); arrow(s,4.78,2.37,5.48,2.37); box(s,'Tools',5.53,2.1,1.55,0.55,'111B36',C.cyan,{bold:true});
 small(s,'Good for simple, local execution. Weak for provenance, evaluation, cross-team memory, replayability and permissioned autonomy.',0.72,3.05,5.85,1.0,C.muted,13);
 const comps=['Genome','Mission Contract','Org-IR','HyperMESH','Policy','DAG','Shadow Twin','Evidence','Certification'];
 comps.forEach((t,i)=>{ const col=i%3,row=Math.floor(i/3); box(s,t,7.35+col*1.55,2.0+row*0.78,1.32,0.5, row%2?'171439':'0F2B2B', row%2?C.violet:C.mint,{fs:10,bold:true}); });
 small(s,'An Operative Cell is a deployable organizational unit. It carries the instructions, authority, memory view, evaluators, and proof trail required for engineering work.',7.25,4.65,4.85,0.9,'C9D8F7',13);
 validate(s);
}

//3 stack
{
 const s=slide(); title(s,'Operative Cell: the technical entity','AI Operative is the operator-facing name; Operative Cell is the certifiable architecture unit.');
 const layers=[['Mission Contract','Success criteria, scope, risk, autonomy envelope'],['Org-IR Topology','Roles, stages, gates, budgets, permissions'],['Agent + Org Genome','Model, prompt, tools, communication, strategy'],['HyperMESH Context','Permissioned retrieval with provenance + contradictions'],['Proof-Carrying DAG','Every node emits artifacts and positive evidence'],['Certification Lockfile','Pinned versions, eval results, approved promotion']];
 layers.forEach((l,i)=>{ const x=1.1+i*0.58, y=1.55+i*0.84, w=11.15-i*1.16; box(s,l[0]+'\n'+l[1],x,y,w,0.64,i%2?C.panel2:'0F2B2B',i%2?C.violet:C.mint,{bold:true,fs:12.2}); if(i<layers.length-1) arrow(s,6.66,y+0.66,6.66,y+0.82); });
 validate(s);
}

//4 System Architecture
{
 const s=slide(); title(s,'System architecture: Agentic Engineering OS','The platform compiles intent into cells, missions, proof, and learning.');
 // connectors first
 arrow(s,1.4,2.05,3.05,2.05); arrow(s,4.25,2.05,5.9,2.05); arrow(s,7.25,2.05,8.8,2.05); arrow(s,10.05,2.05,11.5,2.05);
 arrow(s,6.65,2.55,6.65,3.35); arrow(s,6.65,4.05,6.65,4.92); arrow(s,6.65,5.52,6.65,6.08);
 box(s,'Intent / Ticket',0.65,1.72,1.55,0.66,'111B36',C.cyan,{bold:true}); box(s,'Mission Context\nCompiler',3.0,1.6,1.8,0.9,'0F2B2B',C.mint,{bold:true,fs:12}); box(s,'Org-IR\nCompiler',5.78,1.6,1.74,0.9,'171439',C.violet,{bold:true,fs:12}); box(s,'Operative\nCell',8.65,1.6,1.64,0.9,'111B36',C.cyan,{bold:true,fs:13}); box(s,'Mission\nDAG',11.25,1.6,1.46,0.9,'0F2B2B',C.mint,{bold:true,fs:13});
 box(s,'HyperMESH\nKnowledge Fabric',5.32,3.35,2.66,0.7,'121B35',C.line,{bold:true,fs:12}); box(s,'Evaluation +\nCertification',5.32,4.92,2.66,0.7,'171439',C.violet,{bold:true,fs:12}); box(s,'Doctrine +\nCapability Models',5.32,6.08,2.66,0.7,'0F2B2B',C.mint,{bold:true,fs:12});
 validate(s);
}

//5 HyperMESH
{
 const s=slide(); title(s,'HyperMESH: permissioned organizational cognition','Memory is not a giant unrestricted prompt. It is a policy-routed knowledge fabric.');
 // connectors first
 arrow(s,6.65,2.1,6.65,2.82); arrow(s,6.65,3.52,6.65,4.15); arrow(s,6.65,4.85,6.65,5.55);
 [['A-MESH','agent working memory',1.0,2.0,C.cyan],['T-MESH','team state and handoffs',3.35,2.0,C.mint],['C-MESH','command coordination',5.7,2.0,C.violet],['G-MESH','certified doctrine',8.05,2.0,C.amber],['Federation','tenant/client boundary',10.4,2.0,C.red]].forEach(a=>box(s,`${a[0]}\n${a[1]}`,a[2],2.0,1.55,0.8,'111B36',a[4],{fs:10.5,bold:true}));
 box(s,'HyperMESH Gateway\nRBAC + ABAC + ReBAC + purpose-bound entitlements',4.55,3.0,4.2,0.72,'0F2B2B',C.mint,{fs:12,bold:true});
 box(s,'Mission Knowledge View\nRelevant history · sources · warnings · contradictions · prior PRs · agent capability evidence',3.85,4.25,5.6,0.82,'171439',C.violet,{fs:12,bold:true});
 box(s,'Operative Cell receives context pack, not raw graph access',4.45,5.72,4.45,0.55,'111B36',C.cyan,{fs:13,bold:true});
 validate(s);
}

//6 Proof DAG
{
 const s=slide(); title(s,'Proof-Carrying Mission DAG','A mission node succeeds only when it produces the required evidence object.');
 const xs=[0.75,2.55,4.35,6.15,7.95,9.75,11.3]; const names=['Preflight','Analyze','Plan','Implement','Test','Gate','Promote'];
 for(let i=0;i<xs.length-1;i++) arrow(s,xs[i]+1.08,2.2,xs[i+1]-0.05,2.2);
 names.forEach((n,i)=>{ box(s,n,xs[i],1.85,1.15,0.7,i%2?C.panel2:'0F2B2B',i%2?C.violet:C.mint,{fs:11.5,bold:true}); small(s,['contracts','hypotheses','diff plan','patch','RED→GREEN','review','release'][i],xs[i],2.72,1.15,0.3,C.muted,9); });
 box(s,'Evidence Ledger',4.5,4.02,4.3,0.65,'111B36',C.cyan,{fs:15,bold:true});
 ['artifact','assertion','eval result','transcript','cost','provenance','approval'].forEach((n,i)=>box(s,n,1.0+i*1.6,5.1,1.25,0.42,'121B35',C.line,{fs:9.5,bold:true}));
 small(s,'This is the fix for false-green automation: no node can hide behind a success status without positive proof.',0.85,6.4,7.4,0.35,C.muted,11.5);
 validate(s);
}

//7 Org-IR Genome
{
 const s=slide(); title(s,'Agent Genome + Organizational Genome','Configuration is the optimization surface; evidence is the reality surface. Keep them separate.');
 box(s,'Desired Configuration',0.8,1.65,3.2,0.58,'171439',C.violet,{fs:16,bold:true}); box(s,'Measured Evidence',9.25,1.65,3.2,0.58,'0F2B2B',C.mint,{fs:16,bold:true});
 ['role','model','tools','retrieval','communication','topology','budget','permissions'].forEach((n,i)=>box(s,n,0.95+(i%2)*1.45,2.65+Math.floor(i/2)*0.62,1.25,0.4,'111B36',C.violet,{fs:9.5,bold:true}));
 ['success rate','rework','time-to-green','cost/success','rollback','knowledge quality','synergy','regression rate'].forEach((n,i)=>box(s,n,9.42+(i%2)*1.45,2.65+Math.floor(i/2)*0.62,1.25,0.4,'111B36',C.mint,{fs:9.2,bold:true}));
 arrow(s,4.15,3.65,5.62,3.65); box(s,'Org-IR\nCompiler',5.65,3.18,2.0,0.92,'121B35',C.cyan,{fs:16,bold:true}); arrow(s,7.72,3.65,9.15,3.65);
 box(s,'Certification Lockfile\nPins: model · prompt · tools · memory view · policies · eval set · threshold · approval',3.15,5.38,7.0,0.78,'0F2B2B',C.mint,{fs:13,bold:true});
 validate(s);
}

//8 Evaluation
{
 const s=slide(); title(s,'Evaluation and certification loop','Self-improvement is only real when candidate changes survive independent evidence.');
 const nodes=[['Candidate\nChange',0.8,3.0],['Replay /\nSimulation',2.75,1.65],['RED→GREEN\nProof',5.05,1.65],['Regression\nSuite',7.35,1.65],['Human / Policy\nGate',9.65,3.0],['Canary +\nObserve',9.65,5.05],['Certified\nPromotion',6.1,5.55],['Knowledge\nWriteback',2.75,5.05]];
 const con=[];
 nodes.forEach((n,i)=>box(s,n[0],n[1],n[2],1.32,0.62,i%2?C.panel2:'0F2B2B',i%2?C.violet:C.mint,{fs:11.5,bold:true}));
 small(s,'Evaluators, promotion gates and safety policy stay outside the mutable optimization surface.',0.85,6.65,7.8,0.3,C.muted,11);
 validate(s);
}

//9 Shadow Twin
{
 const s=slide(); title(s,'Shadow Twin + adversarial governance','The safest high-leverage pattern is not unchecked autonomy; it is challenged autonomy.');
 arrow(s,3.0,3.3,5.1,3.3); arrow(s,8.25,3.3,10.4,3.3);
 arrow(s,6.65,2.65,6.65,2.25); arrow(s,6.65,4.02,6.65,5.0);
 box(s,'Primary Cell\nexecutes mission',1.2,2.7,1.8,1.0,'111B36',C.cyan,{fs:13,bold:true});
 box(s,'Evidence\nBoundary',5.1,2.85,3.15,0.72,'121B35',C.line,{fs:15,bold:true});
 box(s,'Promotion\nGate',10.4,2.7,1.65,1.0,'0F2B2B',C.mint,{fs:13,bold:true});
 box(s,'Shadow Twin\nreplay/simulate',5.55,1.55,2.2,0.68,'171439',C.violet,{fs:13,bold:true});
 box(s,'Adversarial Council\ncritic · security · regression · cost',4.75,5.0,3.8,0.72,'171439',C.violet,{fs:12,bold:true});
 small(s,'Decision quality improves when disagreement becomes structured evidence, not chat noise.',0.88,6.55,7.0,0.3,C.muted,11);
 validate(s);
}

//10 Readiness
{
 const s=slide(); title(s,'Readiness and Last-Minute Skill-Up','Before deployment, the cell compares the mission against its own health and capability gaps.');
 box(s,'Mission Brief',0.9,2.0,1.75,0.62,'111B36',C.cyan,{fs:13,bold:true}); arrow(s,2.75,2.31,4.0,2.31); box(s,'Capability / Health\nSnapshot',4.05,1.85,2.1,0.92,'171439',C.violet,{fs:12,bold:true}); arrow(s,6.25,2.31,7.42,2.31); box(s,'Gap\nDetector',7.45,2.0,1.45,0.62,'0F2B2B',C.mint,{fs:13,bold:true}); arrow(s,8.98,2.31,10.2,2.31); box(s,'Skill-Up\nPlan',10.25,1.85,1.8,0.92,'111B36',C.cyan,{fs:13,bold:true});
 ['context freshness','tool readiness','domain knowledge','eval familiarity','communication risk','cost risk'].forEach((n,i)=>bar(s,1.1+(i%3)*3.8,3.7+Math.floor(i/3)*0.9,2.6,n,[.78,.66,.52,.84,.44,.58][i],[C.mint,C.cyan,C.amber,C.violet,C.red,C.amber][i]));
 small(s,'Skill-Up is not magic. It is a bounded curriculum/uplift step that trades time for mission-specific readiness.',0.9,6.55,8.0,0.35,C.muted,11.5);
 validate(s);
}

//11 Evolution Chamber
{
 const s=slide(); title(s,'Evolution Chamber: organizational design becomes empirical','Teams, cells and topologies are treated as hypotheses and compared on held-out outcomes.');
 const colx=[1.0,4.55,8.1]; ['Preset A\nSwarm','Preset B\nSenior + Historian','Preset C\nPipeline Line'].forEach((n,i)=>{ box(s,n,colx[i],1.75,2.25,0.8,i===1?'0F2B2B':'111B36',i===1?C.mint:C.cyan,{fs:13,bold:true}); bar(s,colx[i],3.05,2.25,'success', [.84,.96,.88][i], C.mint); bar(s,colx[i],3.75,2.25,'cost efficiency', [.62,.88,.75][i], C.cyan); bar(s,colx[i],4.45,2.25,'risk control', [.78,.92,.81][i], C.violet); });
 arrow(s,3.25,5.65,5.05,5.65); arrow(s,7.15,5.65,8.9,5.65); box(s,'Mission class',1.15,5.3,1.9,0.64,'171439',C.violet,{fs:12,bold:true}); box(s,'Tournament evidence',5.05,5.3,2.1,0.64,'121B35',C.line,{fs:12,bold:true}); box(s,'Doctrine update',8.9,5.3,2.1,0.64,'0F2B2B',C.mint,{fs:12,bold:true});
 validate(s);
}

//12 Research Compiler
{
 const s=slide(); title(s,'Organizational Research Compiler','Research stops being a static report and becomes structured fuel for doctrine and experiments.');
 const rows=[['Question','Search Plan','Sources'],['Claims','Contradictions','Prior Art'],['Architecture Delta','Experiments','Graph Delta']];
 for(let r=0;r<3;r++){for(let c=0;c<3;c++){box(s,rows[r][c],1.05+c*3.65,1.75+r*1.05,2.55,0.62,(r+c)%2?C.panel2:'0F2B2B',(r+c)%2?C.violet:C.mint,{fs:13,bold:true}); if(c<2)arrow(s,3.62+c*3.65,2.06+r*1.05,4.65+c*3.65,2.06+r*1.05);}}
 box(s,'Human Gate\naccept · reject · backlog · run experiment',3.9,5.35,5.45,0.78,'111B36',C.cyan,{fs:15,bold:true}); small(s,'Modes: scout · deep · reconcile · prior-art · refresh · adversarial.',1.05,6.55,8.1,0.3,C.muted,11.5);
 validate(s);
}

//13 UI paradigm
{
 const s=slide(); title(s,'Interface: Agentic IDE, not an agent dashboard','The UI should help an engineer direct artificial organizations.');
 box(s,'Semantic Zoom',0.9,1.7,2.3,0.62,'0F2B2B',C.mint,{fs:14,bold:true}); box(s,'Mission Command',4.05,1.7,2.3,0.62,'111B36',C.cyan,{fs:14,bold:true}); box(s,'Spatial Command',7.2,1.7,2.3,0.62,'171439',C.violet,{fs:14,bold:true}); box(s,'Evidence Inspector',10.35,1.7,2.3,0.62,'0F2B2B',C.mint,{fs:14,bold:true});
 const ladder=['Company','Theatre','Campaign','Operation','Task Force','Squad','Agent','Tool Call']; ladder.forEach((n,i)=>box(s,n,1.25+i*1.33,3.05+i*0.23,1.15,0.35,i%2?C.panel2:'111B36',i%2?C.violet:C.cyan,{fs:8.8,bold:true}));
 small(s,'Minimum useful surface: what is broken, why, what evidence exists, what is blocked, what action is required, and which cell/version is responsible.',0.9,6.35,10.6,0.42,C.muted,12);
 validate(s);
}

//14 Use cases
{
 const s=slide(); title(s,'Use-cases: where Operative Cells become useful first','Pick slices with real evidence and immediate workflow pain.');
 const cases=[['Connector Modernization','API archaeology · auth · implementation · parity'],['Data Model Repair','lineage · workbook/model split · RED→GREEN'],['Reliability Sentinels','freshness · costs · alerts · recurrence'],['Research Compiler','prior art · claims · experiments · doctrine'],['Factory Self-Hosting','bounded maintenance against explicit contracts'],['UI/UX Studio','variant tournament · accessibility · design memory']];
 cases.forEach((c,i)=>{const x=0.85+(i%3)*4.1, y=1.75+Math.floor(i/3)*1.85; box(s,c[0],x,y,3.35,0.48,i%2?C.panel2:'0F2B2B',i%2?C.violet:C.mint,{fs:13,bold:true}); small(s,c[1],x+0.07,y+0.68,3.2,0.42,C.muted,11);});
 validate(s);
}

//15 Prior art fit
{
 const s=slide(); title(s,'Cutting-edge fit: what to borrow, what to protect','Current agent research reinforces the boring-but-powerful substrate: evaluation, governance, recovery and tool distillation.');
 const items=[['Workflow Optimization','Mine successful traces into deterministic meta-tools.'],['Interactive Coding Evals','Evaluate real multi-turn work, not static issue text only.'],['MAPE-K Recovery','Observe → diagnose → plan → execute over shared knowledge.'],['Runtime Governance','Enforce authority/tool/data rules while agents operate.'],['Provenance + Audit','Tie actions to agent, tools, config, evidence and user intent.']];
 items.forEach((it,i)=>{ box(s,it[0],0.95,1.58+i*0.92,3.0,0.48,i%2?C.panel2:'111B36',i%2?C.violet:C.cyan,{fs:12.5,bold:true}); small(s,it[1],4.25,1.68+i*0.92,7.5,0.28,C.ink,11.5); });
 small(s,'External references used in the accompanying source notes: Microsoft AWO/meta-tools, SWE-Together, MAPE-K self-healing, agentic governance and runtime policy guidance.',0.95,6.55,10.8,0.32,C.muted,10.5);
 validate(s);
}

//16 Roadmap
{
 const s=slide(); title(s,'Build roadmap: preserve the moonshot, ship the slice','Do the smallest sequence that makes future autonomy measurable and safe.');
 const steps=[['1','Mission Contract + Org-IR schema'],['2','Typed DAG + evidence objects'],['3','Operative Cell registry + lockfile'],['4','Mission Control UI + proof inspector'],['5','Replay / Shadow Twin on recorded failures'],['6','HyperMESH mission views'],['7','Research Compiler + doctrine gate'],['8','Evolution Chamber + meta-tool distillation']];
 steps.forEach((st,i)=>{ const x=0.95+(i%4)*3.05, y=1.65+Math.floor(i/4)*2.1; box(s,st[0],x,y,0.48,0.48,'0F2B2B',C.mint,{fs:16,bold:true}); small(s,st[1],x+0.66,y+0.04,2.0,0.46,C.ink,11.2); if(i%4!==3) arrow(s,x+2.35,y+0.24,x+2.85,y+0.24); });
 validate(s);
}

//17 Innovation claims
{
 const s=slide(); title(s,'New concepts from this research session','These are the claims worth testing, not asserting.');
 const inn=['Operative Cell as deployable engineering unit','Mission→Cell Compiler','HyperMESH mission-scoped cognition','Readiness / Last-Minute Skill-Up','Proof-Carrying Mission DAG','Shadow Twin + Adversarial Council','Evolution Chamber for organizational presets','Self-Hosting Reliability Corps'];
 inn.forEach((n,i)=>{ const x=1.0+(i%2)*5.8, y=1.55+Math.floor(i/2)*1.15; box(s,n,x,y,4.9,0.55,i%2?C.panel2:'0F2B2B',i%2?C.violet:C.mint,{fs:13,bold:true}); });
 small(s,'Novelty boundary: many primitives have prior art; the differentiated thesis is the composition into a certifiable Agentic Engineering OS.',1.0,6.45,9.8,0.36,C.muted,11.5);
 validate(s);
}

//18 Close
{
 const s=slide();
 s.addText('The next agent is not an agent.', {x:0.85,y:1.4,w:10.9,h:0.7,fontFace:'Aptos Display',fontSize:40,bold:true,color:C.ink,margin:0});
 s.addText('It is a certified Operative Cell: context-aware, governed, replayable, evidence-bearing, and capable of compounding improvement without unchecked self-modification.', {x:0.9,y:2.35,w:8.9,h:1.15,fontSize:23,color:'C9D8F7',margin:0,fit:'shrink'});
 box(s,'ORCA',0.9,4.2,2.2,0.75,'111B36',C.cyan,{fs:28,bold:true});
 small(s,'Operative Runtime, Context & Assurance',3.3,4.4,4.8,0.3,C.mint,14);
 small(s,'Recommended next step: integrate the schema + DAG + registry slice into the real Agent Factory repo, then test against recorded failures and implementation missions.',0.92,6.25,10.4,0.42,C.muted,12);
 validate(s);
}

pptx.writeFile({ fileName: '/mnt/data/agentic_ai_concepts_pack/presentation/ORCA_Agentic_Engineering_OS.pptx' });

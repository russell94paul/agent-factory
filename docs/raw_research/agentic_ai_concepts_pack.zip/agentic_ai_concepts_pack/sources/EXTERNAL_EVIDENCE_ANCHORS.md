# External Evidence Anchors

These were used as current context while building the presentation and HTML. The generated artifacts primarily synthesize the uploaded research corpus.

- Microsoft Research / arXiv, 2026: Agent Workflow Optimization and meta-tools for reducing repeated tool-call patterns.
- SWE-Together, 2026: evaluation of coding agents in realistic multi-turn user sessions.
- MAPE-K self-healing research, 2026: monitor-analyze-plan-execute over a knowledge base as a resilience pattern.
- Agentic governance/security guidance, 2026: runtime controls, tool permissions, provenance, audit trails, and identity risks.
- Production agent evaluation guidance, 2026: combine pre-deployment evals, real-time monitoring, and human feedback.

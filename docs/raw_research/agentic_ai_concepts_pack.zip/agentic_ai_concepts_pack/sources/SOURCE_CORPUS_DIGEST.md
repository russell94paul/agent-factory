# Source Corpus Digest

The input zip was treated as an incomplete but broad research corpus. This digest prioritizes the files with the highest density of Agentic Engineering concepts.

| Score | File | Signal headings |
|---:|---|---|
| 118 | `converted/Agent_Factory_Frontier_Architecture_Prioritization_Pack.md` | Agent Factory Frontier Architecture; Comprehensive business-value, quality, client-trust, and prioritization pack; 1. Executive recommendation; 2. Grounding: cu |
| 108 | `converted/Beyond_Agent_Armies_Frontier_Architectures.md` | Beyond Agent Armies; Frontier organizational hierarchies, multi-layer architectures, and experiments for an Agentic Organization OS; 1. Baseline: what the curre |
| 96 | `agent_factory_chat_design_pack/CHAT_CONSOLIDATED_SPEC.md` | 00 — Master Concept Map; A. Primary Product Paradigm — CURRENT / CORE; Agentic IDE; Mission Command Console; Alternate Army Command World |
| 87 | `agent_factory_chat_design_pack/legacy_reference/ZEUS_World_UI_Research_Pack.md` | ZEUS WORLD UI — CONSOLIDATED RESEARCH PACK; 00 — Baseline and Doctrine; Existing project direction; New research question; Research question |
| 87 | `agent_factory_army_ui_concept_pack/prior_research/ZEUS_World_UI_Research_Pack.md` | ZEUS WORLD UI — CONSOLIDATED RESEARCH PACK; 00 — Baseline and Doctrine; Existing project direction; New research question; Research question |
| 87 | `ZEUS_World_UI_Research_Pack.md` | ZEUS WORLD UI — CONSOLIDATED RESEARCH PACK; 00 — Baseline and Doctrine; Existing project direction; New research question; Research question |
| 65 | `agent_factory_rd_consolidation_pack/11_DEEP_RESEARCH_PROMPTS.md` | Deep Research Prompts; Prompt A — HyperMESH; Objective; Required research; Architecture alternatives |
| 61 | `agent_factory_agent_genome_research_pack/02_DEEP_RESEARCH_BOOT_PROMPT.md` | Deep Research Boot Prompt — Agent Genome & Organizational Hypertuning; PRIMARY OBJECTIVE; CURRENT PROJECT BASELINE — TREAT AS CONSTRAINTS; CORE HYPOTHESIS; A. G |
| 60 | `agent_factory_rd_consolidation_pack/03_HYPERMESH_ARCHITECTURE.md` | HyperMESH Architecture; Working terminology; Recommended near-term topology; Access control; Mission Knowledge View |
| 36 | `agent_factory_rd_consolidation_pack/07_SELF_HOSTING_BUILD_SEQUENCE.md` | Agent Factory Self-Hosting Build Sequence; Goal; AF-SH0 — Agent Factory Self-Hosting Point; Phases; Phase 0 — Research consolidation |
| 36 | `agent-config-research-pack/01-idea-portfolio.md` | Structured idea portfolio; Three example scenarios per major theme; Readiness Uplift Planner; Agent Family / Lineage; Surplus Capacity Queue |
| 32 | `agent-config-research-pack/03-parameter-catalog.md` | Agent and team parameter catalog; 1. Identity, lineage and presentation; 2. Organizational position; 3. Mission applicability; 4. Model and inference |
| 31 | `agent_factory_rd_consolidation_pack/10_RESEARCH_PROGRAM.md` | Sequenced Research Program; Useful web/research search queries; Research hypotheses |
| 31 | `agent_factory_agents_as_configuration_research_pack/01_CONTEXT/MASTER_CONTEXT.md` | Master Context — Agent Factory / Agents-as-Configuration; Product direction; Current architectural themes; New concept cluster; Original "last minute skill-up"  |
| 30 | `agent-config-research-pack/04-team-metrics-and-formulas.md` | Agent-team metrics and formulas; Measurement rules; Team metric families; Agent health; Team health |
| 29 | `agent_factory_agents_as_configuration_research_pack/04_RESEARCH_PROMPTS/02_DEEP_RESEARCH_AGENT_HEALTH_AND_MISSION_READINESS.md` | Deep Research Prompt 02 — Agent Health + Mission Readiness; Core hypothesis; Cross-domain prior art; Agent Health Vector; Team Health Vector |
| 28 | `agent-factory-bootstrap-pack/docs/07-implementation/FEATURE_INTEGRATION_SEEDS.md` | Feature Integration Seeds; 1. Organization Compiler / Org-IR; 2. Agent + Team Health Model; 3. Pre-Deployment Skill-Up / Readiness Boost; 4. Organization Preset |
| 27 | `agent_factory_rd_consolidation_pack/08_PRESET_AGENTS_AND_TEAMS.md` | Preset Agents and Agent Teams; Suggested first Agents; Example Agent presets; Factory Architect; Agent Architect |
| 27 | `agent_factory_rd_consolidation_pack/04_AGENT_HEALTH_READINESS_TRAINING.md` | Agent Health, Mission Readiness and Dynamic Training; Health is not one universal score; Pre-Deployment Skill-Up; Experience is evidence; Curriculum Optimizer |
| 26 | `agent_factory_agents_as_configuration_research_pack/02_CONCEPTS/MISSION_READINESS_AND_READY_UP.md` | Mission Readiness + READY-UP; Core distinction; Agent Health Vector candidate; Mission Requirement Vector; Initial readiness model |
| 26 | `agent-config-research-pack/00-executive-assessment.md` | Executive assessment; Short answer; What the repository already has; Honest evaluation of the new ideas; Highest-value concepts |
| 24 | `agent_factory_chat_design_pack/legacy_reference/Agent Factory Vision.txt` | 1. I would move toward a hybrid monorepo; Keep client/repository estates outside it; 2. GitHub may be the easiest way to give me the whole corpus; 3. I think fl |
| 24 | `agent_factory_army_ui_concept_pack/sources/Agent Factory Vision.txt` | 1. I would move toward a hybrid monorepo; Keep client/repository estates outside it; 2. GitHub may be the easiest way to give me the whole corpus; 3. I think fl |
| 24 | `agent_factory_agents_as_configuration_research_pack/06_SOURCE_MATERIAL/Agent Factory Vision.txt` | 1. I would move toward a hybrid monorepo; Keep client/repository estates outside it; 2. GitHub may be the easiest way to give me the whole corpus; 3. I think fl |
| 24 | `agent_factory_agent_genome_research_pack/source/Agent Factory Vision.txt` | 1. I would move toward a hybrid monorepo; Keep client/repository estates outside it; 2. GitHub may be the easiest way to give me the whole corpus; 3. I think fl |
| 24 | `agent-factory-bootstrap-pack/docs/01-research-corpus/raw/source-snapshots/Agent Factory Vision.txt` | 1. I would move toward a hybrid monorepo; Keep client/repository estates outside it; 2. GitHub may be the easiest way to give me the whole corpus; 3. I think fl |
| 24 | `agent-config-research-pack/02-configuration-and-storage.md` | Agents-as-Configuration: configuration and storage design; Research question; Decision; Why YAML, but not YAML alone; Where CUE may fit |
| 23 | `agent_factory_rd_consolidation_pack/13_DIAGRAM_PACK.md` | Required Diagram Pack; Agent and organization; Knowledge; Configuration / optimization; Learning |
| 22 | `zeus_world_ui_research_pack/06_STATE_AND_INTERACTION_MODEL.md` | 06 — State and Interaction Model; Principle; Core domain entities; Minimum world-facing event taxonomy; Mission |
| 22 | `agent_factory_rd_consolidation_pack/12_CLAUDE_REPO_PACK_PROMPT.md` | Claude Prompt — Create an External Architecture Review Pack; Mission; Create; Record repo identity; Systematically inspect |
| 22 | `agent_factory_chat_design_pack/legacy_reference/zeus_world_ui_research_pack/06_STATE_AND_INTERACTION_MODEL.md` | 06 — State and Interaction Model; Principle; Core domain entities; Minimum world-facing event taxonomy; Mission |
| 22 | `agent_factory_army_ui_concept_pack/prior_research/zeus_world_ui_research_pack/06_STATE_AND_INTERACTION_MODEL.md` | 06 — State and Interaction Model; Principle; Core domain entities; Minimum world-facing event taxonomy; Mission |
| 22 | `agent-factory-deadline-execution-pack-2026-09-02/01_DECISIONS/ARCHITECTURE_SYNTHESIS.md` | Architecture Synthesis — what to build, reuse, defer; 1. North-star framing; 2. Canonical runtime model; Minimal P0 abstraction; 3. Goal-aware adaptive orchestr |
| 22 | `agent-factory-combined-execution-research-pack-v2-2026-09-02/01_DECISIONS/ARCHITECTURE_SYNTHESIS.md` | Architecture Synthesis — what to build, reuse, defer; 1. North-star framing; 2. Canonical runtime model; Minimal P0 abstraction; 3. Goal-aware adaptive orchestr |
| 22 | `agent-config-research-pack/07-repository-change-map.md` | Repository Change Map; Suggested modules; Database additions; UI tabs; What not to build first |

#!/usr/bin/env python3
"""Validate ensemble registries and calculate explainable mission-match scores."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

PRIMITIVE_REQUIRED = {"id", "label", "type", "meaning", "sources", "status", "relations"}
ENSEMBLE_REQUIRED = {
    "id", "name", "members", "operator", "mechanism", "capability", "lineage",
    "failure_modes", "hypothesis", "falsification", "status",
}
DEFAULT_WEIGHTS = {
    "expertise": 0.30,
    "verified_outcomes": 0.22,
    "skill_coverage": 0.15,
    "hypermesh_relevance": 0.12,
    "availability": 0.08,
    "collaboration": 0.08,
    "cost_latency": 0.05,
}


def read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("root must be a JSON object")
    return value


def validate(registry: dict) -> list[str]:
    errors: list[str] = []
    for key in ("schema_version", "sources", "primitives", "ensembles"):
        if key not in registry:
            errors.append(f"missing root field: {key}")
    primitives = registry.get("primitives", [])
    ensembles = registry.get("ensembles", [])
    if not isinstance(primitives, list) or not isinstance(ensembles, list):
        return errors + ["primitives and ensembles must be arrays"]
    ids: set[str] = set()
    primitive_ids: set[str] = set()
    for kind, items, required in (
        ("primitive", primitives, PRIMITIVE_REQUIRED),
        ("ensemble", ensembles, ENSEMBLE_REQUIRED),
    ):
        for index, item in enumerate(items):
            where = f"{kind}[{index}]"
            if not isinstance(item, dict):
                errors.append(f"{where} must be an object")
                continue
            missing = sorted(required - item.keys())
            if missing:
                errors.append(f"{where} missing: {', '.join(missing)}")
            item_id = item.get("id")
            if not isinstance(item_id, str) or not item_id:
                errors.append(f"{where}.id must be a non-empty string")
            elif item_id in ids:
                errors.append(f"duplicate id: {item_id}")
            else:
                ids.add(item_id)
                if kind == "primitive":
                    primitive_ids.add(item_id)
    for index, item in enumerate(ensembles):
        if not isinstance(item, dict):
            continue
        members = item.get("members", [])
        if not isinstance(members, list) or len(members) < 2:
            errors.append(f"ensemble[{index}].members must contain at least two primitive IDs")
        else:
            unknown = sorted(set(members) - primitive_ids)
            if unknown:
                errors.append(f"ensemble[{index}] has unknown members: {', '.join(unknown)}")
    return errors


def score(profile: dict) -> dict:
    gates = profile.get("gates", {})
    failed = sorted(key for key, value in gates.items() if value is not True)
    factors = profile.get("factors", {})
    contributions: dict[str, float] = {}
    for name, weight in DEFAULT_WEIGHTS.items():
        value = float(factors.get(name, 0))
        if not 0 <= value <= 100:
            raise ValueError(f"factor {name} must be between 0 and 100")
        contributions[name] = round(value * weight, 2)
    total = round(sum(contributions.values()), 2)
    return {"eligible": not failed, "failed_gates": failed, "score": total if not failed else None, "contributions": contributions}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    validate_parser = sub.add_parser("validate")
    validate_parser.add_argument("path", type=Path)
    score_parser = sub.add_parser("score")
    score_parser.add_argument("path", type=Path)
    args = parser.parse_args()
    try:
        payload = read_json(args.path)
        if args.command == "validate":
            errors = validate(payload)
            if errors:
                for error in errors:
                    print(f"error: {error}", file=sys.stderr)
                return 1
            print(f"valid: {args.path}")
        else:
            print(json.dumps(score(payload), indent=2))
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

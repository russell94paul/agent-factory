# Ingestion and Ontology

## Ingestion Sequence

1. Inventory sources with identifiers, type, version/date, scope, and readable status.
2. Extract primitives in batches while retaining source references.
3. Normalize only after extraction so original distinctions remain visible.
4. Resolve aliases conservatively; keep disputed terminology as explicit conflict objects.
5. Produce coverage: fully read, partially read, unread, unsupported, and duplicate.

## Primitive Types

`term`, `definition`, `entity`, `relation`, `principle`, `concept`, `pattern`, `technique`, `protocol`, `algorithm`, `data_structure`, `architecture`, `framework`, `component`, `tool`, `storage_model`, `metric`, `constraint`, `claim`, `evidence`, `failure`, `question`.

## Minimum Primitive Fields

- stable ID and canonical label;
- primitive type and CELL OS layer/domain;
- source wording and normalized meaning;
- source references;
- confidence and status;
- aliases and typed relations;
- scope, authority, state and temporal behavior when applicable;
- evidence status: canonical, observed, cited, inferred, proposed, or disputed.

## Relation Vocabulary

Use `same_as`, `candidate_alias_of`, `overlaps`, `conflicts_with`, `extends`, `specializes`, `composes`, `implements`, `requires`, `governs`, `stores`, `retrieves`, `emits`, `consumes`, `selects`, `evaluates`, `repairs`, `supersedes`, and `derived_from`.

## Conflict Object

Record competing definitions, affected primitives, source positions, practical consequence, temporary working decision, confidence, and resolution owner. Never resolve a terminology dispute simply because one wording appears more often.

# CELL OS Builder Walkthrough

## Primary Story

Use a concrete user and business mission. Move from baseline friction to configuration, live Cell behavior, positive evidence, and measured or explicitly modeled impact. Do not put a marketing hero before the working surface.

## Builder Flow

1. Business brief: user, baseline, constraints, target metric, proof required.
2. Operative DNA: type, model profile, skills, tools, authority and budgets.
3. HyperMesh: C-MESH/T-MESH/OS-MESH with a plain-language trade-off and architecture preview.
4. Cell assembly: ranked candidates, factor contribution, gates, complementarity and alternatives.
5. Mission run: shared simulation event stream drives node state, edge packets, logs, metrics, captions and narration.
6. Impact: before/after, confidence, source, timeframe and observed/projected/modeled/hypothesized label.
7. Blueprint: versioned configuration, evaluation status, rollback and export.

## Simulation Events

Support `SIM_START`, `NODE_ENTER`, `INPUT_REVEAL`, `EDGE_TRANSFER`, `NODE_PROCESS`, `OUTPUT_REVEAL`, `METRIC_UPDATE`, `LOG_APPEND`, `BRANCH`, `RETRY`, `FAILURE`, `RECOVERY`, `NODE_EXIT`, and `SIM_COMPLETE`.

## Interaction Requirements

Allow pause, resume, restart, speed control, captions, optional user-started narration, reduced motion, keyboard navigation, node inspectors, and explicit failure/recovery states. Motion shows causality; it is never the only status signal.

## Metric Integrity

Tag each metric as `observed`, `projected`, `modeled`, or `hypothesized`. Show baseline, comparison window, formula, evidence source, confidence, and important caveats. Fictional walkthroughs must never be styled as testimonials.

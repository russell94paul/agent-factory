# Ensemble Synthesis

## Composition Grammar

Construct candidates as:

`Ensemble = members + operator + interaction boundary + control policy + state + evidence + adaptation`

Members alone are not an ensemble. The interaction must produce a capability not available from isolated members.

## Composition Operators

- **Bridge:** connect two domains through a typed boundary.
- **Fuse:** create one mechanism from complementary primitives.
- **Layer:** place one primitive above/below another as control or substrate.
- **Federate:** preserve local autonomy while exchanging governed summaries.
- **Temporalize:** add leases, expiry, replay, bitemporal truth, or delayed commitment.
- **Dualize:** pair execution with an independent verifier, shadow, or counterfactual path.
- **Marketize:** allocate attention, tools, or seats through utility and constraints.
- **Compile:** translate high-level intent into executable contracts and blueprints.
- **Materialize:** turn expensive reasoning into versioned reusable state with invalidation.
- **Reflexivize:** let a system observe and modify a strictly bounded part of itself.
- **Invert:** move control from a supervisor into a contract, protocol, or environment.
- **Adversarialize:** require challenge, contradiction handling, or red-team evidence.

## Candidate Card

Include name, one-sentence mechanism, member IDs, operator, emergent capability, target mission, architecture view, expected measurable effect, closest alternative, distinctness, incompatibilities, authority, state, failure modes, self-maintenance behavior, smallest vertical slice, acceptance threshold, and kill criteria.

## Compatibility Checks

Check semantic compatibility, input/output fit, time horizon, state ownership, consistency, authority, privacy, failure behavior, cost/latency, evaluation compatibility, and lifecycle. A productive tension may remain when a mediator or contradiction protocol makes it explicit.

## Anti-Novelty Theater

Reject candidates that only concatenate names, restyle known architecture, swap a model, add an agent without causal need, depend on undefined “intelligence,” or lack evidence that could disprove the value claim.

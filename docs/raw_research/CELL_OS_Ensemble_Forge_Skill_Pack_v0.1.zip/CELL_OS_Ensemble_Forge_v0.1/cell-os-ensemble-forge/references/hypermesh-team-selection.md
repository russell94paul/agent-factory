# HyperMesh and Team Selection

These are provisional functional profiles. Replace them with user-canonical definitions when supplied.

## HyperMesh Profiles

| Profile | Functional scope | Strong fit | Primary risks |
| --- | --- | --- | --- |
| C-MESH | Cell-local cognitive and working memory | low-latency private coordination inside one Cell | silos, low reuse, duplicated learning |
| T-MESH | shared mission memory and routing across cooperating teams | specialist collaboration with bounded cross-team knowledge | ownership conflicts, context amplification, stale subscriptions |
| OS-MESH | federated organization-wide knowledge and capability exchange | cross-domain reuse, fleet learning, enterprise coordination | governance, leakage, global blast radius, consistency cost |

For every selection define topology, membership, memory classes, authoritative stores, retrieval paths, exchange protocol, provenance, consistency, invalidation, permissions, tenancy, retention, partitions, recovery, observability, and upgrade compatibility.

## Operative DNA

An Operative profile includes role and mission class; model profile; skills and tool contracts; input/output schemas; local and mesh memory; authority; resource budget; verification; historical outcomes by regime; collaboration behavior; availability; lifecycle; and repair level.

## Mission-Match Formula

Default starting weights, adjustable per mission:

- mission/domain expertise: 30%;
- verified outcomes in similar conditions: 22%;
- skill adjacency and coverage: 15%;
- HyperMesh relevance and knowledge access: 12%;
- availability/capacity: 8%;
- collaboration compatibility: 8%;
- cost/latency fit: 5%.

Apply hard gates before weighting: permissions, conflicts of interest, data boundary, minimum reliability, required tools, availability, budget, model compatibility, and safety policy.

## Team-Level Optimization

Optimize the Cell, not only individual scores. Account for coverage, role complementarity, redundancy, diversity of evidence/reasoning paths, correlated failure, communication load, hierarchy depth, human gates, and cost. A lower-ranked Operative may improve the Cell when it fills a missing skill or reduces correlated risk.

Always show why each seat was chosen, close alternatives, weak factors, exclusions, confidence, and what would change the recommendation.

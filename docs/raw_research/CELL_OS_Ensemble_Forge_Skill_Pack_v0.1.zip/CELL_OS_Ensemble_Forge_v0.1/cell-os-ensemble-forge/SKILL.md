---
name: cell-os-ensemble-forge
description: Ingest research, terminology, entities, architectures, and evidence; normalize them into a provenance-aware concept graph; synthesize traceable ensemble concepts and ensemble entities; and translate strong candidates into CELL OS Operatives, HyperMesh configurations, team-match policies, experiments, and UI blueprints. Use when combining substantial concept collections or designing CELL OS from heterogeneous source material; do not use for simple summarization or unsupported novelty claims.
---

# CELL OS Ensemble Forge

Convert heterogeneous research into new, traceable system designs. Preserve the source lineage, semantic conflicts, and uncertainty behind every ensemble.

## Definitions

- **Primitive:** one normalized concept, term, entity, mechanism, architecture, constraint, claim, metric, or technology.
- **Ensemble concept:** a new candidate mechanism created from two or more compatible primitives whose interaction produces a specific capability.
- **Ensemble entity:** a typed CELL OS entity assembled from primitives, such as an Operative, Cell, HyperMesh profile, team blueprint, memory structure, protocol, or maintenance loop.
- **HyperMesh:** the governed knowledge and coordination fabric used by Operatives and Cells. Preserve user-provided definitions; if none exist, use the provisional functional profiles in [hypermesh-team-selection.md](references/hypermesh-team-selection.md).

## Choose the Mode

- **Ingest and map:** read [ingestion-ontology.md](references/ingestion-ontology.md).
- **Generate ensembles:** read [ensemble-synthesis.md](references/ensemble-synthesis.md).
- **Build Operatives and teams:** read [hypermesh-team-selection.md](references/hypermesh-team-selection.md).
- **Design a builder UI or guided story:** read [ui-walkthrough.md](references/ui-walkthrough.md).
- **Create an end-to-end package:** read all four in that order.

## Workflow

### 1. Establish the mission and source boundary

Identify the target capability, decisions the ensemble must support, intended users, technical environment, authority, risks, evaluation budget, and source collection. Inventory every file or source before deep extraction. Never imply that unread material was ingested.

### 2. Extract typed primitives

For each source, extract terms, definitions, aliases, entities, relations, mechanisms, architectures, constraints, claims, evidence, metrics, failures, and open questions. Attach a stable source reference and exact location when available.

Do not silently merge homonyms, competing definitions, or terms whose canonical meaning is unsettled. Record `same_as`, `overlaps`, `conflicts_with`, `extends`, or `candidate_alias_of` relations instead.

### 3. Build the concept graph

Normalize names and types, retain source wording, connect typed relations, and mark confidence. Separate:

- user-canonical CELL OS terminology;
- imported prior art;
- inferred relations;
- proposed primitives;
- measured evidence.

Validate the JSON registry with `scripts/ensemble_tools.py validate <registry.json>` when using the provided schema.

### 4. Generate ensemble portfolios

Use compatibility-driven composition rather than random pairing. Produce three bands:

- **Grounded:** strong compatibility and established components.
- **Adjacent:** a distinctive cross-domain composition.
- **Frontier:** a new interaction, protocol, topology, adaptive loop, or data structure.

Every candidate must declare its members, composition operator, emergent mechanism, expected outcome, closest alternatives, conflicts, new failure modes, and falsification test. Reject a candidate that is only a new name for existing members.

### 5. Materialize ensemble entities

Translate shortlisted concepts into one or more typed entities:

- Operative DNA: role, model profile, skills, tools, memory, authority, budgets, evaluators, lifecycle;
- Cell blueprint: mission, seats, deterministic services, stages, gates, evidence, recovery;
- HyperMesh profile: topology, scope, memory classes, exchange rules, governance, consistency, invalidation;
- team-selection policy: required gates, weighted factors, exclusions, diversity and redundancy;
- experiment: baseline, workload, metrics, acceptance, kill criteria, replay and rollback.

### 6. Score without hiding judgment

Score causal value, semantic compatibility, mechanism distinctness, coherence, implementability, measurability, interoperability, safety/governance, cost/latency, self-maintenance, and option value. Show the factor scores and uncertainty; never let a weighted average override a hard safety or authority gate.

### 7. Produce the user experience

When a UI is requested, make the primary flow immediately usable:

`business mission → Operative type → model profile → skills → HyperMesh → match explanation → Cell assembly → shadow run → evidence → modeled impact`

Use one shared simulation event stream for mesh animation, node state, logs, metrics, narration, and captions. Clearly label fictional or modeled business results.

## Required Outputs

Choose the smallest complete set:

- source inventory and ingestion coverage;
- normalized glossary/entity registry;
- concept graph and unresolved semantic conflicts;
- ensemble candidate portfolio;
- ensemble entity cards and lineage;
- recommended CELL OS blueprint;
- team-match explanation;
- experiment and rollout plan;
- interactive or implementation-ready UI walkthrough.

## Quality Gates

- Every ensemble traces to primitives and sources.
- Every proposed emergence has a causal mechanism and falsification test.
- Canonical terminology is never overwritten by an inference.
- Match scores expose factors, exclusions, uncertainty, and hard gates.
- Model choice is a profile decision, not an unexplained brand preference.
- HyperMesh scope, consistency, privacy, invalidation, and failure behavior are explicit.
- Self-maintenance specifies what may change, who evaluates it, attempt caps, promotion gates, and rollback.
- Business outcomes distinguish observed results, projections, modeled scenarios, and hypotheses.

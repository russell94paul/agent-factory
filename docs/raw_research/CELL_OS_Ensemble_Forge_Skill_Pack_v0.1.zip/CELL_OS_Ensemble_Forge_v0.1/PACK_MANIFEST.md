# CELL OS Ensemble Forge v0.1

An installable skill for ingesting research, terminology and entities; building a provenance-aware concept graph; synthesizing ensemble concepts/entities; and producing Operative, HyperMesh, team-match, experiment and UI blueprints.

The pack contains the skill, ingestion ontology, ensemble grammar, HyperMesh/team selection model, builder walkthrough specification, reusable assets, and a tested zero-dependency validation/scoring utility.

# Visual Sources

These `.mmd` files are Mermaid diagram sources intended for rendering in Markdown/HTML tooling that supports Mermaid.

Included:
- CELL_OS_Concept_Map.mmd
- Mesh_Architecture_Gallery.mmd
- Link_Fabric.mmd
- Adaptive_Organization.mmd
- Federation.mmd
- Mission_Compilation.mmd

They are deliberately source-format diagrams so the research/design team can modify them as terminology changes.

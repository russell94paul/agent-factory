# Product Expansion Hypotheses

## Core product thesis
CELL OS may have three product layers over one runtime:

1. **CELL OS Pro** — agentic engineering, research and technical organizations.
2. **CELL OS Business** — synthetic staff / operating system for solo and small businesses.
3. **CELL OS Personal** — personal operating system for career, home, learning, creative work and administration.

## UX hypothesis
The normal user should not start with "Create Operative" or "Configure Mesh".

Potential top-level onboarding question:

> **What would you like your organization to take care of?**

Potential domains:
- Business
- Career
- Work
- Research
- Home
- Creative
- Performance
- Other

## Product moat hypotheses to test
- persistent synthetic organizations
- reusable organizational software (versioned Cell Blueprints/Images)
- organizational learning: which team/topology/link configuration works for which mission class
- progressive disclosure: simple at the surface, inspectable underneath
- evidence/assurance as a product feature rather than developer-only telemetry

## Important caution
These are product hypotheses, not claims of uniqueness. Deep research must compare them with contemporary products and prior art before asserting novelty.

# CELL OS — Experiment Catalog & Templates

## Standard experiment card

```text
EXPERIMENT ID:
TITLE:
HYPOTHESIS:
WHY IT SHOULD WORK:
SOURCE / PRIOR ART BASIS:
BASELINE:
INTERVENTION:
MISSION SET:
PRIMARY METRIC:
SECONDARY METRICS:
GUARDRAILS:
FAILURE CRITERIA:
REPLICATION / SAMPLE PLAN:
PROMOTION RULE:
ROLLBACK RULE:
STATUS: proposed | sandbox | shadow | canary | promoted | rejected
```

## Core experiment families

### E1 — Adaptive organizational complexity
Compare fixed large Meshes with progressive escalation:

```text
Solo → Specialist → Small Mesh → Council → Human Gate
```

Measure verified success, cost/success, latency, number of models invoked, human interventions and false-green rate.

### E2 — Mesh architecture tournament
Run identical mission classes through:
- solo
- pipeline
- parallel
- hierarchy
- council
- swarm
- hybrid

Measure quality/$, quality/second, reliability and coordination overhead.

### E3 — Link communication protocol
Compare:
- free-form natural-language link
- typed structured link
- contract-only compressed link
- adaptive link

Measure tokens transferred, error propagation, latency, information retention and downstream quality.

### E4 — Context compilation
Compare:
- full context
- generic RAG
- role-specific context
- mission-compiled context
- adaptive context paging

Measure retrieval relevance, context size, cost, latency, contradiction/staleness rate and task quality.

### E5 — Agentic crystallization
Mine repeated successful tool/reasoning sequences, convert candidates into deterministic composite tools, and replay the same mission set.

Measure variance, failure rate, cost, latency and maintainability.

### E6 — Proof-carrying execution
Compare ordinary workflow success states with evidence-gated completion.

Primary metric: false-green reduction.

### E7 — Link topology optimization
For a fixed set of Operatives, vary who can communicate/delegate/consult and under which contracts.

Measure coordination cost, mission quality, information leakage and robustness.

### E8 — Trust-aware routing
Compare static routing against contextual trust-based routing by domain and task type.

### E9 — Human-in-the-loop placement
Move human gates earlier/later or make them risk-adaptive. Measure burden, safety, speed and rework.

### E10 — Cell-as-a-Service
Compare embedding a specialist Operative in every Cell versus calling a reusable specialist Cell through a capability/link contract.

### E11 — Shadow organization
Run candidate organization configurations in replay/shadow mode before promotion. Measure prediction quality between shadow and live outcomes.

### E12 — Self-profiler accuracy
Ask a Cell to identify its own causal bottlenecks from traces and compare against deterministic profiling evidence.

## Promotion discipline

No architecture proposal should be promoted solely because it sounds elegant or because one demonstration succeeds. Prefer:

```text
proposal
→ offline eval
→ representative replay
→ shadow
→ canary
→ monitored promotion
→ rollback path retained
```

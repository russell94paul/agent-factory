# CELL OS — Frontier Audit Research Pack

This bundle consolidates the current terminology/ontology pass, the deep research audit prompt, experiment templates, product-expansion/persona work, editable diagram sources, existing presentation/web artifacts, and the accessible master/source research archives.

## Recommended order

1. `01_CANONICAL_ONTOLOGY/CELL_OS_Canonical_Terminology_vNext.md`
2. `01_CANONICAL_ONTOLOGY/KNOWN_TERMINOLOGY_COLLISIONS.md`
3. `02_DEEP_RESEARCH/CELL_OS_Frontier_Product_Architecture_Innovation_Audit_MASTER_PROMPT.md`
4. `02_DEEP_RESEARCH/REPORT_OUTPUT_REQUIREMENTS.md`
5. `03_EXPERIMENTATION/Experiment_Catalog_and_Templates.md`
6. `04_PRODUCT_EXPANSION/Five_Persona_Product_Lenses.md`
7. `05_VISUALS/`
8. `06_PRESENTATION_AND_WEB/`
9. `07_SOURCE_ARCHIVES/`

## Folder map

```text
CELL_OS_Frontier_Audit_Research_Pack/
├── 00_START_HERE/
├── 01_CANONICAL_ONTOLOGY/
├── 02_DEEP_RESEARCH/
├── 03_EXPERIMENTATION/
├── 04_PRODUCT_EXPANSION/
├── 05_VISUALS/
├── 06_PRESENTATION_AND_WEB/
└── 07_SOURCE_ARCHIVES/
```

## Important terminology note

This pack uses the current proposed distinction:

- **Operative** — individual intelligent computational worker
- **Cell Mesh** — team/topology of Operatives
- **Cell** — bounded mission-execution unit
- **Link** — typed relationship between entities
- **Organization** — coordinated collection of Cells
- **CELL OS** — operating/control system over the organization

Older material may use `CELL Mesh` for OS-to-OS federation or `Operative Cell` for the bounded deployable unit. Those historical terms are intentionally preserved in source archives; the deep research audit is asked to reconcile them rather than silently rewrite history.

## Source preservation

`07_SOURCE_ARCHIVES/` preserves the accessible source/master archives rather than destructively de-duplicating them. Some archives overlap by design because they represent different research generations and provenance.

## Research objective

The intended next step is to run the master prompt against the source corpus and obtain an adversarial report that:
- validates or rejects architecture concepts;
- identifies high-leverage performance improvements;
- identifies new product capabilities;
- finds simpler terminology and architecture where possible;
- designs experiments rather than asserting novelty;
- proposes UI/UX that can hide technical complexity from nontechnical users;
- ranks market-expansion opportunities.

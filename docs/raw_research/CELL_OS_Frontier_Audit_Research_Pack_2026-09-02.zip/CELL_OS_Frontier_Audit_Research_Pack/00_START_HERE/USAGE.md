# Suggested Usage

## For Deep Research
Upload or attach this complete ZIP and instruct the research system to:

1. Treat `01_CANONICAL_ONTOLOGY` as the current proposed ontology, not as proven truth.
2. Use `07_SOURCE_ARCHIVES` as the historical/source corpus.
3. Execute the prompt in `02_DEEP_RESEARCH`.
4. Preserve the evidence labels SOURCE-DERIVED / PRIOR ART / NEW SYNTHESIS / SPECULATIVE.
5. Return all required visuals, decision tables and experiment plans.

## For Claude Code / repository work
Extract the pack into a research area rather than production source code, e.g.:

```text
research/cell-os-frontier-audit/
```

Do not promote terminology changes into production schemas until the ontology audit is reviewed.

## For presentation work
The existing `.pptx` and HTML artifacts are preserved under `06_PRESENTATION_AND_WEB`. They predate some of the latest terminology refinements and should be treated as design history / presentation baselines, not canonical technical truth.

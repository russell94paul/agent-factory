# Research Report Output Requirements

The final report should include:

## Mandatory lenses
1. Frontier AI / multi-agent systems
2. Distributed systems / OS / durable workflow
3. HCI / product design / progressive disclosure
4. Organizational science / collective intelligence
5. Security / governance / assurance
6. Performance engineering / cost / latency
7. Commercial product strategy / market expansion
8. Adversarial simplicity / architecture reduction

## Evidence labels
Every major claim or proposal must be marked as one of:
- SOURCE-DERIVED
- PRIOR ART
- NEW SYNTHESIS
- SPECULATIVE

## Mandatory decisions
For every major current concept, output one of:
- KEEP
- RENAME
- MERGE
- RETIRE
- INVESTIGATE

## Mandatory prioritization
Every proposed feature must be assigned:
- NOW
- NEXT
- LATER
- RESEARCH
- DO NOT BUILD

## Mandatory top lists
- Top 5 performance breakthroughs
- Top 5 capability breakthroughs
- Top 5 nontechnical UX breakthroughs
- Top 5 market-expansion features
- Top 5 research bets
- Top 5 things to remove

## Mandatory visuals
At least 20 information-bearing diagrams/visuals as listed in the master prompt.

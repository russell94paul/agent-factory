# CELL OS Invention & Engineering Skill Pack v0.1

## Purpose

This installable skill turns CELL OS capability ideas into classified concepts, architecture portfolios, protocols, technical designs, experiments, and implementation plans.

## Included

- `cell-os-invention-engine/SKILL.md` — coordinating workflow and quality gates.
- `references/taxonomy.md` — categories spanning architectures, concepts, frameworks, techniques, components, tools, databases, KGs, vector systems, and maturity.
- `references/invention-method.md` — morphological design, innovation operators, novelty filter, and scoring.
- Four domain laboratories — communication, integration, memory/data, and processing.
- `references/autonomy-maintenance.md` — bounded self-maintenance and evolution loops.
- `references/implementation-evaluation.md` — vertical slices, experiments, metrics, rollout, and evaluation threats.
- Reusable concept, portfolio, experiment, implementation, and registry templates.
- A zero-dependency registry initialization and validation script.

## Install

Copy the `cell-os-invention-engine` directory into a Codex skills directory. Keep the directory intact so its references, templates, and script remain available.

## Recommended First Uses

1. Map current CELL OS concepts into the taxonomy and innovation registry.
2. Produce communication, integration, memory, processing, and self-maintenance architecture portfolios.
3. Select one high-leverage candidate per domain and specify a falsifiable vertical slice.
4. Run historical replay and shadow-mesh experiments before granting production authority.

## Version Intent

v0.1 establishes the operating method and reusable vocabulary. Future versions should evolve from observed use, evaluation results, and repeated failure modes rather than accumulating speculative rules.

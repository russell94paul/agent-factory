---
name: cell-os-invention-engine
description: Classify, invent, architect, prototype, and evaluate CELL OS and general agentic-system concepts, especially Operative Cells, Cell Meshes, communication, integrations, memory and knowledge, data processing, and self-maintenance. Use for capability invention, architecture alternatives, concept registries, technical specifications, experiments, and implementation roadmaps; do not use for ordinary application feature work with no agentic-systems design component.
---

# CELL OS Invention Engine

Turn agentic ideas into named, classified, testable system designs. Preserve the distinction between a promising hypothesis, a recombination of prior art, and a demonstrated innovation.

## CELL OS Grounding

- An **Operative** is an agentic execution unit with a bounded role, capabilities, authority, state, and lifecycle.
- An **Operative Cell** is a mission-oriented composition of Operatives, deterministic services, tools, memory, policies, and evaluation gates.
- A **Cell Mesh** is a topology of Operative Cells. Meshes may be hierarchical, nested, federated, peer-to-peer, or linked into larger structures.
- A **Mission** is a versioned objective with constraints, success evidence, budget, authority, and termination conditions.
- Treat deterministic components as first-class CELL OS members. Use agents where interpretation, synthesis, negotiation, or novel diagnosis is valuable; use deterministic code for enforceable contracts, validation, routing, accounting, and safety boundaries.

## Select the Working Mode

1. **Map** — inventory or categorize concepts and technology. Read [taxonomy.md](references/taxonomy.md).
2. **Invent** — generate new mechanisms, protocols, frameworks, or architectures. Read [invention-method.md](references/invention-method.md) plus the relevant domain reference.
3. **Architect** — compare topologies and make a decision. Read the relevant domain reference and [implementation-evaluation.md](references/implementation-evaluation.md).
4. **Implement** — produce contracts, schemas, stages, failure handling, a thin vertical slice, and migration plan. Read [implementation-evaluation.md](references/implementation-evaluation.md).
5. **Evaluate** — design simulations, adversarial cases, metrics, and kill criteria. Read [implementation-evaluation.md](references/implementation-evaluation.md).
6. **Evolve** — design observation, diagnosis, repair, upgrade, validation, rollback, and learning loops. Read [autonomy-maintenance.md](references/autonomy-maintenance.md).

Use only the references needed for the current request:

- Communication and coordination: [communication.md](references/communication.md)
- Tools, APIs, apps, services, and cross-system action: [integration.md](references/integration.md)
- Databases, KGs, vector stores, memory, provenance, and retrieval: [memory-data.md](references/memory-data.md)
- Batch, stream, event, semantic, and reasoning pipelines: [processing.md](references/processing.md)
- Self-maintenance, autonomy, resilience, and evolution: [autonomy-maintenance.md](references/autonomy-maintenance.md)

## Core Workflow

### 1. Frame the design problem

Capture the mission, actors, environment, latency, scale, risk, cost ceiling, data sensitivity, authority, current baseline, and measurable success. Ask only for missing facts that materially change the design; otherwise state assumptions.

### 2. Classify before naming

Assign every item coordinates from the taxonomy: artifact type, CELL OS layer, domain, scope, topology, temporal mode, state model, authority, and maturity. Distinguish concepts from components, protocols from transports, architectures from implementations, database categories from products, memory policies from storage engines, and agent reasoning from deterministic processing. Never present a tool list as an architecture.

### 3. Establish the novelty boundary

When novelty matters, inspect current primary sources and relevant prior art. Mark elements as **Known**, **Adapted**, **Composed**, **Hypothesized**, or **Validated**. Do not claim “first,” “novel,” or “patentable” without a dedicated search. Name hypotheses provisionally.

### 4. Generate a portfolio, not one answer

Produce at least three meaningfully different candidates when inventing:

- **Grounded:** low-risk improvement using proven primitives.
- **Adjacent:** new composition or control policy.
- **Frontier:** new protocol, data structure, market, topology, or adaptation loop.

Vary mechanisms, not cosmetic labels. Use the morphologies in [invention-method.md](references/invention-method.md).

### 5. Express each architecture through consistent views

Describe mission and boundary; topology and roles; control and authority; communication and coordination; data, memory, and provenance; processing and runtime; and trust, observability, failure recovery, and lifecycle. Use a compact Mermaid diagram when relationships or event order are material. Keep exact mappings in tables.

### 6. Make the concept buildable

For shortlisted candidates specify commands, events, queries, states, schemas, versioning, invariants, ownership, idempotency, ordering, concurrency, timeouts, retries, backpressure, cancellation, permissions, secrets, auditability, human gates, observability, positive proof of success, degraded modes, repair, rollback, safe shutdown, compatibility, migration, and the smallest vertical slice that can falsify the hypothesis.

### 7. Evaluate honestly

Define a baseline, hypothesis, workload, metrics, adversarial cases, acceptance threshold, and kill criteria before implementation. Prefer outcome measures such as mission success, accepted-change rate, cost per accepted result, time-to-green, regression rate, recovery time, and human rework. Activity counts are diagnostic, not success.

Test self-maintenance loops with fault injection and replay. Bound every repair loop by budgets, attempt caps, escalating authority, and rollback.

## Standard Deliverables

Choose the smallest complete package:

- **Concept Card** — one candidate, classification, mechanism, value, risks, and test.
- **Architecture Portfolio** — candidates plus trade-off matrix and recommendation.
- **Technical Design** — views, contracts, data model, lifecycle, and failure model.
- **Experiment Charter** — hypothesis, baseline, workload, metrics, and kill criteria.
- **Reference Implementation Plan** — vertical slice, interfaces, work packages, tests, and rollout.
- **Innovation Registry** — deduplicated concepts, relations, evidence, maturity, owners, and results.

Copy templates from `assets/templates/` when creating these artifacts. Use `scripts/concept_registry.py` to initialize or validate a JSON registry.

## Non-Negotiable Quality Gates

- Every named invention has a precise mechanism, not only a metaphor.
- Every architecture states ownership, state, authority, and failure behavior.
- Every autonomous action has permissions, budgets, termination, evidence, and rollback.
- Every self-improvement claim identifies what changes, what evaluates it, what cannot change automatically, and how promotion is gated.
- Every storage proposal separates logical memory behavior from the physical database product.
- Every recommendation explains why simpler alternatives are insufficient.
- Unknowns and evidence gaps remain visible.

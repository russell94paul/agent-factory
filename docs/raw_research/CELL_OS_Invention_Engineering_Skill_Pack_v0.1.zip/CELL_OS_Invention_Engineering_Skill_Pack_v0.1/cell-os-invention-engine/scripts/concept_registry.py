#!/usr/bin/env python3
"""Initialize and validate a lightweight CELL OS innovation registry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys


ARTIFACT_TYPES = {
    "principle", "concept", "pattern", "technique", "protocol", "algorithm",
    "data-structure", "architecture", "framework", "component", "tool-product",
    "metric-evaluation",
}
MATURITY = {
    "seed", "framed", "prior-art-checked", "specified", "prototyped",
    "simulated", "validated", "piloted", "production", "deprecated",
}
REQUIRED = {
    "id", "name", "summary", "artifact_type", "layers", "domains", "scope",
    "maturity", "mechanism", "hypothesis", "evidence", "relations",
}


def load(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("registry root must be an object")
    return value


def validate(registry: dict) -> list[str]:
    errors: list[str] = []
    if not isinstance(registry.get("registry_version"), str):
        errors.append("registry_version must be a string")
    concepts = registry.get("concepts")
    if not isinstance(concepts, list):
        return errors + ["concepts must be an array"]
    seen: set[str] = set()
    for index, concept in enumerate(concepts):
        where = f"concepts[{index}]"
        if not isinstance(concept, dict):
            errors.append(f"{where} must be an object")
            continue
        missing = sorted(REQUIRED - concept.keys())
        if missing:
            errors.append(f"{where} missing: {', '.join(missing)}")
        concept_id = concept.get("id")
        if not isinstance(concept_id, str) or not concept_id.strip():
            errors.append(f"{where}.id must be a non-empty string")
        elif concept_id in seen:
            errors.append(f"{where}.id duplicates {concept_id!r}")
        else:
            seen.add(concept_id)
        if concept.get("artifact_type") not in ARTIFACT_TYPES:
            errors.append(f"{where}.artifact_type is not recognized")
        if concept.get("maturity") not in MATURITY:
            errors.append(f"{where}.maturity is not recognized")
        for field in ("layers", "domains", "evidence", "relations"):
            if field in concept and not isinstance(concept[field], list):
                errors.append(f"{where}.{field} must be an array")
    return errors


def init(path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite {path}")
    path.write_text(
        json.dumps(
            {"registry_version": "0.1.0", "cell_os_version": "unassigned", "concepts": []},
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    init_parser = sub.add_parser("init")
    init_parser.add_argument("path", type=Path)
    validate_parser = sub.add_parser("validate")
    validate_parser.add_argument("path", type=Path)
    args = parser.parse_args()
    try:
        if args.command == "init":
            init(args.path)
            print(f"initialized {args.path}")
            return 0
        errors = validate(load(args.path))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if errors:
        for error in errors:
            print(f"error: {error}", file=sys.stderr)
        return 1
    print(f"valid: {args.path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

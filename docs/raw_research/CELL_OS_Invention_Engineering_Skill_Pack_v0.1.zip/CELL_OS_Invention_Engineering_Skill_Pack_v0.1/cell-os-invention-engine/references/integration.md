# Agentic Integration Architectures

An integration architecture must govern discovery, authorization, execution, evidence, and recovery—not merely expose tools.

## Integration Layers

1. **Capability catalog:** actions, versions, schemas, owners, risk, cost, latency, and health.
2. **Semantic contract:** business meaning, preconditions, invariants, and expected proof.
3. **Policy membrane:** identity, authority, consent, budgets, secrets, data boundaries, and approval.
4. **Execution adapter:** protocol translation, validation, idempotency, rate limits, and retries.
5. **Transaction/evidence envelope:** correlation, before/after state, receipts, compensation, and audit.
6. **Observation plane:** traces, failures, quotas, drift, and service-level objectives.

## Architecture Families

Direct tool binding; adapter/anti-corruption layer; tool gateway/capability membrane; event-driven integration; workflow/saga orchestration; choreography among Cells; federated capability exchange; and shadow/digital-twin integration for simulation.

## Candidate Mechanisms

- **Capability Membrane:** every action passes discovery → policy → optional simulation → execution → evidence → reconciliation.
- **Semantic Handshake:** Cell and adapter negotiate schema, meaning, authority, side effects, and proof before execution.
- **Transactional Action Envelope:** wraps non-transactional APIs with idempotency, expected state, receipt, compensation, and reconciliation.
- **Tool Shadow Twin:** safe tool model for planning, dry runs, fault injection, and compatibility tests.
- **Evidence-Bearing Connector:** emits positive domain evidence that intended state changed, not only an HTTP result.
- **Adaptive Integration Cell:** monitors failures and routes between compatible adapters while policy prevents silent semantic change.
- **Capability Federation:** Cells advertise bounded capabilities and terms without unrestricted authority.

## Contract and Testing

Define commands, queries, events, side effects, pre/postconditions, idempotency, consistency, retry classes, compensation, limits, secrets, residency, evidence, ownership, compatibility, and deprecation.

Test credential expiry, revoked scope, partial success, duplicate action, stale read, rate limit, schema change, partition, wrong environment, semantic mismatch, missing receipt, compensation failure, and provider outage.

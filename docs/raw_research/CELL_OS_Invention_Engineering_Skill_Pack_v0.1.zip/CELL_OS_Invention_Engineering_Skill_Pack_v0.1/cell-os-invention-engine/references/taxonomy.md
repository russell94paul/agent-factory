# CELL OS Concept Taxonomy

Use this taxonomy to prevent architectures, frameworks, concepts, techniques, and products from collapsing into one list.

## Classification Coordinates

Classify each registry item across all material axes.

### Artifact type

| Type | Meaning | Example form |
| --- | --- | --- |
| Principle | Design rule or invariant | least authority by default |
| Concept | Explanatory idea | mission-scoped identity |
| Pattern | Reusable solution shape | blackboard coordination |
| Technique | Bounded method | confidence-weighted routing |
| Protocol | Interaction contract | request, accept, report, expire |
| Algorithm | Computable procedure | auction-based task allocation |
| Data structure | Organized state | temporal provenance graph |
| Architecture | Components and relations | federated Cell Mesh |
| Framework | Extensible operating structure | mission lifecycle framework |
| Component | Implemented subsystem | policy decision point |
| Tool/product | Deployable technology | a specific graph database |
| Metric/evaluation | Measurement mechanism | cost per accepted mission |

### CELL OS layer

| Layer | Main concern |
| --- | --- |
| L0 Intent & governance | mission, policy, budget, success, authority |
| L1 Operative cognition | perception, reasoning, planning, tool choice |
| L2 Cell composition | roles, teams, delegation, specialization |
| L3 Communication & coordination | messages, shared work, consensus, handoffs |
| L4 Integration & action | tools, APIs, apps, services, transactions |
| L5 Data, memory & knowledge | state, databases, KGs, vectors, provenance |
| L6 Processing & computation | batch, stream, event, semantic, reasoning flows |
| L7 Runtime & orchestration | scheduling, execution, isolation, resource control |
| L8 Trust & observability | identity, policy, evaluation, audit, telemetry |
| L9 Evolution & maintenance | diagnosis, repair, upgrade, learning, rollback |

### Remaining axes

- **Domain:** communication; coordination; integration; memory; knowledge; storage; retrieval; processing; orchestration; security; evaluation; observability; governance; self-maintenance; human interaction.
- **Scope:** Operative; Cell; Cell Mesh; domain fleet; Army; cross-organization ecosystem.
- **Topology:** centralized; hierarchical; peer-to-peer; blackboard; publish/subscribe; pipeline; market; swarm; federated; nested; hybrid.
- **Temporal mode:** synchronous; asynchronous; event-driven; streaming; batch; scheduled; episodic; continuous.
- **State model:** stateless; local; shared; replicated; sharded; event-sourced; bitemporal; federated; derived/materialized.
- **Authority:** observe-only; recommend; draft; act-with-approval; delegated-within-policy; autonomous-with-supervision; emergency-limited.
- **Maturity:** seed; framed; prior-art-checked; specified; prototyped; simulated; validated; piloted; production; deprecated.

## Technology Category Map

Classify products by their role; one product may occupy several roles.

| Family | Store/query model | Strong fit | Common mistake |
| --- | --- | --- | --- |
| Relational DB | tables, constraints, SQL | authoritative operational state | forcing semantic similarity into tables alone |
| Document DB | aggregate documents | flexible Operative and mission records | hiding cross-record invariants |
| Key-value store | key lookup | cache, leases, counters, fast state | treating it as durable knowledge without lifecycle rules |
| Graph DB / KG | nodes, edges, semantics | relationships, provenance, lineage, dependency reasoning | assuming graph storage creates a correct ontology |
| Vector DB/index | embeddings and nearest neighbors | semantic retrieval and similarity | equating similarity with truth or authority |
| Search index | lexical/inverted index | exact terms, filters, hybrid retrieval | losing transaction semantics |
| Event log/stream | ordered append and subscriptions | event sourcing, replay, asynchronous coordination | ignoring schema evolution and duplicate delivery |
| Object store/lake | files and columnar objects | artifacts, history, large datasets | using it as a low-latency control plane |
| Warehouse/lakehouse | analytical tables | fleet metrics, experiments, historical analysis | driving real-time control from stale aggregates |
| Time-series DB | timestamped measures | telemetry, SLOs, anomaly signals | storing mission meaning only as numeric series |
| Ledger | append-only verifiable records | high-integrity approvals and provenance | paying ledger complexity without a trust requirement |

## Required Registry Relations

Use typed relations: `depends_on`, `implements`, `extends`, `competes_with`, `composes`, `stores`, `emits`, `consumes`, `governs`, `evaluates`, `repairs`, `supersedes`, and `derived_from`.

Keep a product catalog separate from a concept registry, linked through `implements` or `supports`.

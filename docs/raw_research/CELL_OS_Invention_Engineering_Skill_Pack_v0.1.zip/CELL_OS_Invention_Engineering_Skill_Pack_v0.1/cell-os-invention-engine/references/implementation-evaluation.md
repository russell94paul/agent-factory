# Implementation and Evaluation

Use this guide to cross the gap from architecture language to executable evidence.

## Architecture Decision Sequence

1. State the decision and constraints.
2. Describe the baseline and failure evidence.
3. Compare at least two viable alternatives plus “keep baseline.”
4. Apply hard constraints before weighted preferences.
5. Record the choice, rejected options, uncertainties, consequences, and revisit triggers.

## Thin Vertical Slice

Exercise one end-to-end causal claim:

`mission input → coordination → state/memory → processing → authorized action or artifact → positive evidence → telemetry`

Mock only external boundaries that are not central to the hypothesis. Avoid building a general platform before validating the differentiating mechanism.

## Required Technical Specification

Component responsibilities/owners; APIs, event/storage schemas and versions; state machine/lifecycle; authority checks; consistency, ordering, concurrency, idempotency and transactions; budgets, quotas, timeouts, retries, cancellation and compensation; telemetry, SLOs, evidence, audit and lineage; degraded/isolation/recovery/rollback paths; deployment, dependencies, migration; and unit, contract, integration, replay, load, security and fault tests.

## Experiment Charter

Define the hypothesis, baseline, representative/adversarial workload, independent variables, primary outcome metrics, guardrails, acceptance threshold, kill criteria, and replayability before implementation.

Prefer mission success with positive evidence, accepted result rate, time-to-green, cost per accepted result, regression/escape rates, human rework/gate rejection, recovery/rollback, calibration/abstention, controlled stage ablation, and robustness across mission classes. Token, tool, message, and activity counts are diagnostic.

## Evaluation Threats

Control leakage, memorized cases, evaluator bias, unstable model versions, cherry-picked workloads, correlated judges, hidden human rescue, retry inflation, survivor bias, and proxy gaming. Keep a holdout, refresh it, include real historical failures with known-good evidence, and verify that the evaluation fails without the candidate fix.

## Rollout

Use offline replay → isolated sandbox → shadow traffic → canary → bounded production → staged expansion. Pin models, prompts, tools, policies, schemas, and evaluators in a configuration lockfile. Promotion requires independent proof and a rollback trigger.

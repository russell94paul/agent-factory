# Agentic Systems Invention Method

Use this method to generate structural variation and filter attractive-but-empty ideas.

## Start with a Capability Equation

Express the desired capability as:

`Capability = actors + state + signals + decisions + actions + evidence + adaptation`

Identify the limiting term. Innovations should change a limiting mechanism, boundary, or feedback loop.

## Morphological Design Axes

| Axis | Options |
| --- | --- |
| Coordination | supervisor, peer negotiation, blackboard, pub/sub, market, swarm, hybrid |
| Task allocation | static roles, skill match, bidding, load-aware, reputation-aware, learned router |
| Authority | human gate, policy lease, risk tier, dual control, reversible autonomy |
| State | local, shared, replicated, event-sourced, graph, vector, bitemporal, materialized |
| Consistency | strong, causal, eventual, quorum, confidence-bounded |
| Communication | request/reply, events, intents, deltas, subscriptions, shared artifacts |
| Verification | tests, contracts, independent critic, cross-model quorum, simulation, proof artifact |
| Adaptation | fixed, rules, bandit, offline optimization, gated self-modification |
| Failure control | retry, alternate route, degrade, isolate, compensate, rollback, escalate |
| Time | synchronous, asynchronous, batch, stream, episodic, continuous |

## Innovation Operators

- **Invert:** move control from supervisor to contract or environment.
- **Decouple:** separate message transport from semantics, or logical memory from storage.
- **Temporalize:** add leases, expirations, bitemporal truth, replay, or delayed commitment.
- **Make explicit:** turn implicit context into typed state, authority, evidence, or uncertainty.
- **Localize:** push decisions toward a Cell while retaining global policies.
- **Federate:** preserve local autonomy while exchanging bounded summaries or contracts.
- **Marketize:** allocate scarce attention, tools, or work through bids and utility.
- **Compile:** transform high-level mission intent into deterministic plans, policies, and schemas.
- **Materialize:** cache expensive reasoning as versioned artifacts with invalidation rules.
- **Dualize:** pair fast action with independent verification or a shadow execution path.
- **Reflexivize:** allow the system to observe and change a bounded part of itself.
- **Adversarialize:** add structured disagreement, red teams, or challenge protocols.

## Concept Families Worth Exploring

These are hypothesis seeds, not novelty claims.

- **Mission compiler:** converts intent, constraints, evidence, and budget into a versioned executable mission contract.
- **Capability membrane:** mediates Cell actions through discovery, authorization, simulation, execution, and evidence capture.
- **Epistemic delta exchange:** communicates changes in belief, evidence, uncertainty, or decision instead of full histories.
- **Delegation lease:** grants time-, budget-, scope-, and risk-bounded authority that expires automatically.
- **Causal mission graph:** links actions and outputs to the evidence and decisions that produced them.
- **Memory metabolism:** scores, compresses, promotes, quarantines, or forgets memory under explicit policies.
- **Semantic operator algebra:** defines typed agentic processing operators that can be composed, verified, and replayed.
- **Cellular immune loop:** detects behavioral drift, isolates suspect components, gathers evidence, and proposes bounded repairs.
- **Shadow mesh:** replays missions through candidate Cell configurations without real-world authority.
- **Evidence escrow:** withholds promotion or downstream use until required proof artifacts arrive.

## Novelty Filter

For each candidate ask what exact mechanism changes, what established mechanism is closest, whether the difference is rename/transfer/composition/new causal mechanism, what observable outcome should improve, which new failure appears, and what result would falsify its value. Reject candidates without a precise mechanism, outcome, and falsification condition.

## Portfolio Scoring

Score 1–5 and retain uncertainty for mission value, mechanism distinctness, feasibility, testability, interoperability, reliability/recoverability, security/governance, cost/latency, self-maintenance leverage, and option value. Apply hard constraints before collapsing scores into a ranking.

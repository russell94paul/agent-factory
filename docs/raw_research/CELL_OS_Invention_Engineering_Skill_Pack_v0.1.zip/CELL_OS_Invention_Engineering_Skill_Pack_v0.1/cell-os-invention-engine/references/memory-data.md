# Agentic Data, Memory, and Knowledge Architectures

Design memory behavior independently from database brands. A production design may combine stores behind one policy and provenance layer.

## Memory Functions

| Function | Core question |
| --- | --- |
| Working state | what is active in the current step? |
| Episodic memory | what happened during missions? |
| Semantic knowledge | what claims, entities, and relations are believed? |
| Procedural memory | how should recurring work be performed? |
| Artifact memory | what files, code, models, and outputs exist? |
| Organizational memory | who owns, trusts, or can perform what? |
| Prospective memory | what must happen later or on a condition? |
| Evaluative memory | what configurations worked under which conditions? |

## Required Separation

Separate truth/authority from relevance; logical memory from physical storage; raw evidence from summaries/derived claims; valid time from system-recorded time; retrieval score from confidence/trust; mission/tenant scope from global reuse; and retention from promotion.

## Architecture Families

Event-sourced mission ledger; relational system of record plus derived search/vector indexes; temporal knowledge graph with provenance; tiered hot/warm/cold memory; federated Cell-local memory; shared blackboard; lakehouse for replay/fleet learning; and hybrid lexical/vector/graph/SQL retrieval.

## Candidate Mechanisms

- **Bitemporal Mission Graph:** records when a claim was valid and when CELL OS learned it, linked to evidence, decisions, Operatives, and artifacts.
- **Memory Metabolism:** policies score memories for reinforcement, compression, promotion, quarantine, expiry, or deletion.
- **Contradiction-Aware Knowledge:** conflicting claims coexist with provenance and resolution state rather than last-write-wins.
- **Retrieval Compiler:** converts mission context into a typed retrieval plan across lexical, vector, graph, SQL, and artifacts.
- **Memory Lease:** temporary access or retention with scope, purpose, expiry, and revocation.
- **Provenance-Carrying Embedding:** vectors reference source versions, extraction policy, model, time, access, and invalidation state.
- **Knowledge Packet:** portable bounded subgraph with claims, evidence, confidence, permissions, and update subscriptions.
- **Counterfactual Replay Store:** retains inputs and decisions needed to compare Cell designs without production effects.

## Design Contract

Specify memory object types, identity, ownership, scopes, evidence, confidence, trust, valid/system time, versioning, write and promotion paths, retrieval plan, ranking, contradiction handling, retention, forgetting, access, audit, invalidation, and migration.

Select stores only after defining access patterns, invariants, consistency, latency, scale, query types, tenancy, durability, replay, operations, and cost. State which store is authoritative and which indexes are rebuildable.

Test stale embeddings, deleted sources, conflicting facts, poisoned summaries, cross-tenant leakage, graph cycles, invalid provenance, clock errors, retention violations, overload, missed index updates, and recovery from authoritative sources.

# Communication and Coordination Architectures

Design semantics first, transport second.

## Separate the Planes

| Plane | Purpose | Typical payload |
| --- | --- | --- |
| Intent | desired outcome and constraints | mission, priority, budget, deadline |
| Coordination | offers, claims, delegation, handoffs | bid, lease, reservation, dependency |
| Knowledge | evidence and belief changes | observation, citation, uncertainty, contradiction |
| Control | pause, cancel, isolate, promote | policy decision, gate, emergency action |
| Data | artifacts and structured values | records, files, feature batches |
| Telemetry | runtime evidence | traces, cost, latency, health, eval results |

## Architecture Families

- **Direct request/reply:** simple ownership; weak for many-to-many asynchronous work.
- **Supervisor routing:** clear authority; supervisor can bottleneck and lose local context.
- **Publish/subscribe:** loose coupling; requires ownership, ordering, and duplicate rules.
- **Blackboard/shared workspace:** emergent collaboration; requires concurrency and truth-status policies.
- **Peer contract net/market:** adaptive allocation; requires incentives, bid quality, and anti-gaming controls.
- **Gossip/federation:** resilient distribution; needs convergence, privacy, and stale-state handling.
- **Hybrid mesh:** different planes use different topologies; often the realistic production choice.

## Candidate Mechanisms

- **Epistemic Delta Protocol:** publish new evidence, belief/confidence change, affected decisions, and links to prior state.
- **Delegation Lease Protocol:** grant work and authority together with scope, budget, deadline, permissions, renewal, and revocation.
- **Causal Broadcast:** include upstream decision/evidence identifiers so downstream Cells can assess impact and replay consequences.
- **Attention Budget Exchange:** subscribe or bid for signals while quotas prevent interruption storms.
- **Handoff Capsule:** package objective, state, open questions, proof, risks, and a resumable execution pointer.
- **Contradiction Channel:** conflicting claims become explicit objects routed to verification Cells.
- **Conversation Backpressure:** recipients can defer, summarize, reject, or request compression based on mission priority and budget.

## Protocol Contract Checklist

Specify identity, schema/version, correlation and causation IDs, sender authority, recipient addressing, delivery semantics, ordering, expiry, idempotency key, acknowledgment, rejection reasons, cancellation, privacy classification, evidence links, observability, and compatibility.

Test duplicates, reordering, loss, delay, partitions, contradictory messages, low-quality senders, expired authority, schema drift, runaway chatter, supervisor loss, overload, and partial handoffs.

# Autonomy and Self-Maintenance Architectures

Self-maintenance is a controlled lifecycle: observe, detect, diagnose, propose, simulate, authorize, change, verify, promote, monitor, and roll back.

## Maintenance Targets

Operative prompts/models/tools; Cell blueprints; workflows; schemas; connectors; indexes; knowledge; policies; evaluations; infrastructure; dependencies; budgets; access; and observability.

## Autonomy Ladder

| Level | Allowed behavior |
| --- | --- |
| A0 Observe | collect health and evidence |
| A1 Diagnose | classify and explain, no mutation |
| A2 Propose | produce repair plan/diff and tests |
| A3 Sandbox | execute in isolated replay or simulation |
| A4 Gated repair | mutate after explicit approval |
| A5 Bounded repair | mutate within pre-authorized low-risk policy |
| A6 Adaptive optimization | search and promote configurations through independent gates |

Assign levels per target and action, never once for the entire system.

## Control Loop Architecture

- **Sensors:** health, outcomes, drift, cost, latency, security, and freshness.
- **Detector:** deterministic thresholds plus statistical or semantic anomaly detection.
- **Diagnoser Cell:** causal hypotheses with evidence and uncertainty.
- **Planner Cell:** minimal reversible interventions.
- **Shadow Mesh:** replay candidate changes against representative and adversarial missions.
- **Policy gate:** permissions, risk, evidence, budgets, and separation of duties.
- **Executor:** versioned change with canary and rollback.
- **Verifier:** independent positive success and regression evaluation.
- **Memory:** fault, diagnosis, change, result, and applicability conditions.

## Candidate Mechanisms

- **Cellular Immune Loop:** identifies abnormal behavior, isolates components, gathers evidence, and proposes bounded repair.
- **Repair Contract:** target, symptoms, evidence, permitted changes, tests, blast radius, rollback, expiry, and owner.
- **Behavioral Canary Operative:** receives mirrored workloads and blocks promotion when outcome distributions degrade.
- **Evolution Budget:** caps changes, experiments, tokens, cost, and risk per period.
- **Configuration Genome:** versioned blueprint/lockfile for roles, models, tools, policies, evaluators, and dependencies.
- **Knowledge Hygiene Cell:** detects stale, contradictory, ungrounded, duplicated, or over-broad memories.
- **Maintenance Mesh:** specialist Cells for detection, diagnosis, repair, verification, and governance.
- **Operational Antibodies:** reusable tested mitigations matched to fault signatures and applicability constraints.

## Hard Safety Invariants

- Diagnosis must not silently trigger unrestricted repair.
- A component proposing a material self-change must not be its sole evaluator.
- Ordinary optimization cannot weaken security policy, audit controls, or promotion gates.
- Repairs require positive success evidence, not only absence of errors.
- Changes are versioned, attributable, reversible where practical, and bounded in blast radius.
- Attempt caps survive restarts; repeated failures escalate rather than loop.
- Learning from production does not automatically promote to production.

Measure detection quality, time-to-detect, diagnostic accuracy, repair success, false repair, recovery time, rollback success, regression escape, human burden, maintenance cost, repeated-fault rate, and knowledge reuse precision. Use fault injection, replay, mutation testing, dependency failures, poisoned telemetry, evaluator disagreement, and rollback drills.

#!/usr/bin/env bash
set -euo pipefail

PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET_REPO="${1:-.}"
TARGET="$TARGET_REPO/.claude/skills"
mkdir -p "$TARGET"

for skill in "$PACK_ROOT"/skills/*; do
  [[ -d "$skill" && -f "$skill/SKILL.md" ]] || continue
  name="$(basename "$skill")"
  rm -rf "$TARGET/$name"
  cp -R "$skill" "$TARGET/$name"
  echo "installed $name -> $TARGET/$name"
done

echo
echo "Delta skills installed. Existing skills in agent-army-research are NOT copied automatically."
echo "See skills/EXISTING_SKILLS_TO_REUSE.md and promote/copy them deliberately."

from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
required = [
    "README.md",
    "CLAUDE.md",
    "docs/00-FEASIBILITY.md",
    "docs/01-SEQUENCING.md",
    "docs/02-ARCHITECTURE.md",
    "research/RUN_ORDER.md",
    "prompts/00-RECONCILE-CURRENT-REPOS.md",
]

errors = []
for rel in required:
    p = ROOT / rel
    if not p.is_file() or p.stat().st_size == 0:
        errors.append(f"missing/empty: {rel}")

skills = [p for p in (ROOT / "skills").glob("*/SKILL.md")]
if len(skills) < 12:
    errors.append(f"expected >=12 delta skills, found {len(skills)}")

prompts = list((ROOT / "research/prompts").glob("R*.md"))
if len(prompts) < 8:
    errors.append(f"expected >=8 delta research prompts, found {len(prompts)}")

for schema in (ROOT / "schemas").glob("*.json"):
    try:
        json.loads(schema.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"invalid JSON schema {schema.name}: {exc}")

if errors:
    print("PACK INVALID")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("PACK OK")
print(f"skills={len(skills)}")
print(f"research_prompts={len(prompts)}")
print(f"docs={len(list((ROOT/'docs').glob('*.md')))}")
print(f"diagrams={len(list((ROOT/'diagrams').glob('*.md')))}")
print(f"environment_profiles={len(list((ROOT/'configs/environment_profiles').glob('*.yaml')))}")

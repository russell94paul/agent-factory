#!/usr/bin/env bash
set -euo pipefail

DEST="${1:-agent-platform-candidate}"
if [[ -e "$DEST" ]]; then
  echo "Refusing: $DEST already exists" >&2
  exit 2
fi

mkdir -p "$DEST"/{apps/factory-control,apps/mission-console,packages/{agent-kernel,missions,contracts,context,environments,capabilities,events,evals,optimization},services/{evaluator,scheduler,knowledge,organizational-diagnostics},skills,evals,environments,research,docs/{architecture,adr,product},infra,tools}

cat > "$DEST/README.md" <<'INNER'
# Agent Platform Candidate

This is a **candidate future monorepo skeleton**, not permission to migrate production code.

Start by copying the bootstrap pack into `docs/bootstrap/` or keep it adjacent, then run the repository reconciliation prompt against the existing sibling repositories.

Do not move production code until a file-level migration decision and rollback path exist.
INNER

cat > "$DEST/.gitignore" <<'INNER'
.venv/
node_modules/
__pycache__/
.pytest_cache/
.env
.env.*
.data/
.DS_Store
INNER

printf '%s\n' "created $DEST"
printf '%s\n' "next: run prompts/00-RECONCILE-CURRENT-REPOS.md before copying source code"

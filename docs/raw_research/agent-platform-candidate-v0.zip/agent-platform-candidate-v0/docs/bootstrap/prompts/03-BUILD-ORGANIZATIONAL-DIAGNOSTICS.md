# Claude Boot Prompt — Organizational Diagnostic MVP

## Precondition

Do not run this until the Single-Agent Kernel has durable mission/run/evaluation data across enough runs to make a diagnostic meaningful.

## Goal

Build a **recommendation-only** organizational diagnostic service.

It should answer:

> Where are verified outcomes degrading, why might that be, and what is the least-complex change worth testing?

## Inputs

- mission classes;
- run bindings;
- evaluator outcomes;
- latency/cost;
- human interventions;
- environment/tool failures;
- skill/tool/context usage;
- workload/queues;
- knowledge corrections/staleness if available.

## Output proposal types

```text
measurement_fix
code_fix
context_fix
skill_candidate
meta_tool_candidate
environment_change
model_change
routing_change
capacity_change
specialist_agent_candidate
team_topology_experiment
human_process_change
insufficient_evidence
```

## MVP algorithms

Start interpretable:
- stratified failure-rate deltas;
- change-point alerts;
- failure clustering;
- queue/latency bottlenecks;
- environment-attributed failure ratios;
- skill/context usefulness stratification;
- confidence intervals/sample-size warnings.

Do not start with a black-box LLM making staffing decisions.

## Required UI contract

For every recommendation show:
- symptom;
- evidence window;
- affected mission class;
- candidate explanation;
- recommended experiment;
- expected upside;
- confidence/limitations;
- blast radius;
- accept/reject/defer.

## Negative controls

Inject synthetic false correlations and verify the diagnoser does not confidently recommend a new agent merely because volume changed.

# Claude Boot Prompt — Evidence-Based Monorepo Decision

## Goal

Decide whether/when to merge Agent Factory and adjacent platform code into a monorepo without mixing research truth with production truth.

## Current default

Keep:

```text
agent-factory/          production
agent-army-research/    research/speculation
```

as sibling repositories until evidence supports consolidation.

## Audit

Measure:
- actual cross-repo changes over last N weeks;
- duplicated schemas/types;
- duplicated CI/tooling;
- number of atomic changes currently requiring multiple PRs;
- access/isolation differences;
- release cadence differences;
- contributors/ownership;
- repository size/build/test cost;
- client-data/secret boundaries;
- research vs product truth semantics.

## Options

A. keep two repos;
B. platform monorepo + separate research repo;
C. monorepo including research under hard dependency boundaries;
D. platform monorepo + federated external workload repos.

## Decision rule

Do not choose monorepo for aesthetics. Choose it if atomicity/shared contracts/tooling substantially reduce maintenance burden and boundaries can be mechanically enforced.

## Required output

- measured current pain;
- options matrix;
- recommended threshold/date for revisit;
- candidate future tree;
- dependency-boundary rules;
- migration/rollback plan;
- exact list of packages that are genuinely shared **today**.

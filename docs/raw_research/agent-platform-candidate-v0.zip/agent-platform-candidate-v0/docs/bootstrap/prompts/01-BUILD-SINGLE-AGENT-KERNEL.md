# Claude Boot Prompt — Build the Single-Agent Kernel

## Mission

Implement the smallest reversible slice that lets Agent Factory version, execute, externally evaluate, inspect, compare, and recertify **one agent**.

Do not add a multi-agent team or optimizer in this task.

## Read first

- current `factory/blueprint.py`
- `factory/contract.py`
- `factory/context.py`
- `factory/launch.py`
- run/session/event code
- evaluator service and corpus
- relevant tests
- bootstrap `docs/01-SEQUENCING.md`, `docs/03-EXECUTION-ENVIRONMENTS.md`.

## Preserve

Reuse existing:
- content-addressed AgentSpec versioning;
- five-verdict GreenContract semantics;
- independent verifier boundary;
- sourced ContextRef/ContextPack;
- existing run/session evidence;
- prohibition/permission conventions where real.

## Add only what the current code lacks

Target concepts:

```text
EnvironmentProfile
AgentRunBinding
Mission (minimal)
Mandate/authority boundary only if enforceable
SkillRef (do not build full skill registry yet)
EvaluationRecord
CapabilitySnapshot (structured, not magic score)
RecertificationTrigger
```

## Required invariants

1. A run records exact versions/bindings.
2. Changing a load-bearing config changes identity or explicitly invalidates certification.
3. The authoritative verifier is not editable/impersonable by the worker in the run.
4. Environment-caused errors remain distinguishable from task failures.
5. Context sources remain traceable.
6. A missing measurement cannot become PASS.
7. Existing behavior remains compatible behind adapters/feature flags.

## Test-first discriminators

Before implementation predict results for tests proving:

- changing model binding changes run binding;
- changing environment profile changes run binding;
- changing a skill reference changes run binding;
- worker cannot set authoritative verifier verdict directly;
- evaluator crash yields ERROR, not FAIL/UNMEASURABLE;
- stale/unverified context remains visible;
- candidate version can be compared to current on same corpus;
- rollback restores previous active binding.

## Output

- implementation;
- tests;
- architecture note;
- migration note;
- exact command to run a two-config comparison;
- known gaps;
- no UI beyond a minimal inspector/JSON output unless needed for operator verification.

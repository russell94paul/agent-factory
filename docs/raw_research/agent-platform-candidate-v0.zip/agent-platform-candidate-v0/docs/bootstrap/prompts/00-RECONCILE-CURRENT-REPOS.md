# Claude Boot Prompt — Reconcile Agent Factory + Agent Army Research

You are the principal repository architect for a controlled migration.

## Workspace expected

```text
workspace/
├── agent-factory/
├── agent-army-research/
└── agent-platform-bootstrap-v1/   # this pack
```

If paths differ, discover them. Do not assume a branch or commit.

## Mission

Produce a **repository-grounded current→north-star reconciliation**. Do not redesign from documents alone and do not automatically merge the repositories.

The immediate product goal remains to get Agent Factory working on real workflows. The north-star is broader: develop/maintain/operate/improve one agent; compose proven agents into teams; diagnose capability gaps; recommend organizational changes; safely optimize configurations; eventually let the same machinery maintain the Factory.

## Non-negotiable source order

1. current tested code and tests;
2. current runtime evidence/data;
3. accepted product ADRs/decisions;
4. synthesized research;
5. raw research answers;
6. candidate architecture in this bootstrap.

If candidate docs disagree with tested code, code wins until a deliberate migration is approved.

## Required reading

### Agent Factory
- `README.md`
- `BRAIN-DUMP.md`
- `factory/contract.py`
- `factory/blueprint.py`
- `factory/context.py`
- `factory/launch.py`
- `docs/agent-communication.md`
- `docs/CLIENT-INTAKE-PLATFORM-PLAN.md`
- `docs/agent-army/CURRENT_STATE.md`
- `docs/agent-army/APPROVED_CONCEPTS.md`
- relevant tests/evals/blueprints and current git status.

### Agent Army Research
- `README.md`
- `PROGRAM_MANIFEST.md`
- `research/RESEARCH-MANIFEST.yaml`
- `research/synthesis/W0-foundations.md`
- `research/DEEP-RESEARCH-RUNBOOK.md`
- `repo-boundary/RESEARCH-VS-PRODUCT.md`
- `architecture/*`
- `claude-skills/*/SKILL.md`
- relevant research prompts.

### Bootstrap
Read every file in `docs/` and `research/RUN_ORDER.md`.

## First action: create evidence inventory

Record:

```yaml
agent_factory:
  branch:
  sha:
  tests:
  dirty_state:
agent_army_research:
  branch:
  sha:
  manifest_state:
```

Then inventory current implementation by mechanism, not metaphor.

## Required comparison table

For each candidate mechanism:

```text
MECHANISM
CURRENT CODE
CURRENT TESTS
RESEARCH STATUS
NORTH-STAR NEED
DECISION: KEEP/MODIFY/ADD/DEFER/DELETE/EXPERIMENT
PRECONDITION
MIGRATION RISK
FIRST DISCRIMINATING TEST
```

At minimum cover:

- AgentSpec/versioning;
- run binding;
- environment profiles;
- context packs;
- missions/mandates;
- evaluator boundary;
- events/replay;
- skills;
- capability readiness;
- memory writeback;
- research automation;
- team composition;
- organizational diagnostics;
- surge composition;
- optimization;
- self-maintenance;
- UI.

## Architecture rule

Use the complexity ladder:

```text
deterministic service
→ one LLM agent
→ one agent + independent evaluator
→ routed specialists
→ parallel independent workers
→ fixed multi-agent team
→ adaptive organization
```

Never skip a level without evidence the simpler level is insufficient.

## Required deliverables

Create in a new branch, **docs only unless explicitly asked to implement**:

```text
docs/reconciliation/
├── 00-current-state.md
├── 01-current-to-target-delta.md
├── 02-decisions-needed.md
├── 03-sequenced-backlog.md
├── 04-file-level-migration-map.md
├── 05-test-and-eval-plan.md
├── 06-repo-boundary-recommendation.md
└── 07-first-14-days.md
```

Also output:
- concepts that W0 killed/demoted and must not silently reappear;
- existing mechanisms that are stronger than the research abstraction;
- duplicated docs/code candidates;
- explicit rollback/strangler plan;
- a list of research questions that genuinely block implementation.

## Do not

- write a greenfield architecture without reading code;
- call the current system an "army" if the mechanism is just a lane/session;
- create agent-to-agent chat because it sounds natural;
- create a monorepo as a style preference;
- build an optimizer before the evaluator/corpus is trustworthy;
- let an agent grade its own authoritative outcome;
- preserve concepts because they sound impressive.

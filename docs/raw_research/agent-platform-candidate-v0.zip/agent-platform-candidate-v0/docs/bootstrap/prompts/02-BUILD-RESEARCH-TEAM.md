# Claude Boot Prompt — Build the Research Team Harness

## Goal

Automate the Agent Army research protocol without reducing source rigor.

The research workflow is one of the few domains where parallel agents are naturally useful because independent source directions can be explored concurrently.

## Use existing skills

Do not duplicate these if present:
- evidence-auditor;
- research-synthesizer;
- experiment-designer;
- systems-architect;
- repo-integrator;
- knowledge-curator.

Install/use the delta skills from this bootstrap:
- base-research-agent;
- research-orchestrator;
- adversarial-researcher;
- source-verifier.

## Topology

```text
Research Orchestrator
   ├── source scout A
   ├── source scout B
   ├── implementation/repo scout
   └── adversarial scout
          ↓
Source/Evidence Reviewer
          ↓
Research Synthesizer
          ↓
Experiment Designer
          ↓
Human acceptance
```

Subagents share **structured artifacts**, not free-form chat.

## Required run artifact

```text
research/runs/<research-id>/<timestamp>/
├── run.yaml
├── question.md
├── decomposition.yaml
├── sources.jsonl
├── claims.jsonl
├── contradictions.jsonl
├── scouts/
├── evidence-audit.md
├── synthesis.md
├── experiments.md
└── decision-needed.md
```

## Source quality rules

- primary source before summary for load-bearing claims;
- exact date/version/URL/identifier;
- record inaccessible sources;
- independent-source grouping;
- code implementation inspected when implementation claims matter;
- never treat search snippets as final evidence;
- research answer is not product truth.

## Evaluation

Build a small benchmark of 5 prior research questions with known corrections. Measure:
- citation/source correctness;
- unsupported claims;
- duplicate-source inflation;
- missed counterevidence;
- human review time;
- research cost/latency.

Do not declare the research harness "better" because it produced more sources.

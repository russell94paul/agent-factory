# Claude Boot Prompt — Assemble a Candidate Platform Repository from Both Repos

## Use only after

1. `00-RECONCILE-CURRENT-REPOS.md` has produced a current→target delta;
2. a human has accepted the migration decisions;
3. the current production repo is clean/pushed.

## Goal

Create a **new candidate repository** that composes approved/reusable parts from:

```text
../agent-factory
../agent-army-research
../agent-platform-bootstrap-v1
```

without deleting or rewriting the source repositories.

## Default target

```text
../agent-platform-candidate
```

The target is an integration experiment. `agent-factory` remains production source-of-truth until parity is proven.

## Rules

- use git history/commit references in migration manifest;
- copy/move only items explicitly approved by the reconciliation decision;
- keep research content logically separated from runtime dependencies;
- preserve production package names behind compatibility adapters first;
- do not rename every concept to Agent Army vocabulary;
- do not import raw research answers as runtime dependencies;
- do not copy secrets/.env/.data/client-private artifacts;
- keep external workload/client repos federated outside the platform repo.

## Candidate structure

```text
agent-platform-candidate/
├── apps/
├── packages/
│   ├── agent-kernel/
│   ├── contracts/
│   ├── context/
│   ├── environments/
│   ├── missions/
│   ├── capabilities/
│   ├── events/
│   └── evals/
├── services/
│   └── evaluator/
├── skills/
├── evals/
├── research/
│   └── README.md   # points to research repo; no bulk sync by default
├── docs/
│   ├── migration/
│   ├── architecture/
│   └── adr/
└── tools/
```

## Migration manifest

Create `docs/migration/MANIFEST.yaml` containing for every migrated artifact:

```yaml
source_repo:
source_sha:
source_path:
target_path:
operation: copy|adapt|wrap|rewrite
reason:
parity_test:
rollback:
```

## Required sequence

1. initialize candidate repo;
2. add contracts/eval primitives first;
3. add single-agent kernel adapters;
4. add context/environment binding;
5. add tests and reproduce current Agent Factory demo/certification behavior;
6. only then add new capabilities;
7. generate parity report;
8. stop before replacing production repo.

## Acceptance

The candidate repository must prove it preserves at least:
- five-verdict contract behavior;
- evaluator separation;
- AgentSpec/version identity semantics;
- ContextRef source/freshness semantics;
- relevant current tests;
- rollback path back to unchanged `agent-factory`.

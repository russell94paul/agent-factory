# Pack Manifest

## Purpose

A candidate implementation/research acceleration pack created after reviewing the current `agent-factory` and `agent-army-research` repositories.

## Included

- 15 architecture/product/research docs;
- 6 Mermaid architecture diagrams;
- 11 delta research prompts (R46–R56, selected sequence);
- research run order that reuses W0 rather than restarting;
- external source-lead sheet for independent re-verification;
- 17 new/delta Claude Skills;
- map of 8 existing Agent Army skills to reuse;
- 10 execution-environment preset YAMLs;
- 6 reusable templates;
- 4 JSON schemas;
- 6 Claude boot prompts including repo reconciliation and candidate-repo assembly;
- validation/install/bootstrap scripts.

## Source-position warning

This pack is a **candidate synthesis**, not product truth. The current product repo's tested code and accepted decisions remain authoritative. Use the reconciliation prompt before implementation.

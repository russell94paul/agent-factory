# Claude Instructions — Agent Platform Bootstrap

## Mission

Use this repository to reconcile two existing systems and implement the smallest evidence-backed path from a measurable single agent to a configurable agent organization platform.

## Source repositories

Expected sibling layout:

```text
workspace/
├── agent-factory/
├── agent-army-research/
└── agent-platform-bootstrap-v1/
```

Do not assume the bootstrap is more authoritative than tested production code.

## Truth order

1. Tested current code in `agent-factory`.
2. Measured production/run evidence.
3. Accepted product ADRs / contracts.
4. Synthesized research in `agent-army-research`.
5. Raw research answers.
6. Candidate architecture in this bootstrap.

If two levels disagree, surface the disagreement. Do not silently reconcile it.

## Required workflow

Before implementing a substantial feature:

1. identify the existing production primitive;
2. identify the research claim / hypothesis;
3. state the current measurable gap;
4. define the baseline;
5. define the acceptance/rejection criterion;
6. implement the smallest reversible slice;
7. add negative controls;
8. run evals;
9. update architecture only after evidence.

## Sequencing guard

Do not implement adaptive team formation until a single-agent lifecycle is measurable end-to-end.

Do not implement organization optimization until there is a versioned mission corpus and independent verifier.

Do not implement autonomous Factory self-modification until shadow/canary/rollback paths exist.

## Complexity rule

Prefer, in order:

```text
deterministic code
→ single agent
→ single agent + evaluator
→ routed specialist agents
→ parallel workers for independent subtasks
→ multi-agent team
→ adaptive organization
```

Every upward step must solve a measured problem the simpler level failed to solve.

## Research rule

Use the research skills in this repository. A research answer is evidence, not a product decision.

## Completion rule

Every implementation report must include:

- files changed;
- behavior changed;
- test/eval results;
- negative control;
- performance/cost impact;
- new telemetry;
- rollback path;
- assumptions disproven;
- next gate.

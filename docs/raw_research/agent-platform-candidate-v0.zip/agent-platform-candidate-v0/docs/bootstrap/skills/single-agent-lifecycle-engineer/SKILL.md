# Skill — Single-Agent Lifecycle Engineer

## Purpose

Build/maintain the smallest reproducible unit of agent capability before team complexity is introduced.

## Canonical concerns

```text
AgentSpec
ModelBinding
SkillSet
ToolPolicy
EnvironmentProfile
ContextPolicy
Mission
Mandate
Verifier
AgentRunBinding
Evaluation
CapabilitySnapshot
```

## Procedure

1. Reuse existing versioning/eval/context primitives.
2. Define which fields are identity-bearing.
3. Hash/version load-bearing configuration.
4. Persist exact run bindings.
5. Ensure worker cannot author authoritative verification.
6. Track lifecycle state and recertification triggers.
7. Add canary/rollback metadata.
8. Add discriminating tests for every identity field.
9. Expose structured inspector output.
10. Keep a solo baseline for every later team experiment.

## Completion criterion

Two candidate agent bindings can be replayed on the same mission corpus and compared fairly, with environment/tool/evaluator differences visible.

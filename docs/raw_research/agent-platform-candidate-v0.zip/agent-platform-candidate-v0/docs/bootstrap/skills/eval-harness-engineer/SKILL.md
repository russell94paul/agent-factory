# Skill — Evaluation Harness Engineer

## Purpose

Make sure an agent/team/organization can be proven wrong before anyone optimizes it.

## Procedure

1. Define terminal success in externally observable state.
2. Define PASS / FAIL / UNMEASURABLE / ERROR / NOT_RUN semantics.
3. Create negative controls proving each critical assertion can fail.
4. Separate worker permissions from evaluator authority.
5. Version corpus and verifier.
6. Track replay vs live measurement explicitly.
7. Prevent optimizer access to holdout answers/verifier internals.
8. Record side effects/regressions, not only target success.
9. Report confidence/effect size appropriate to sample size.
10. Refuse scalar ranking when required dimensions conflict.

## Anti-Goodhart rule

Activity metrics can explain a run; they cannot certify it.

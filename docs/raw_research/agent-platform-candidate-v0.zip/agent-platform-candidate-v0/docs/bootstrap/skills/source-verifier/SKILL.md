# Skill — Research Source Verifier

## Purpose

Verify load-bearing citations before they influence synthesis or architecture.

## Checks

For each claim/source pair:

1. Open the source artifact, not only a summary.
2. Confirm title/authors/date/version.
3. Locate the exact supporting passage/result.
4. Check whether the statement is abstract/body/spec/code.
5. Record task domain, dataset, sample size and comparator where applicable.
6. Record uncertainty/effect interval when reported.
7. Verify cited implementation exists if claimed.
8. Mark source independence/grouping.
9. Note retractions/version changes/superseding work.
10. Flag extrapolation beyond source scope.

## Verdict

```text
VERIFIED
PARTIAL
NOT_SUPPORTED
NOT_ACCESSIBLE
SUPERSEDED
```

## Rule

A source can be credible and still fail to support the specific claim.

# Skill — Execution Environment Engineer

## Purpose

Design and version the runtime/harness substrate so environment effects are measurable instead of being blamed on the agent.

## Environment dimensions

- image/OS/dependencies;
- CPU/RAM/disk/time;
- workspace/worktree/repo ref;
- network/proxy/DNS;
- secrets/capability references;
- tool/MCP availability;
- API quotas;
- sandbox/isolation;
- observability hooks;
- concurrency/contention;
- data locality.

## Procedure

1. Define EnvironmentProfile with content-addressed identity.
2. Separate environment identity from AgentSpec identity.
3. Record profile/version on every run.
4. Instrument provisioning and resource metrics.
5. Classify infra failures separately from task failures.
6. Create task-class presets only after measured use.
7. Compare matched agent versions across profiles.
8. Detect stale images/dependencies/tools.
9. Define isolation and secret-access tests.
10. Provide rebuild/rollback path.

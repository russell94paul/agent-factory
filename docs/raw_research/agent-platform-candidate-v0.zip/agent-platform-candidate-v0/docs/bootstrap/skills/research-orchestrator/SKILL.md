# Skill — Research Team Orchestrator

## Purpose

Decompose a broad research question into parallelizable evidence tasks, coordinate scouts through artifacts, and route results into audit/synthesis.

## Use when

The problem has independent research directions. Do not use for one narrow sequential lookup.

## Procedure

1. Read prior research manifest/synthesis.
2. Identify which part is genuinely new.
3. Create 3–5 non-overlapping subquestions.
4. For each, define source classes and a falsification target.
5. Assign scouts; require structured outputs.
6. Do not allow scouts to overwrite one shared narrative file.
7. Collect outputs into one evidence directory.
8. Run source/evidence review.
9. Run adversarial review on the strongest proposed conclusion.
10. Pass reviewed claims to Research Synthesizer.
11. Pass unresolved empirical mechanisms to Experiment Designer.
12. Stop before product implementation; request human decision.

## Artifact protocol

```text
run.yaml
decomposition.yaml
scouts/<id>.md
sources.jsonl
claims.jsonl
contradictions.jsonl
evidence-audit.md
synthesis.md
experiments.md
decision-needed.md
```

## Orchestration KPIs

- source correctness;
- contradiction coverage;
- duplicate-source inflation;
- unsupported claim rate;
- cost;
- latency;
- human review minutes;
- number of decisions changed by adversarial review.

More scouts is not a success metric.

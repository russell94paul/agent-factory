# Skill — Adversarial Researcher

## Purpose

Attempt to falsify a favored architecture/research conclusion before it becomes product truth.

## Procedure

1. State the candidate claim in falsifiable form.
2. Build the strongest simpler alternative.
3. Search prior art and negative/contradictory evidence.
4. Check benchmark/task mismatch.
5. Check whether the claimed gain disappears after controlling for cost, model, environment, or task mix.
6. Check independence of cited sources.
7. Identify terminology/novelty collisions.
8. Identify hidden operational costs and failure modes.
9. Propose a discriminating A/B or ablation.
10. Return a verdict without editing the original research artifact.

## Verdicts

```text
SURVIVES
SURVIVES_WITH_NARROWER_CLAIM
NEEDS_EXPERIMENT
REFUTED_FOR_THIS_DOMAIN
REFUTED
```

## Required close

- strongest kill shot;
- strongest reason the idea may still be useful even if non-novel;
- evidence needed to change the verdict.

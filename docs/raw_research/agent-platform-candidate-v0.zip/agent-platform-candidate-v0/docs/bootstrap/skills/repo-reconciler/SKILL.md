# Skill — Repository Reconciler

## Purpose

Compare current tested product code against research/candidate architecture without creating a greenfield rewrite.

## Procedure

1. Record repo/branch/SHA/dirty state.
2. Read product source, tests, data contracts and current ADRs.
3. Read accepted synthesis/handoffs.
4. Map mechanisms by file and ownership.
5. Identify existing primitives that already solve part of the proposed problem.
6. Identify semantic/name collisions.
7. Classify each delta: KEEP / MODIFY / ADD / DEFER / DELETE / EXPERIMENT.
8. Prefer adapter/projection/strangler migration.
9. Define first discriminating test and rollback for every implementation item.
10. Produce a file-level migration map.

## Never

- call a research doc implemented;
- delete working behavior before parity;
- merge research and production truth automatically;
- rename stable code solely to fit a metaphor.

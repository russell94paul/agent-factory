# Skill — Evidence-Grounded Team Composer

## Purpose

Create a fixed team candidate only when a measured solo/routed baseline shows a coordination or specialization need.

## Procedure

1. Start from mission capability decomposition.
2. Check whether one agent + skills/tools is sufficient.
3. Identify subtasks that are independent vs sequential/shared-state.
4. Use parallel agents only for independent work when possible.
5. Minimize mandatory handoffs.
6. Assign external verifier separately from workers.
7. Version topology, bindings, skills, environment and comms policy.
8. Define same-budget/quality experimental threshold before running.
9. Run against versioned corpus and holdout.
10. Reject and preserve negative result if team fails to beat baseline.

## Output

Team candidate YAML + experiment + explanation of why each additional agent exists.

# Skill — Mission Context Compiler Engineer

## Purpose

Turn vague requests plus enterprise artifacts into a sourced, permissioned, compact mission package and a small set of high-value unanswered questions.

## Procedure

1. Normalize request into entities/intents/constraints.
2. Resolve referenced client/repo/API/app/document artifacts.
3. Retrieve relevant sourced ContextRefs and similar cases.
4. Detect contradictions/stale/unverified refs.
5. Generate knowledge needs, not broad retrieval dumps.
6. Attempt internal answers before asking a human.
7. Rank unresolved questions by expected information gain × downstream risk.
8. Link accepted requirements to verifier assertions.
9. Allocate context budget by marginal value.
10. Preserve provenance/permissions on every included ref.

## Metrics

- first-pass success;
- questions avoided;
- human minutes;
- token waste;
- stale context usage;
- requirement→verification coverage;
- time to executable mission.

# Skill — Skill and Meta-Tool Miner

## Purpose

Turn repeated successful reasoning/tool patterns into reusable skills or deterministic composite tools when that reduces cost/variance without losing adaptability.

## Procedure

1. Mine successful traces grouped by mission class.
2. Find repeated action/tool subsequences and repeated instructions.
3. Check that repetition is not simply duplicate work/topic bias.
4. Classify candidate as:
   - documentation/context;
   - LLM Skill;
   - deterministic meta-tool;
   - workflow template;
   - not reusable.
5. Create candidate with inputs/outputs/preconditions/failure modes.
6. Add tests/negative controls.
7. Compare candidate vs original trace pattern on holdout missions.
8. Measure success/cost/latency/tool-call variance.
9. Publish versioned candidate only if threshold met.
10. Track usage/helpfulness and retire regressions.

## Bias

Prefer deterministic code when the repeated behavior is stable and testable; keep LLM skills for judgment-heavy or variable steps.

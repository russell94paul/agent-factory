# Skill — Surge Team Composer

## Purpose

Recommend a temporary urgency-aware mission team from currently available organizational capability.

## Inputs

- required capabilities;
- urgency/deadline;
- readiness evidence;
- current workload;
- preemption/context-switch cost;
- concurrency limits;
- environment/tool availability;
- permissions/client scope;
- verifier and human capacity;
- budget.

## Procedure

1. Reject candidates lacking hard permissions/required environment.
2. Compute feasible capability coverage.
3. Compare best-idle, fixed-team and temporary-composition options.
4. Penalize unnecessary team size and communication seams.
5. Include preemption/opportunity cost.
6. Explain each selected member's marginal contribution.
7. Define communication topology and context package per member.
8. Define dissolution/fallback conditions.
9. Require approval for disruptive preemption or privileged actions.
10. Log recommendation for replay evaluation.

## Never

"Swarm" must not mean broadcast to every agent or spawn without limits.

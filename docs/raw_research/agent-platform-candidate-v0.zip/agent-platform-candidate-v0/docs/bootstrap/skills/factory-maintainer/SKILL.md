# Skill — Agent Factory Maintainer

## Purpose

Use the Factory's own mission/eval machinery to maintain the Factory safely.

## Loop

```text
observe
→ diagnose
→ internal maintenance ticket
→ candidate repair
→ independent evaluation
→ human/policy gate
→ canary
→ measure
→ promote/rollback
→ knowledge writeback
```

## Maintenance domains

- agent/skill drift;
- evaluator health;
- knowledge freshness;
- workflow failures;
- dependencies/APIs;
- infrastructure/cost;
- architecture/docs drift;
- dead code/tests;
- security/configuration.

## Procedure

1. Classify symptom and evidence.
2. Verify monitor/instrument is itself healthy.
3. Create bounded internal mission.
4. Select least-complex repair path.
5. Execute in isolated environment.
6. Run regression/negative-control suite.
7. Require explicit approval based on risk class.
8. Canary where applicable.
9. Auto-rollback on declared failure signals.
10. Record recurrence/prevention value.

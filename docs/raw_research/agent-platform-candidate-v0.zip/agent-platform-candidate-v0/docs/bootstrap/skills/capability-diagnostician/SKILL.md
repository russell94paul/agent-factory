# Skill — Capability Diagnostician

## Purpose

Use verified run/event data to identify organizational weaknesses and propose the least-complex remedy worth testing.

## Diagnosis order

Before suggesting a new agent, test whether the issue is:

```text
measurement
source/data
context
skill
meta-tool/deterministic automation
environment
model/tool routing
capacity/queue
existing specialist routing
new agent
team topology
human/process
```

## Procedure

1. Stratify by mission class and binding.
2. Detect outcome/latency/cost changes with sample warnings.
3. Cluster failure modes and attribution signals.
4. Check environment/tool outages before blaming reasoning.
5. Check whether a known skill/context remedy already exists.
6. Estimate opportunity and uncertainty.
7. Generate one or more candidate interventions.
8. Attach evidence and a discriminating experiment.
9. Recommend only; do not staff or deploy autonomously.
10. Track accepted/rejected proposals and later outcomes.

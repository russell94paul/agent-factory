# Skill — Optimization Controller

## Purpose

Run bounded offline search over agent/team/runtime configurations without allowing the optimizer to redefine success or mutate hard governance.

## Preconditions

- trustworthy versioned evaluator;
- negative controls;
- versioned corpus + holdout;
- exact run bindings;
- bounded search budget;
- promotion pipeline.

## Searchable

Agent config, model binding, skills, environment, context policy, tool policy, team topology, routing, review depth, budgets.

## Immutable

Authoritative verifier, hard permissions, audit rules, secrets policy, holdout labels.

## Procedure

1. Declare search space/constraints/budget.
2. Preserve baseline.
3. Separate optimize/evaluate sets.
4. Run candidates reproducibly.
5. Track full metric vector, not one opaque score.
6. Detect reward hacking/degenerate candidates.
7. Test robustness/transfer across mission slices.
8. Produce Pareto candidates with lineage.
9. Promote only through shadow/canary gates.
10. Record failed candidates as useful evidence.

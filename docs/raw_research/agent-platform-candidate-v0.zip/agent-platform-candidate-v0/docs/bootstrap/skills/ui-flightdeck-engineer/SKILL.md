# Skill — Agent Flight Deck UI Engineer

## Purpose

Build a high-information operator UI that feels fast and game-like because actions and feedback are immediate, not because agents wander around decoratively.

## Priority surfaces

1. Mission Brief / Context gaps.
2. Agent Run Inspector.
3. Capability/Readiness.
4. Environment health.
5. Evidence/Verifier outcome.
6. Timeline/replay.
7. Team recommendation/compare.
8. Organizational diagnostic proposals.
9. Surge confirmation.
10. Optimization experiments.

## Design rule

Every animation/color/badge must encode real state with an accessible textual equivalent.

## Never reward

messages, token burn, agent count, tool calls, generated files.

## Reward/show

verified outcomes, readiness, cost/latency, reduced human intervention, stable recertification, useful knowledge, resolved uncertainty.

## Build sequence

Thin Flight Deck first; rich Command World only after event/world-state semantics are proven useful.

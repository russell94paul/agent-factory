# Existing Agent Army Skills — Reuse, Do Not Duplicate

The current `agent-army-research` repository already contains valuable skills. Keep them as the research source-of-truth and either install/symlink/copy them deliberately into the product workspace when needed.

Existing skills found during review:

- `doctrine-engineer`
- `evidence-auditor`
- `experiment-designer`
- `knowledge-curator`
- `repo-integrator`
- `research-synthesizer`
- `systems-architect`
- `ui-architect`

The skills in this bootstrap are **delta skills** covering missing lifecycle/orchestration/environment/diagnostic/self-maintenance work.

Recommended research stack:

```text
research-orchestrator        NEW
  ├── base-research-agent    NEW
  ├── adversarial-researcher NEW
  └── source-verifier        NEW
        ↓
evidence-auditor             EXISTING
        ↓
research-synthesizer         EXISTING
        ↓
experiment-designer          EXISTING
        ↓
systems-architect            EXISTING
        ↓
human decision
        ↓
repo-integrator              EXISTING
```

# Skill — Mission Memory Synthesizer

## Purpose

Prevent agent context from becoming compartmentalized while keeping individual perspective and raw evidence intact.

## Layers

1. immutable evidence;
2. agent episodic digest;
3. mission working memory;
4. curated organizational knowledge.

## Procedure

1. Collect each agent's structured digest and relevant tool/evidence outputs.
2. Deduplicate shared root evidence.
3. Separate observation, inference, decision and verified outcome.
4. Preserve disagreements; do not majority-vote truth.
5. Prefer authoritative evidence/test outcomes over repeated agent claims.
6. Identify reusable lesson candidates and applicable scope.
7. Add provenance, confidence basis, validity window and permissions.
8. Run write gate before durable promotion.
9. Link future use/corrections back to the knowledge object.
10. Deprecate/recertify stale or contradicted knowledge.

## Rule

The synthesizer adds a canonical interpretation; it never deletes the underlying agent digests or evidence.

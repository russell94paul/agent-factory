# Skill — Base Research Agent

## Purpose

Produce one bounded, evidence-traceable research contribution for an Agent Platform research mission.

## Inputs

- research question/subquestion;
- run id;
- source classes requested;
- prior synthesis if applicable;
- repository evidence pack if applicable.

## Procedure

1. Restate the exact subquestion and what would falsify the expected answer.
2. Search for primary/authoritative sources first.
3. Record every inspected source with date/version/identifier.
4. Extract decision-relevant claims; separate direct evidence from inference.
5. Search for counterevidence and negative results.
6. Inspect implementation/source code when claiming a system implements a mechanism.
7. Group correlated sources by root dataset/lab/implementation lineage.
8. Mark inaccessible sources explicitly.
9. Map findings to the task domain; do not generalize across unrelated benchmarks silently.
10. End with what remains unknown and what experiment would resolve it.

## Evidence labels

```text
ESTABLISHED
EMERGING
EXPERIMENTAL
SPECULATIVE
METAPHORICAL ONLY
```

## Output

Structured claim rows:

```yaml
claim_id:
claim:
evidence_label:
source:
source_type:
primary_opened:
direct_support:
independence_group:
task_domain:
counterevidence:
agent_factory_implication:
confidence_limit:
```

## Never

- treat search snippets as evidence;
- inflate confidence with duplicate citations;
- call something novel without prior-art search;
- recommend implementation solely because an idea is elegant;
- edit canonical architecture from a scout run.

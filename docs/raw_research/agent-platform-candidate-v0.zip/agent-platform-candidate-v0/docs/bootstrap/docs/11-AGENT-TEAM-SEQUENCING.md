# Agent → Skill → Team → Organization Sequencing

## Why the order matters

The product's optimization target becomes impossible to interpret if agents, teams, context, environments and evaluators all change at once.

Use this ladder.

## Level A0 — Deterministic mechanism

Use code when inputs/outputs/rules are stable and testable.

Examples:
- schema validation;
- credential preflight;
- diff parsing;
- event projection;
- capability filters;
- budget enforcement.

## Level A1 — Single worker agent

One continuous context owns the sequential work.

Use when:
- task is stateful/sequential;
- one agent can inspect/plan/implement/test iteratively;
- communication seams would add more risk than specialization removes.

## Level A2 — Worker + independent verifier

This should become the default production evidence shape.

```text
Worker cannot author terminal PASS
        ↓
Clean verifier evaluates external state
```

## Level A3 — Routed specialists

Only one specialist works at a time, chosen by mission class/need.

This gives specialization without team coordination overhead.

## Level A4 — Parallel independent workers

Useful for:
- research;
- independent hypothesis exploration;
- independent design variants;
- broad searches;
- embarrassingly parallel inspections.

## Level A5 — Fixed team

Add when the mission genuinely benefits from persistent division of labor or independent review.

Team identity includes:
- member bindings;
- topology;
- communication protocol;
- context allocation;
- environment bindings;
- verifier;
- budget.

## Level A6 — Adaptive composition

System recommends configuration/team based on mission features + capability evidence + resource state.

Start recommendation-only.

## Level A7 — Organizational diagnosis

System asks:

> What capability/process/resource is causing verified performance degradation?

It proposes organizational changes, not only team selections.

## Level A8 — Offline organization optimization

Replay/simulation searches candidate configurations under multiple objectives.

## Level A9 — Guarded self-maintenance

Agent Factory becomes one of the systems its own mission machinery maintains.

## Promotion rule

A higher level is justified only when:

```text
measured problem at lower level
+
mechanism-specific hypothesis
+
external verifier
+
predeclared acceptance criterion
+
rollback
```

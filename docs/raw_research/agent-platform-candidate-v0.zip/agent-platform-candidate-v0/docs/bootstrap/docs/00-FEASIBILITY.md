# Feasibility Review

## Executive verdict

The north-star is **feasible as a staged engineering program**. It is not feasible as one immediate build.

The important split is between mechanisms that are straightforward with current agent tooling and mechanisms that are still experimental.

| Capability | Feasibility now | Recommendation |
|---|---:|---|
| Version and run one agent reproducibly | Very high | Build now |
| Independent evaluation / replay | Very high | Build now |
| Versioned skills and environments | Very high | Build now |
| Agent health / readiness / recertification | High | Build now after baseline |
| Research agent + evidence reviewer | High | Build now |
| Context packs / client-intake compiler | High | Build incrementally |
| Fixed team templates | High | Build only after solo baseline |
| Shared mission working memory | High | Build when two agents need it |
| Capability-based team recommendation | Medium-high | Build as decision support first |
| Organizational diagnostics from event history | Medium-high | Prototype after event schema stabilizes |
| Urgency-based temporary “surge” team | Medium-high | Build as constrained scheduler, not free spawning |
| Automated team/config selection | Medium | Offline/shadow first |
| Environment-aware optimizer | Medium | Strong experiment candidate |
| Self-maintaining Agent Factory | Medium | Start with diagnosis/ticket creation, not self-deploy |
| Fully autonomous organizational evolution | Low-medium | Research only until eval/sim validity is proven |

## Why the proposal is technically credible

The idea can be decomposed into established engineering families rather than requiring a single breakthrough:

- agent harnesses and tool interfaces;
- workflow/event systems;
- versioned configuration;
- conformance testing and independent verification;
- process / organizational mining;
- dynamic resource allocation;
- contextual routing and bandits;
- simulation / replay;
- knowledge provenance and retrieval;
- autonomic-computing control loops.

The moonshot is the **integration and control discipline**, not a magical all-knowing supervisor.

## Existing assets that should survive

From the current Agent Factory, preserve and evolve rather than rewrite:

- five-valued GreenContract verdict discipline;
- hashed AgentSpec / TeamSpec identity;
- ContextRef / ContextPack with source, freshness, and basis;
- evidence-gated close;
- clean-verifier separation;
- launch/readiness distinctions;
- worktree isolation and sparse event/bus patterns;
- the client-intake principle that questions become checkable acceptance assertions.

## The biggest architectural correction

The product should be sequenced around **one agent as a managed resource**.

A team should not be the first durable abstraction. The platform first needs to prove it can answer:

```text
Which exact agent configuration ran?
In which exact environment?
With which context and skills?
What was it allowed to do?
What evidence shows it succeeded?
How much did it cost?
Is that capability still valid now?
What changed since certification?
```

If those answers do not exist at agent level, team-level optimization will produce attractive but untrustworthy scores.

## Brutal failure modes

1. **Optimizer before evaluator** — produces Goodharted configs that exploit weak checks.
2. **Team before solo baseline** — cannot tell whether coordination helped or merely added cost.
3. **Environment unversioned** — apparent agent improvement may actually be CPU/RAM/network/tool differences.
4. **Research self-confirmation** — research agents reproduce the platform thesis rather than attack it.
5. **Memory pollution** — every agent summary becomes “knowledge.”
6. **Busy-agent swarm without capacity model** — priority inversion, duplicate writes, context loss.
7. **One opaque score** — hides correctness/cost/latency/robustness trade-offs.
8. **Simulation overconfidence** — optimizer learns replay artifacts that do not transfer to production.
9. **Self-maintenance without independent gate** — platform can certify its own bad changes.
10. **UI leads architecture** — visually compelling states exist with no reliable event semantics.

## Feasibility gate

The north-star should be considered on track when one agent can be changed, evaluated, recertified, rolled back, and compared across environment profiles without manual forensic reconstruction.

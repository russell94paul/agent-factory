# North-Star Architecture

## System view

```mermaid
flowchart TB
    Intake[Email / Ticket / Mission Request] --> MC[Mission & Context Compiler]
    MC --> KB[Knowledge + Evidence Plane]
    MC --> Mission[Mission + Mandate + Verification Contract]
    Mission --> Planner[Organization Planner]

    AR[Agent Registry] --> Planner
    CR[Capability Registry] --> Planner
    ER[Environment Registry] --> Planner
    SR[Skill Registry] --> Planner
    Planner --> Plan[Executable Organization Plan]

    Plan --> Runtime[Agent Runtime]
    Runtime --> Hands[Execution Environments / Tools / Sandboxes]
    Runtime --> Events[Durable Run Events]
    Events --> World[Materialized Operational State]
    Runtime --> Verifier[Independent Verifier]
    Verifier --> Eval[Evaluation Record]

    Events --> Diagnostics[Organizational Diagnostics]
    Eval --> Diagnostics
    Diagnostics --> Suggestions[Capability / Team / Process Suggestions]
    Suggestions --> Optimizer[Offline Optimization Lab]
    Optimizer --> Candidate[Candidate Config / Team / Environment]
    Candidate --> Verifier

    Events --> Curator[Memory Curator]
    Eval --> Curator
    Curator --> KB

    Diagnostics --> Maintenance[Factory Maintenance Missions]
    Maintenance --> MC
```

## Layer 1 — Managed Agent Kernel

Owns the atomic unit of the platform:

```text
AgentSpec
AgentVersion
AgentRunBinding
AgentRun
AgentHealth
CapabilitySnapshot
```

The kernel should not know about “army” concepts.

## Layer 2 — Mission Plane

Owns:
- normalized request;
- success contract;
- authority / budget boundary;
- risk;
- urgency;
- artifact scope;
- unresolved questions.

## Layer 3 — Cognitive / Context Plane

Owns:
- immutable source evidence;
- sourced context refs;
- mission working memory;
- agent memory candidates;
- team/mission synthesis;
- durable knowledge promotion;
- retrieval / context packaging.

## Layer 4 — Team / Organization Plane

Owns:
- fixed team templates;
- capability requirements;
- assignment;
- coordination topology;
- staff functions;
- temporary surge teams;
- dissolution.

Do not make every staff function an LLM.

## Layer 5 — Evaluation / Optimization Plane

Owns:
- immutable eval corpus version;
- independent verifier;
- baselines;
- experiments;
- multi-objective scorecards;
- optimizer candidates;
- promotion history.

## Layer 6 — Organizational Diagnostics

Mines actual work history to answer:

```text
Where are missions failing?
Which mission classes have weak capability coverage?
Which queues are bottlenecked?
Which agents are overloaded?
Which handoffs create rework?
Which tools/environment profiles correlate with success or failure?
Would a skill, agent, verifier, deterministic tool, or new team structure help?
```

## Layer 7 — Operator UI

Early UI = operational truth.

Later UI = richer organization world.

Every visual state must come from events, evals, capacities, capability records, or knowledge provenance.

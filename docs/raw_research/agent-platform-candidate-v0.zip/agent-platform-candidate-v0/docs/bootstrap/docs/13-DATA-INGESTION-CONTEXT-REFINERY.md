# Enterprise Data / Context Refinery

The strongest version of the Briefing Room is not "put every company document into RAG." It is a **pre-context refinery** that turns messy enterprise artifacts into sourced evidence objects and only then compiles mission context.

## Sources

```text
email
attachments
tickets
meeting notes
client documents
Git repositories
API/OpenAPI specs
applications/configuration
warehouse schemas
data catalogs
dashboards/metrics
logs/incidents
cloud/infrastructure metadata
```

## Pipeline

```text
RAW ARTIFACT
   ↓ immutable origin + access policy
PARSED EVIDENCE
   ↓
ENTITY / RELATION RESOLUTION
   ↓
CLAIMS / ASSERTIONS / CONTRACT FACTS
   ↓
CLIENT / REPO / API / DATASET PROJECTIONS
   ↓
CASE / MISSION LINKS
   ↓
KNOWLEDGE CANDIDATES
   ↓ write gate
MISSION CONTEXT COMPILATION
```

## Ten optimizations

1. **Canonical artifact IDs + immutable origin** — every derived fact links back to exact source/version.
2. **Entity resolution before embedding** — resolve client/repo/API/table/dashboard/owner names before semantic search.
3. **Temporal validity** — distinguish when a fact was true from when the system learned/checked it.
4. **Source authority descriptors** — measured API/schema/config beats an old narrative summary where appropriate.
5. **Client isolation at retrieval time** — permissions belong on objects/edges and requests, not only the final prompt.
6. **Change-driven re-indexing** — invalidate/rebuild projections when source commit/schema/doc changes instead of periodic full dumps.
7. **Claim/evidence separation** — summaries are interpretations, not replacement sources of truth.
8. **Question-before-human internal search** — every clarification becomes a knowledge need and searches allowed sources first.
9. **Context budget optimizer** — select marginally useful evidence; avoid giant prompt dumps/context rot.
10. **Post-mission write gate** — only verified reusable learning reaches durable organizational knowledge; corrections update usefulness/expiry.

## UI: Evidence Workbench

Before Briefing Room questions reach a person, show:
- resolved entities;
- artifact/source coverage;
- stale/unverified evidence;
- contradictions;
- questions answered automatically;
- remaining high-risk gaps;
- permission-denied sources;
- expected impact of each question.

This is a productive UI surface because the operator can correct the **inputs to context construction**, not merely edit the final LLM prompt.

# Execution Environment Profiles

## Why “environment” is a first-class technical object

For an agent, the environment is not decoration. It is the **execution substrate and resource/tool envelope** in which the agent acts.

A useful technical decomposition is:

```text
Agent brain / harness
        │
        ├── Session / event state
        ├── Context policy
        └── Tool router
                │
                ▼
        Execution Environment
        ├── workspace / filesystem
        ├── sandbox / container / VM
        ├── CPU / RAM / disk
        ├── timeout / concurrency
        ├── network / egress
        ├── credentials / permissions
        ├── repo/worktree state
        ├── installed packages
        ├── APIs / MCP tools
        ├── data locality
        └── observability hooks
```

Version this separately from AgentSpec.

## EnvironmentProfile

Important fields:

```yaml
environment:
  id: migration-lab
  version: 1
  workspace:
    isolation: git-worktree
    persistence: mission
  compute:
    cpu: 4
    memory_gb: 8
    hard_memory_gb: 12
    wall_time_minutes: 60
  network:
    egress: allowlist
  tools:
    allow: [git, pytest, repo_search]
  secrets:
    mode: brokered
  context:
    max_budget_tokens: 50000
  verification:
    verifier_environment: cleanroom-v1
```

## Environment KPIs

Measure separately from agent quality:

- provisioning latency;
- infrastructure error rate;
- OOM / timeout rate;
- tool failure rate;
- egress/API error rate;
- dependency install latency;
- workspace contention;
- duplicate-write / merge conflict rate;
- environment-caused task failure;
- reproducibility rate;
- cost per run;
- CPU/RAM utilization;
- context delivery latency;
- verifier availability;
- isolation violations;
- secret-policy violations;
- recovery / rebuild time.

## Ten useful environment presets

### 1. Read-Only Triage
Fast startup, repo/docs/log search, no mutation. Optimize diagnosis precision, time-to-hypothesis, cost.

### 2. Deep Coding Sandbox
Writable worktree, test tooling, bounded network, larger resource headroom. Optimize verified task success and time-to-green.

### 3. Migration Lab
Pinned dependencies, test API access, warehouse sandbox, replayable fixtures. Optimize end-to-end connector success and reproducibility.

### 4. Verification Cleanroom
No write access to candidate implementation or authoritative grader. Optimize trust and independence.

### 5. Research Environment
Web/repository access, citation/source capture, read-only product repositories. Optimize evidence coverage and source quality.

### 6. Client Intake Environment
Email/ticket/docs/wiki/API-schema readers, no code mutation, strong tenant boundary. Optimize requirements coverage and questions avoided.

### 7. Incident Surge Environment
High-priority read access for multiple analysts; exactly one mutation owner unless explicitly partitioned. Optimize MTTR and collision avoidance.

### 8. Memory Curation Environment
Read mission evidence and candidate digests; write only candidate knowledge. Cannot promote its own output. Optimize provenance completeness and low contamination.

### 9. Factory Maintenance Environment
Writable isolated platform branch, full test suite, no direct production deploy. Requires canary plan and rollback artifact.

### 10. Offline Optimization Lab
Sanitized historical corpus, no production credentials, parallel candidate runs, pinned resource envelopes. Optimize Pareto front across correctness/cost/latency/robustness.

## Optimization implication

Environment must appear in the experiment binding. Comparing Agent A in a generous environment with Agent B in a constrained environment is not an agent comparison.

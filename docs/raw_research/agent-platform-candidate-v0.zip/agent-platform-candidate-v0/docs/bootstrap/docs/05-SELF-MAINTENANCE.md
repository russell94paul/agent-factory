# Self-Maintaining Agent Factory

## Principle

Agent Factory should eventually be one of the systems managed by Agent Factory.

Do not begin with unrestricted self-editing. Begin with a control loop whose outputs are internal maintenance missions.

```mermaid
flowchart LR
    O[Observe] --> D[Diagnose]
    D --> T[Create Internal Ticket]
    T --> P[Propose Change]
    P --> E[Evaluate in Clean Environment]
    E --> G{Gate}
    G -->|reject| D
    G -->|approve| C[Canary]
    C --> M[Measure]
    M -->|good| R[Promote]
    M -->|bad| B[Rollback]
    R --> K[Knowledge Writeback]
    B --> K
```

## What should maintain itself

### Agents
- model binding changes;
- prompt drift;
- tool/API compatibility;
- skill freshness;
- cost regressions;
- mission-class success regressions.

### Teams
- redundant members;
- poor handoffs;
- coordination overhead;
- stale topology assumptions;
- verifier bottlenecks.

### Knowledge
- stale sources;
- contradictions;
- duplicate evidence chains;
- popular-but-wrong memories;
- unused or harmful knowledge.

### Workflows
- repeated agent tool sequences that should become deterministic tools;
- retry loops;
- bottlenecks;
- unreachable/obsolete stages.

### Platform code
- dependency/security updates;
- failing tests;
- dead configuration;
- schema/version drift;
- operational incidents.

### Infrastructure
- provisioning failures;
- quota/resource pressure;
- latency;
- broken observability;
- environment profile drift.

## Maintenance autonomy ladder

```text
L0 observe only
L1 create diagnostic finding
L2 create internal ticket
L3 propose patch/config change
L4 run offline verification
L5 create canary proposal
L6 gated canary execution
L7 bounded auto-promotion for explicitly low-risk change classes
```

Do not skip levels.

## Core metric

**Maintenance leverage** = reduction in human maintenance effort while holding or improving verified reliability.

Also track:
- mean time to detect degradation;
- mean time to diagnosis;
- maintenance-ticket precision;
- fix acceptance rate;
- rollback rate;
- escaped regression rate;
- recertification latency;
- stale configuration age;
- repeated incident rate.

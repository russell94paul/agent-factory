# Ten Organizational Presets Worth Testing

These are **configuration templates**, not claims that multi-agent is always superior. Every preset should compile to versioned config and must compete with a simpler baseline.

| Preset | Shape | Best for | Primary KPIs | Maintenance loop |
|---|---|---|---|---|
| **Solo Operator** | 1 worker + clean verifier | sequential coding/migration | verified success, time-to-green, cost | recertify agent/model/environment/skills |
| **Research Fan-Out** | orchestrator → parallel scouts → reviewer/synthesizer | broad research | source correctness, decision quality, human review time | retire low-yield scout roles, update source policies |
| **Incident Surge** | parallel diagnostics → incident lead → gated repair | outages | MTTR, diagnosis accuracy, rollback, disruption | replay incidents, tune routing/preemption |
| **Data Quality Guardian** | deterministic monitors → diagnosis agent → verifier | data health | detection precision, data downtime, false alerts | retrain thresholds/rules, recertify checks |
| **Client Discovery Council** | context compiler → domain lookup → interview → spec verifier | vague client requests | spec completeness, human questions, first-pass success | learn recurring gaps, improve questionnaire |
| **API Integration Pod** | API specialist route → worker → contract verifier | integrations | auth/API correctness, first data, regressions | maintain provider skills/environment profiles |
| **Migration Factory Line** | deterministic gates + one worker at ambiguous seams | repeatable migrations | throughput, failure rate, human touch time | convert repeated LLM steps to meta-tools |
| **Knowledge Stewardship** | curator + contradiction/evidence checks | organizational memory | retrieval usefulness, stale rate, correction rate | expiry/reverification/dedupe |
| **Optimization Lab** | candidate generator → sandbox runners → external evaluator | bounded experimentation | Pareto improvement, transfer, search cost | prune search space, refresh holdout |
| **Factory Reliability Corps** | monitors → diagnostician → maintenance worker → verifier | self-maintenance | MTTD/MTTR, recurrence, rollback, maintenance minutes | recursive internal mission loop |

## How presets should be represented

```yaml
preset:
  id: incident-surge
  version: 1
  mission_classes: [incident]
  topology: parallel_diagnosis_then_gated_repair
  members:
    - capability: diagnosis
      count: 2
    - capability: incident_lead
      count: 1
  environment_profile: env.incident-surge
  communication_policy: sparse_structured
  context_policy: incident_context
  verification_policy: independent
  budget: ...
  hard_limits: ...
```

## Optimization dimensions

Presets can later be parameterized over:
- number of workers;
- model binding;
- skill packages;
- environment;
- context policy;
- parallelism;
- review depth;
- preemption;
- budget/timeouts.

Do not let the optimizer mutate hard permissions, verifier authority or audit controls.

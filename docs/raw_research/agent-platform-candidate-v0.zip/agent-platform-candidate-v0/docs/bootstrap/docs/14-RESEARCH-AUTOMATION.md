# Research Automation Architecture

## Why research is a strong first team use-case

Broad research often decomposes into genuinely independent source directions. This is a better early multi-agent candidate than a sequential shared-state coding task.

## Pipeline

```text
Question
  ↓
Research Orchestrator
  ├─ academic/prior-art scout
  ├─ implementation/repo scout
  ├─ contemporary/product scout
  └─ adversarial scout
          ↓
Source Verifier
          ↓
Evidence Auditor
          ↓
Research Synthesizer
          ↓
Experiment Designer
          ↓
Human acceptance
          ↓
Systems Architect / Implementation Handoff
```

## Critical separation

Research agents discover evidence. They do not automatically update product truth.

```text
raw research
→ audited research
→ synthesis
→ decision/ADR
→ approved handoff
→ implementation
→ verification
```

## Automation target

A user should be able to run:

```text
/research R48
```

and receive a run directory with:
- decomposition;
- source ledger;
- claims;
- counterevidence;
- audits;
- synthesis;
- experiments;
- decisions needed.

## Self-improvement

Measure research quality over a small benchmark of prior runs with known citation mistakes/corrections.

Candidate improvements can change:
- scout prompts;
- source-search strategies;
- number of scouts;
- source verifier rules;
- synthesis template.

Do not optimize on "number of sources". Optimize on reviewed claim quality and human decision time.

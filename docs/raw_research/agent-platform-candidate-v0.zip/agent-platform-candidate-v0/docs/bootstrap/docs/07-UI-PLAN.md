# UI Plan — Thin Flight Deck First, Command World Later

## Is a UI a waste of time?

A rich animated UI is a waste **before** reliable events and evals. A thin operational UI is not.

Build the first UI as an observability/debugging instrument for one agent.

## Phase 1 UI — Agent Flight Deck

Show:
- current mission;
- exact AgentSpec + environment binding;
- context sources / freshness;
- tool calls and artifacts;
- cost/latency;
- verifier status;
- blockers;
- human questions;
- replay timeline;
- capability/readiness change.

## Phase 2 — Briefing Room

Show agents/services assembling the mission understanding, but every “participant” card maps to a real source/function.

Panels:
- understood requirements;
- sourced facts;
- assumptions;
- contradictions;
- unanswered questions;
- which questions were answered internally;
- acceptance criteria generated.

## Phase 3 — Team Composer

UI can present:
- best solo agent baseline;
- candidate fixed teams;
- capability coverage;
- expected cost/latency;
- historical evidence;
- environment compatibility.

## Phase 4 — Organizational Diagnostics

Views:
- capability coverage heatmap;
- failure/bottleneck map;
- queue/capacity pressure;
- recurring rework;
- suggested interventions;
- evidence behind each suggestion.

## Phase 5 — Surge button

The button must show consequences before confirmation:

```text
Mission urgency: CRITICAL
Recommended team: 4 analysts + 1 mutation owner
Preemptions: 2 low-priority research tasks
Expected cost: $18–$31
Expected latency improvement: evidence interval, not fake certainty
Verifier capacity: READY
```

## Gameful without gaming

Use progression only for real capability:
- capability readiness;
- verified mission classes;
- cost-quality frontier;
- reliability streaks with sample size;
- newly certified skills;
- knowledge coverage.

Never reward messages, token use, agent count, or visual motion.

# Repository Strategy

## Recommendation now

Keep:

```text
workspace/
├── agent-factory/          # production truth
├── agent-army-research/    # research truth
└── agent-platform-bootstrap-v1/ # reconciliation + migration plan
```

Do not merge the first two repos immediately.

## Why not merge today

The research repository explicitly uses a graduation protocol. Production code has a stronger truth status than candidate architecture. A premature monorepo makes it easier for speculative docs and product code to look equally authoritative.

## When a monorepo becomes worth it

Consider migrating when at least three of these become real shared packages:

- agent-kernel;
- events/world state;
- eval contracts;
- context packages;
- environment profiles;
- capability registry;
- mission schemas;
- shared UI data contracts.

And when cross-package changes are frequent enough that atomic commits materially reduce friction.

## Future monorepo boundary rules

Even in one Git repository, preserve semantic boundaries:

```text
research/*              cannot be imported by runtime code
packages/contracts/*    dependency-light
apps/*                   depend on packages, not research
services/*               own persistence/runtime side effects
experiments/*            cannot promote to prod without handoff/ADR
```

Add CI checks for forbidden imports and require an implementation handoff artifact to graduate a research mechanism.

## Migration style

Use strangler migration:

```text
existing Agent Factory
    + new typed seam
    + shadow record/projection
    + compare
    + migrate consumer
    + remove old path after parity
```

Do not greenfield-rewrite the working verifier/context/versioning primitives.

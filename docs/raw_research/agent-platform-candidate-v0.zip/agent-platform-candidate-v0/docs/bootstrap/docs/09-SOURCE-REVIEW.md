# Source Review Summary

## Agent Factory — strongest existing primitives

- `factory/contract.py`: independent outcome vocabulary including PASS/FAIL/UNMEASURABLE/ERROR/NOT_RUN.
- `factory/blueprint.py`: AgentSpec and TeamSpec config identity hashes.
- `factory/context.py`: sourced ContextRef/ContextPack with freshness and evidence-basis semantics.
- `factory/launch.py`: separates “may run supervised”, “may run unattended”, and “may trust output”.
- `factory/evidence.py` + task store: evidence-gated completion.
- `factory/sessions.py`, worktrees, claims, bus: practical concurrency/control primitives.
- `docs/CLIENT-INTAKE-PLATFORM-PLAN.md`: client questionnaire → machine-checkable contract → execution → assurance → learning loop.

## Agent Factory — key warning

`blueprints/orchestrator_team.yaml` is intentionally retained as a rejected hypothesis. The repository recommends a single end-to-end worker plus independent verifier as the first topology. The broader research later corrected the statistical interpretation of the quoted multi-agent mean, so treat this as a sequencing decision, not a universal claim that multi-agent systems are worse.

## Agent Army Research — current state

The research repository is unusually disciplined:
- separate truth semantics from production;
- evidence tiers;
- explicit synthesis step;
- experiment designer / evidence auditor / research synthesizer skills;
- architecture and research prompts for knowledge, readiness, compiler, evolution, governance, and UI.

Wave 0 already changed the program materially: it rejected broad novelty/category claims and recommended moving evaluation earlier. Do not restart from scratch and lose that negative result.

## What this bootstrap changes

1. Make the **single managed agent** the first product layer.
2. Add **Execution Environment Profile** to every experimental binding.
3. Add organizational diagnosis as a separate data/decision layer before dynamic organization creation.
4. Interpret “swarm” as constrained surge scheduling with explicit capacity/preemption.
5. Treat Agent Factory self-maintenance as a control loop with staged autonomy.
6. Re-sequence research around evaluation, single-agent lifecycle, environment effects, organizational mining, and safe dynamic assignment.

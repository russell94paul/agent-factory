# Build Sequencing

## Principle

```text
one measured agent
→ one maintainable agent
→ reusable skills
→ research/eval automation
→ fixed team
→ capability registry
→ organizational diagnosis
→ suggested team changes
→ surge composition
→ offline optimization
→ guarded self-maintenance
```

## Phase 0 — Reconcile and freeze the measurement surface (2–4 days)

Deliver:
- current main-branch inventory;
- accepted/rejected Wave-0 research decisions;
- baseline eval corpus version;
- authoritative verifier boundary;
- `AgentRunBinding` schema;
- `EnvironmentProfile` schema.

Exit:
- one command can identify the exact agent × environment × mission × verifier binding for a run.

## Phase 1 — Single-Agent Kernel (1–2 weeks)

Build:
- versioned AgentSpec;
- EnvironmentProfile;
- Mission + Mandate;
- ContextPack assembly seam;
- skill references;
- tool/permission envelope;
- durable run/event record;
- external verifier;
- cost/latency/tool metrics;
- replay record.

Exit:
- same historical task can be run under two agent configurations and two environment profiles and compared fairly.

## Phase 2 — Agent Maintainability (1 week)

Build:
- Agent Health / Capability Snapshot;
- recertification triggers;
- stale model/tool/skill/environment detection;
- canary/rollback metadata;
- maintenance-ticket generator;
- post-run memory digest candidate.

Exit:
- a configuration change invalidates or narrows certification instead of silently inheriting it.

## Phase 3 — Research Automation (3–7 days)

Install:
- base research agent;
- evidence reviewer;
- research orchestrator;
- adversarial reviewer;
- synthesis/promoter.

Exit:
- one research question can produce a traceable source pack, reviewed claims, contradictions, architecture implications, and a next experiment without manual copy/paste.

## Phase 4 — Context / Intake Compiler (1–2 weeks)

Build:
- ticket/email normalization;
- source/artifact resolver;
- information-gap detector;
- internal-answer-before-human-question loop;
- ranked clarification questions;
- Briefing Room data contract;
- accepted requirement → verification assertion linkage.

Exit:
- vague request becomes a versioned Mission + ContextPack + unresolved-question set.

## Phase 5 — First Fixed Team (1–2 weeks)

Precondition:
- solo baseline exists on a versioned mission corpus.

Build only the smallest topology justified by failures, e.g.:

```text
planner/researcher only when needed
      ↓
primary worker
      ↓
independent verifier
```

Prefer parallel workers only for genuinely independent subtasks.

Exit:
- team beats the solo baseline under predeclared same-budget or quality/cost criteria.

## Phase 6 — Capability Registry + Organizational Diagnostics (2 weeks)

Build:
- capability evidence model;
- mission-class performance profiles;
- workload/capacity model;
- bottleneck and failure clustering;
- capability-gap detector;
- “new skill / new agent / new team member / process fix” recommendations.

Start as **recommendation only**.

Exit:
- historical event data produces useful, reviewable capability-gap recommendations with evidence links.

## Phase 7 — Surge Composer (“Swarm button”) (1–2 weeks)

The button is a constrained scheduler, not uncontrolled spawning.

Inputs:
- mission class;
- urgency;
- required capabilities;
- active workloads;
- preemption cost;
- environment availability;
- permissions;
- verifier capacity.

Outputs:
- recommended temporary team;
- agents displaced or delayed;
- expected benefit/cost;
- why each member was selected;
- rollback/dissolution plan.

Exit:
- recommendation beats simple “best idle agent” routing in replay/shadow tests.

## Phase 8 — Optimization Lab (ongoing)

Search over:
- agent config;
- model binding;
- skills;
- environment profile;
- context policy;
- tool policy;
- team topology;
- routing;
- verification depth;
- budgets.

Promotion:

```text
offline corpus
→ holdout
→ shadow
→ limited live
→ production
```

## Phase 9 — Factory Maintains Factory

Begin with:

```text
observe → diagnose → create internal ticket → propose fix → test → human approve
```

Only later consider bounded automated canary deployment.

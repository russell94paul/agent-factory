# Memory, Synthesis, and Agent Communication

## Four memory layers

```text
1. Immutable evidence
   raw artifacts, logs, emails, code diffs, test outputs

2. Agent episodic memory
   structured digest of what one agent observed/tried/learned

3. Mission working memory
   temporary shared state for the active mission

4. Organizational knowledge
   evidence-backed, scoped, versioned, curated reusable knowledge
```

Do not let layer 2 write directly into layer 4.

## Agent self-digest

Each meaningful run may emit a candidate:

```yaml
agent_digest:
  observations: []
  hypotheses: []
  actions_tried: []
  worked: []
  failed: []
  evidence_refs: []
  reusable_candidate: []
  confidence: stated
  unresolved: []
```

## Team / mission synthesis

A Memory Curator consumes:
- agent digests;
- source evidence;
- tool outputs;
- code diff;
- verifier outcomes;
- human corrections.

It produces candidate mission lessons. Evidence outranks repetition.

## Cross-agent communication

Prefer sparse structured needs over chatter.

```yaml
knowledge_need:
  mission_id: M-104
  topic: oauth_invalid_client
  entities: [client-x, connector-y]
  desired_evidence: verified_resolution
  scope: client-x
  max_age_days: 180
```

A broker resolves knowledge/experts. Direct agent-to-agent dialogue is reserved for cases where persisted artifacts cannot carry the interaction.

## Publish/subscribe events

Useful events:
- `FindingPublished`
- `KnowledgeNeedRaised`
- `ContextPackUpdated`
- `ContradictionDetected`
- `AgentCapabilityChanged`
- `VerifierCapacityChanged`
- `MissionBlocked`

## Write gate

Before organizational promotion require:
- source provenance;
- scope;
- freshness/validity;
- contradiction check;
- outcome evidence where applicable;
- permission/tenant check;
- promotion level appropriate to persistence.

# 90-Day North-Star Roadmap

The roadmap protects the immediate work objective while making each implementation choice compatible with the larger platform.

## Days 0–14 — prove one managed agent

### Week 1
- reconcile current `main` against W0 synthesis;
- freeze/record evaluator + corpus versions;
- add `EnvironmentProfile` and `AgentRunBinding` candidate schemas behind adapters;
- persist exact run binding;
- add matched comparison command/report;
- establish a read-only Flight Deck inspector for one run.

### Week 2
- add lifecycle/recertification triggers;
- run one real connector/workflow mission with supervised execution;
- compare at least two agent/environment bindings;
- capture first episodic memory digest candidate;
- measure human minutes, cost, latency, task outcome, environment failure attribution.

**Gate:** one agent can be changed, evaluated, recertified and rolled back without ambiguity about what changed.

## Days 15–30 — automate research and context

- install Research Orchestrator + scouts/reviewer/synthesizer flow;
- run R30 early and R46–R48;
- create source/claim artifacts automatically;
- implement request/email normalization seam;
- compile existing ContextRefs into task-specific packs;
- generate internal knowledge needs and unresolved-question list;
- prototype Briefing Room as a data-first UI.

**Gate:** one vague request can become a sourced Mission package whose missing information is explicit.

## Days 31–45 — skills before teams

- add a minimal SkillRef/Skill package convention;
- mine repeated successful traces for skill/meta-tool candidates;
- create 2–3 verified reusable skills;
- evaluate skill version changes against holdout missions;
- add agent capability snapshot by mission class.

**Gate:** a measured improvement can be attributed to a skill/tool/context change rather than a vague "agent got better" claim.

## Days 46–60 — first justified team

- identify one mission class where solo baseline exposes a real bottleneck;
- design the smallest team candidate that addresses it;
- minimize sequential LLM handoffs;
- compare same-budget/quality against solo/routed specialist baseline;
- keep rejected candidates as evidence.

**Gate:** at least one multi-agent arrangement has measured value in your own estate, or the system explicitly concludes it does not yet.

## Days 61–75 — organizational diagnosis

- instrument mission-class trends and capacity;
- build failure/bottleneck clustering;
- generate recommendation-only organizational proposals;
- include remedy alternatives: code/context/skill/environment/routing/agent/team;
- build Org Diagnostics UI panel.

**Gate:** recommendations are evidence-linked and useful enough that an operator accepts/rejects them for rational reasons.

## Days 76–90 — surge + offline optimization MVP

- build recommendation-only Surge Composer;
- simulate urgency/preemption/capability selection against replay history;
- create bounded offline optimizer over 2–3 dimensions only;
- create candidate registry with lineage and Pareto metrics;
- create first internal Factory maintenance mission from real degradation/maintenance need.

**Gate:** the platform can propose a better organization/configuration, prove it in replay/holdout, and require explicit promotion rather than mutating production itself.

## Do not promise by day 90

- autonomous production evolution;
- fully general company-wide staffing optimization;
- trustworthy counterfactual forecasts without enough data;
- federation across organizations;
- a 3D/animated Command World as the operational source of truth.

# Organizational Diagnostics, Capability Gaps, and Surge Composition

## The new layer

Use four explicit components rather than one omniscient “army manager.”

### Organizational Diagnostician
Mines events, missions, outcomes, queues, failures, costs, and rework.

### Capability Planner
Maps recurring problems to capability deficits and proposes the cheapest intervention.

### Surge Composer
Builds a temporary mission team under urgency, capacity, permission, and preemption constraints.

### Organization Optimizer
Evaluates candidate structure/config changes offline before promotion.

## Diagnosis loop

```mermaid
flowchart LR
    E[Event + Eval History] --> P[Process / Failure Mining]
    P --> G[Capability Gap Model]
    G --> R{Intervention Type}
    R -->|procedure repeats| S[Create / improve Skill]
    R -->|deterministic pattern| T[Create Meta-tool]
    R -->|missing expertise| A[Create / retrain Agent]
    R -->|capacity shortage| C[Add capacity / scheduling]
    R -->|handoff failure| W[Change workflow/topology]
    R -->|verification gap| V[Add verifier]
    R -->|context gap| K[Improve context / knowledge]
    S --> X[Experiment]
    T --> X
    A --> X
    C --> X
    W --> X
    V --> X
    K --> X
```

## Team-member suggestion is a capability-gap problem

Do not ask “which new agent would be cool?”

Ask:

```text
Which mission classes are underperforming?
What failure categories dominate?
Which capabilities are absent, stale, overloaded, or low-confidence?
Is the problem expertise, capacity, process, environment, context, verification, or tooling?
What is the smallest intervention predicted to improve the outcome?
```

A recommendation can be:
- new skill for an existing agent;
- deterministic tool;
- context source;
- additional verifier;
- agent config variant;
- new specialist agent;
- new team pattern;
- environment change;
- no agent change at all.

## Surge / “Swarm” button

A safe surge request is:

```yaml
surge_request:
  mission_id: INC-104
  urgency: critical
  deadline_minutes: 30
  required_capabilities:
    - oauth_diagnosis
    - connector_runtime
    - deployment_observability
  mutation_slots: 1
  analysis_slots: 4
  preemption_policy: allow_low_priority_read_only
  max_cost_usd: 40
```

The scheduler ranks candidate assignments by a vector such as:

```text
capability fit
× readiness
× mission-class evidence
× environment compatibility
× availability
× knowledge/context affinity
− preemption cost
− coordination overhead
− policy risk
```

Never collapse this into one unexplained number in the UI. Show the dimensions and reason.

## KPIs

- verified success by mission class;
- first-pass success;
- time-to-green / MTTR;
- queue wait;
- utilization and overload;
- rework;
- handoff failure;
- preemption cost;
- coordination overhead;
- surge benefit vs baseline routing;
- recommendation acceptance rate;
- recommendation realized benefit;
- capability coverage;
- capability freshness;
- verification capacity;
- environment availability.

# Research Execution Order — Delta Program

This is **not a restart from scratch**. `agent-army-research` Wave 0 already did the highest-value thing a research program can do: it falsified weak novelty assumptions, found a live defect, and changed the recommended research order.

## Gate 0 — Human decision on W0

Before new conceptual research, read and explicitly accept/reject the major conclusions in:

- `agent-army-research/research/synthesis/W0-foundations.md`
- `agent-army-research/docs` / canonical research files it proposes changing
- `agent-factory/docs/agent-army/APPROVED_CONCEPTS.md`

Create ADRs only for mechanisms you actually accept. Do not bulk-promote a research wave.

## Wave A — Measurement before organization

1. **R30 existing — Evaluation / Benchmarks / Experiments**
   - Move this forward from the old W5 position.
   - Outcome: mission corpus, verifier contracts, experimental thresholds.
2. **R46 — Independent 2026 Prior-Art Delta**
   - Re-check IMACS, Artificial Organisations, current agent harnesses, organizational MAS, workflow optimization, and dynamic task allocation with independent sources.
3. **R47 — Single-Agent Lifecycle Kernel**
   - Establish the smallest object that can be versioned, run, measured, maintained, and recertified.
4. **R48 — Execution Environment as an Experimental Variable**
   - Separate agent quality from environment/harness effects.

**Exit:** a run can be bound to agent + model + skill + environment + context policy + verifier + mission corpus.

## Wave B — Context and organizational knowledge

5. **R21 existing — Collective Cognition**, revised by W0 vocabulary decisions.
6. **R37 existing — Context/Readiness/Cognitive Logistics**, but treat the name as provisional and focus on mechanisms.
7. **R52 — Context Compilation & Clarification Economics**
   - vague request → internal evidence gathering → ranked human questions → executable specification.
8. **R53 — Memory Write-Gate & Cross-Agent Synthesis**
   - agent digest → mission working memory → team curator → organizational knowledge.

**Exit:** context quality and memory usefulness are measurable, with provenance and write gates.

## Wave C — Organization diagnosis before organization generation

9. **R49 — Organizational Diagnostics & Capability Gaps**
   - infer where the company/project is weak from event/outcome data.
10. **R50 — Surge Composition / Dynamic Resource Allocation**
   - urgency-aware temporary team suggestions, including preemption cost.
11. **R54 — Skill vs Agent vs Team vs Deterministic Tool Decision Rule**
   - prevent every capability gap from becoming another agent.

**Exit:** the platform can recommend a change to the organization without automatically making it.

## Wave D — Safe adaptation

12. **R51 — Self-Maintaining Factory**
    - monitor/analyze/plan/execute/verify loops for the Factory itself.
13. **R24 existing — Replay, Simulation, Counterfactuals**
    - only after a versioned corpus and stable evaluator exist.
14. **R55 — Optimization Search Space & Transfer Validity**
    - determine what optimization results transfer across models/environments/mission classes.
15. **R23/R42 existing — Organization representation / Org-IR**
    - run after there is more than one empirically useful configuration to represent.

**Exit:** offline candidates can be compared and promoted with no self-grading and no production self-mutation.

## Wave E — Product / human factors

16. **R25/R41 existing — UI + Human Factors**
17. **R56 — Gameful Control Without Goodharting**
18. **R29 existing — Repository-grounded migration**, rerun against the now-current code and accepted architecture.

## Explicitly delayed

Do not prioritize before the above:

- uncontrolled morphogenesis;
- production evolutionary search;
- federation;
- organizational fields/stigmergy unless a simpler event/projection mechanism fails;
- supervisor hierarchies without measured coordination bottlenecks;
- animated world UI without real event/state semantics.

## Research team topology

Use multi-agent research when the work is naturally breadth-first:

```text
Research Orchestrator
   ├── Prior-art Scout
   ├── Academic Evidence Scout
   ├── Implementation/Repo Scout
   ├── Adversarial Scout
   └── Product/UX Scout (only when relevant)
            ↓
Evidence Reviewer
            ↓
Research Synthesizer
            ↓
Experiment Designer
            ↓
Human decision
```

Do **not** split a sequential coding change into five agents merely because the research workflow parallelizes well.

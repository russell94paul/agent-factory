# R53 — Memory Write-Gate and Cross-Agent Synthesis

## Objective

Prevent useful context from remaining trapped in individual agents while preventing organizational memory from becoming a pile of duplicated or hallucinated summaries.

## Proposed memory layers to test

1. immutable evidence;
2. agent episodic digest;
3. mission working memory;
4. curated organizational knowledge;
5. versioned skill/doctrine only after stronger promotion gates.

## Research questions

- what should an agent self-summarize at end/checkpoint?
- when should a team/mission curator reconcile agent digests?
- how should contradictions be represented?
- how should provenance/independence be preserved?
- how should retrieval usefulness update ranking without amplifying popular-but-wrong memory?
- what retention/expiry rules prevent stale knowledge?
- when should knowledge remain client-private vs shared organizationally?

## Candidate write pipeline

```text
raw evidence
→ observation
→ agent digest candidate
→ dedupe/conflict check
→ mission curator synthesis
→ verification / scope / expiry
→ organizational knowledge candidate
→ measured reuse
→ promote / revise / deprecate
```

## Required output

- schemas;
- write gate;
- curator responsibilities;
- knowledge usefulness metrics;
- contradiction model;
- retrieval feedback model;
- permission model;
- UI provenance trail;
- adversarial memory-poisoning tests.

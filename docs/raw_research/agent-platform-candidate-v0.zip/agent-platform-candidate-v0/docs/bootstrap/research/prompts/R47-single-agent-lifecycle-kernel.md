# R47 — Single-Agent Lifecycle Kernel

## Objective

Design the smallest production primitive that lets Agent Factory **develop, operate, maintain, compare, and improve one agent correctly** before scaling to teams.

## Core hypothesis

A team factory cannot be scientifically optimized until an individual agent execution is a reproducible, versioned, externally evaluated experimental unit.

## Research

Study current agent runtimes/harnesses, software artifact versioning, model/eval registries, canary deployment, certification, SRE health models, and agent skill systems.

## Define the binding

Determine which fields belong to:

```text
AgentSpec
ModelBinding
SkillSet
ToolPolicy
EnvironmentProfile
ContextPolicy
Mission
Mandate
Verifier
AgentRun
CapabilitySnapshot
```

Answer which changes invalidate certification and which can use a declared transfer rule.

## Lifecycle

Design:

```text
DRAFT
→ EVALUATING
→ CERTIFIED(scope)
→ ACTIVE
→ DEGRADED
→ RECERTIFICATION_REQUIRED
→ CANARY
→ ACTIVE(new version)
→ RETIRED
```

Do not force a scalar health score if structured state is safer.

## Required experiments

At minimum:

1. same AgentSpec, different environment profile;
2. same AgentSpec, different model binding;
3. same model/environment, different skill;
4. same binding, different context policy;
5. candidate version vs current version on holdout tasks;
6. stale dependency/tool event triggering recertification.

## Metrics

- externally verified task success;
- time-to-green;
- cost;
- latency;
- tool errors;
- human interventions;
- repeatability;
- side effects;
- calibration/uncertainty if meaningful;
- environment-caused failure rate;
- recertification time.

## Required output

- canonical schemas;
- lifecycle state machine;
- certification/transfer rules;
- event model;
- storage model;
- UI inspector;
- minimal Agent Factory file-level migration plan;
- 10 negative controls;
- what not to build yet.

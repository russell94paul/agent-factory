# R52 — Context Compilation and Clarification Economics

## Objective

Turn vague email/ticket requests into the smallest high-confidence Mission package needed for execution, while minimizing avoidable human questions.

## Flow

```text
email/ticket + attachments
→ normalize intent/entities
→ resolve related repos/APIs/apps/docs/clients
→ retrieve evidence and similar missions
→ identify unknowns/contradictions
→ attempt internal answers
→ rank remaining questions by expected information gain × downstream risk
→ client/operator briefing
→ Mission + Mandate + acceptance assertions + ContextPack
```

## Research

Study requirements elicitation, ambiguity detection, active learning/question selection, retrieval planning, graph retrieval, case-based reasoning, context compression, and human factors.

## Required distinctions

Never confuse:
- fact vs assumption;
- source availability vs source relevance;
- relevance vs correctness;
- context coverage vs mission success;
- question count vs question value.

## Metrics

- mission first-pass success;
- percent of clarification questions answered internally;
- human questions per mission;
- human minutes;
- specification defects caught before implementation;
- context token waste;
- retrieval usefulness;
- stale/incorrect context usage;
- requirement→verifier coverage;
- time from email to executable mission.

## Required output

- context compiler architecture;
- ranking formula candidates;
- Briefing Room data contract;
- stopping criteria;
- A/B design;
- source permission model;
- first vertical slice for Agent Factory.

# R55 — Optimization Search Space and Transfer Validity

## Objective

Determine how to optimize agent/team configurations without overfitting a corpus or transferring a winner into a different model/environment where it no longer wins.

## Candidate dimensions

```text
agent prompt/config
model binding
skill set
tool policy
environment profile
context policy
retrieval policy
team topology
communication policy
review depth
budget/timeouts
verification strategy
routing/preemption policy
```

## Questions

- Which dimensions interact strongly?
- What can be tuned independently?
- What requires revalidation when model/environment changes?
- How should train/validation/holdout historical missions be split?
- What is the minimum sample needed before promotion?
- How should multi-objective Pareto/quality-diversity results be represented?
- How do we detect reward hacking and simulation mismatch?

## Required output

- search-space schema;
- constraint system;
- transfer matrix;
- experiment budget strategy;
- promotion gates;
- candidate registry schema;
- UI Pareto/tournament views;
- stop rules for expensive searches.

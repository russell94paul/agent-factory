# R48 — Execution Environment Profiles and Harness Effects

## Objective

Make the **environment** a first-class, versioned experimental variable instead of hidden infrastructure noise.

## Working definition

An Execution Environment Profile may include:

- workspace/worktree strategy;
- OS/container image;
- CPU/RAM/disk/time ceilings;
- dependency state;
- repo ref and dirty-state policy;
- network/DNS/proxy policy;
- secrets and credential capability references;
- tool/MCP availability;
- API quotas;
- data locality;
- sandbox/isolation;
- observability/tracing hooks;
- concurrency/contention constraints.

## Research questions

1. How much does environment configuration change agent task success independently of model/prompt?
2. Which environment features should be part of the certification identity?
3. Which should be measured as covariates rather than identity?
4. How should a scheduler choose an environment for a mission?
5. When does a richer environment increase capability versus increase attack surface/noise?
6. What environment presets are useful for research, coding, verification, incident response, data migration, client intake, and self-maintenance?

## Experimental design

Use matched tasks and matched agent versions. Vary one environment dimension at a time where possible.

Measure:

```text
success
infra-error rate
provisioning latency
OOM/timeout rate
tool/API failure rate
reproducibility
cost
resource utilization
contention
isolation violations
secret exposure incidents
rebuild/recovery time
```

## Required output

- EnvironmentProfile schema;
- environment versioning rules;
- 10 recommended presets;
- selection/routing algorithm candidates;
- environment × agent interaction matrix;
- UI health card;
- experiment suite;
- migration plan.

# R46 — Independent 2026 Prior-Art Delta

## Objective

Independently re-test the current Agent Platform thesis against the strongest prior art available as of the run date. This is a **delta** from Wave 0, not a novelty-seeking exercise.

## Required inputs

- current `agent-factory` commit;
- `agent-army-research/research/synthesis/W0-foundations.md`;
- current ontology/architecture after any accepted W0 decisions;
- this bootstrap's north-star architecture.

## Questions

1. Which existing systems already implement organization configuration, dynamic team selection, capability routing, process mining, organizational mining, self-healing, shared agent memory, or agent optimization?
2. What changed in 2026 research that invalidates assumptions in W0?
3. Which proposed mechanisms are ordinary engineering patterns that should be adopted rather than branded as inventions?
4. Where is there still a useful **product integration gap**, even when novelty is absent?
5. Which ideas should be removed from the roadmap because a mature external implementation can be adopted?

## Mandatory source classes

Search primary papers/specifications and maintained source repositories. Include at minimum:

- organization-oriented MAS / Moise+ / JaCaMo / OperA lineage;
- IMACS or the current equivalent organizational-configuration work;
- contemporary multi-agent LLM orchestration;
- process/organizational mining;
- dynamic task/resource allocation;
- autonomic/self-healing computing;
- agent harness/context engineering;
- agent workflow optimization/meta-tools;
- memory/graph retrieval systems.

## Method

For each load-bearing claim record:

```yaml
claim:
source:
primary_source_opened: true|false
source_date:
mechanism:
task_domain:
evidence_tier:
replication_status:
agent_factory_relevance:
changed_since_W0: true|false
```

Do not count several papers from the same lab/dataset as independent confirmations.

## Required output

- delta from W0, not a rewrite of W0;
- competitor/prior-art matrix;
- build/adopt/ignore recommendations;
- terminology collisions;
- architecture implications;
- 5 claims most likely to be wrong;
- experiments that would change the roadmap;
- explicit `NOW / NEXT / LATER / RESEARCH ONLY / DO NOT BUILD` table.

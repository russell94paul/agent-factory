# R56 — Gameful Organizational Control Without Goodharting

## Objective

Design an interface that feels immediate, satisfying, visual, and game-like while rewarding **verified organizational competence rather than activity**.

## Explore

- progressive disclosure;
- mission briefing UX;
- confidence/unknown visualization;
- capability readiness;
- timeline/replay;
- agent/team selection explanations;
- optimization tournaments;
- intervention mechanics;
- organizational health;
- learning/capability progression.

## Forbidden reward proxies

Do not reward:
- messages;
- tool calls;
- token burn;
- number of agents;
- generated files;
- animation frequency;
- self-reported confidence.

## Candidate real progression signals

- verified success by mission class;
- first-pass success;
- cost per accepted outcome;
- regression/rollback rate;
- human intervention;
- knowledge reuse proven helpful;
- capability breadth with evidence;
- recertification/freshness;
- mean time to diagnosis/green.

## Required output

- interaction model;
- 8 key screens;
- animation/state semantics;
- accessibility and cognitive-load rules;
- dark-pattern/Goodhart risks;
- usability experiments;
- thin MVP that can be built before the full Command World.

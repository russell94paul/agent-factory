# R54 — Skill vs Agent vs Team vs Deterministic Tool

## Objective

Create a decision rule that chooses the **least complex remedy** for a recurring capability gap.

## Candidate remedies

```text
fix data/source
fix deterministic code
add guard/eval
add context rule
extract deterministic meta-tool
add/update reusable skill
route to existing specialist
create new specialist agent
change team topology
increase capacity
human/process change
```

## Key question

When repeated successful agent behavior becomes stable, should it be compressed into a deterministic tool instead of permanently consuming reasoning tokens?

## Evaluate each remedy by

- success delta;
- cost delta;
- latency;
- determinism;
- testability;
- maintenance burden;
- blast radius;
- transfer across mission classes;
- security/permission surface;
- reversibility.

## Required output

- complexity ladder;
- remedy classifier;
- decision matrix;
- meta-tool extraction criteria;
- examples from connector migration, research, incident response, client intake;
- experiments proving the classifier beats "add another agent".

# R50 — Surge Composition and Dynamic Resource Allocation

## Objective

Research a safe "Swarm / Surge" capability that assembles the best temporary mission team from organizational capacity under urgency, permissions, and opportunity-cost constraints.

## Important reframing

This is **constrained scheduling / resource allocation**, not uncontrolled swarm spawning.

## Inputs

```text
mission class
urgency / SLA / deadline
required capabilities
candidate agents and capability readiness
current assignments
preemption cost
switching/context cost
agent concurrency limits
model/tool quotas
environment availability
permissions/client isolation
verifier capacity
human approval capacity
budget
```

## Outputs

```text
recommended temporary composition
why each member is needed
expected gain vs best-idle baseline
which current work is delayed/preempted
cost and risk
communication topology
context packages
dissolution condition
fallback plan
```

## Research questions

- optimization/assignment methods appropriate at small and large scale;
- priority scheduling and preemption;
- multi-objective routing;
- fairness/starvation;
- team-size regularization;
- capability complementarity;
- uncertainty in success predictions;
- how to avoid always selecting the historically strongest agents and starving learning.

## Baselines

Compare against:

1. best idle agent;
2. round robin;
3. static specialist routing;
4. fixed team;
5. urgency-blind capability ranking.

## Required output

- algorithm candidates;
- scheduling schema;
- UI confirmation surface;
- simulation/replay benchmark;
- safety constraints;
- promotion gates;
- pseudocode for v1 recommendation-only scheduler.

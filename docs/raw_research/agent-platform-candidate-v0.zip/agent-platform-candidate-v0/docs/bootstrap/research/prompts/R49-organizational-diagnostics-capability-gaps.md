# R49 — Organizational Diagnostics and Capability-Gap Detection

## Objective

Design the layer that observes mission/event/outcome data and recommends **what organizational capability is missing or unhealthy**.

It must not jump directly from "performance is low" to "spawn another agent."

## Decision space

A diagnosis may recommend:

```text
fix deterministic code
improve verifier/instrumentation
add/update a skill
improve context/source data
change environment profile
change model binding
change routing
add specialist agent
change team topology
change queue/capacity
request human expertise
retire obsolete capability
no action / insufficient evidence
```

## Research analogues

- process mining;
- organizational mining;
- SRE/error-budget analysis;
- causal diagnosis;
- resource allocation;
- skills matrices/workforce planning;
- bottleneck theory;
- queueing;
- change-point detection;
- recommender/ranking systems.

## Evidence model

Recommendations must cite the mission/run/event clusters that caused them.

Example:

```yaml
proposal:
  symptom: oauth tickets miss SLA
  evidence:
    sample_size: 34
    failure_cluster: credential_rotation
    affected_mission_class: connector.oauth
  candidate_changes:
    - type: skill
      proposal: oauth-rotation-diagnosis
      expected_value: ...
    - type: environment
      proposal: credential-preflight capability
    - type: agent
      proposal: oauth specialist
  confidence_basis: ...
  experiment: ...
```

## Required output

- diagnostic architecture;
- capability graph;
- feature/event requirements;
- recommendation taxonomy;
- ranking/uncertainty approach;
- false-positive controls;
- UI workflow;
- first 10 diagnostic rules/experiments;
- thresholds for when an agent/team recommendation is justified.

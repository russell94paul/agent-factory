# External Source Leads — Verify Again at Research Time

These are starting leads from the 2026 review. They are **not canonical evidence** until a research run opens/verifies the current source/version.

1. **IMACS — Toward an Organizational Science of Multi-Agent LLM Systems**
   - arXiv:2607.25446
   - https://arxiv.org/abs/2607.25446
   - Why: decouples organization/coordination/collaboration and reports model-binding-dependent organizational winners.

2. **Anthropic — Quantifying infrastructure noise in agentic coding evals**
   - https://www.anthropic.com/engineering/infrastructure-noise
   - Why: direct evidence that runtime resources/environment can shift agentic coding success materially.

3. **Anthropic — Scaling Managed Agents: Decoupling the brain from the hands**
   - https://www.anthropic.com/engineering/managed-agents
   - Why: separates durable session, harness/brain, and sandbox/hands into replaceable interfaces.

4. **Anthropic — Harness design for long-running application development**
   - https://www.anthropic.com/engineering/harness-design-long-running-apps
   - Why: harness design affects long-horizon agent performance and should be stress-tested as models improve.

5. **Anthropic — How we built our multi-agent research system**
   - https://www.anthropic.com/engineering/multi-agent-research-system
   - Why: useful evidence for breadth-first parallel research as an early multi-agent use-case.

6. **Microsoft Research — Optimizing Agentic Workflows using Meta-tools**
   - arXiv:2601.22037
   - https://www.microsoft.com/en-us/research/publication/optimizing-agentic-workflows-using-meta-tools/
   - Why: repeated tool sequences can be mined and compiled into deterministic composite tools.

7. **Applying organizational mining to discover agent systems from event data**
   - DOI: 10.1016/j.is.2025.102669
   - Why: data-driven organizational/agent-system discovery from event logs.

8. **Automated decision-making for dynamic task assignment at scale**
   - DOI: 10.1016/j.is.2026.102694
   - Why: dynamic task/resource assignment at real-world scale; relevant to Surge Composer.

9. **Anthropic — Demystifying evals for AI agents**
   - https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents
   - Why: emphasizes outcome/final-environment state and treating model+harness as evaluated unit.

10. **Agent Army Wave 0 local synthesis**
    - `../agent-army-research/research/synthesis/W0-foundations.md`
    - Why: already contains prior-art corrections and must be treated as the starting delta, not discarded.

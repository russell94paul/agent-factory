# Context and Memory Flow

```mermaid
flowchart LR
    T[Ticket / Email] --> N[Normalize + Entity Resolve]
    D[(Docs / Code / APIs / Apps / Data)] --> E[Evidence Refinery]
    E --> G[(Permissioned Evidence / Knowledge Graph)]
    N --> Q[Knowledge Needs]
    Q --> G
    G --> CP[Context Compiler]
    CP --> U{Critical unknowns?}
    U -->|yes| B[Briefing Room / Human Answers]
    B --> CP
    U -->|no| MP[Mission ContextPack]
    MP --> A[Agent / Team Execution]
    A --> WD[Agent Digests]
    A --> WE[Mission Working Memory]
    WD --> MC[Mission Memory Curator]
    WE --> MC
    V[Verifier / Outcome] --> MC
    MC --> WG{Write Gate}
    WG -->|promote| G
    WG -->|reject/archive| AR[Episode Archive]
```

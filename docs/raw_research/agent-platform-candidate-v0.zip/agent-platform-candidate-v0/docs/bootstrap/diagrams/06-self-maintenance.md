# Self-Maintenance Recursive Loop

```mermaid
flowchart LR
    O[Observe Factory] --> D[Diagnose]
    D --> T[Internal Maintenance Ticket]
    T --> C[Mission / Context Compiler]
    C --> W[Maintenance Worker / Team]
    W --> S[Isolated Environment]
    S --> V[Independent Verifier]
    V --> G{Risk / Promotion Gate}
    G -->|reject| R[Rollback / Revise]
    G -->|canary| CA[Canary]
    CA --> M[Measure]
    M -->|good| P[Promote]
    M -->|bad| R
    P --> K[Knowledge / Capability Update]
    K --> O
```

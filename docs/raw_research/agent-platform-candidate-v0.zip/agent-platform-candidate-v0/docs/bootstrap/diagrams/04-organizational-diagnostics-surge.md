# Organizational Diagnostics and Surge Composition

```mermaid
flowchart TB
    R[(Run / Eval / Queue / Environment Events)] --> F[Feature + Mission-Class Projections]
    F --> D[Capability Diagnostician]
    D --> Q{What is weak?}
    Q --> M[Measurement / Verifier]
    Q --> C[Context / Data]
    Q --> SK[Skill / Meta-tool]
    Q --> EN[Environment / Tool]
    Q --> RO[Routing / Capacity]
    Q --> AG[Specialist Agent]
    Q --> TM[Team Topology]
    M & C & SK & EN & RO & AG & TM --> P[Evidence-linked Proposal]
    P --> H{Human accepts experiment?}
    H -->|no| A[Reject / Defer]
    H -->|yes| S[Replay / Shadow Test]
    S --> EV[External Evaluation]
    EV --> PR{Promotion threshold?}
    PR -->|yes| REG[Registry / Configuration Update]
    PR -->|no| A

    URG[Urgent Mission] --> SC[Surge Composer]
    REG --> SC
    CAP[(Readiness + Workload + Preemption Cost)] --> SC
    SC --> REC[Temporary Team Recommendation]
```

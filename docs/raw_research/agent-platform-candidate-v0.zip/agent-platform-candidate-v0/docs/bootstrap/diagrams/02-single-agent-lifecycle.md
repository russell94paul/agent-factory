# Single-Agent Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> Evaluating: config complete
    Evaluating --> Certified: verifier + corpus pass
    Evaluating --> Draft: failed / revise
    Certified --> Active: promoted
    Active --> Degraded: outcome drift / dependency change
    Active --> RecertificationRequired: load-bearing binding changed
    Degraded --> RecertificationRequired
    RecertificationRequired --> Evaluating
    Active --> Canary: candidate version
    Canary --> Active: candidate passes promotion threshold
    Canary --> RolledBack: regression / risk
    RolledBack --> Active: previous binding restored
    Active --> Retired: superseded / no demand
    Retired --> [*]
```

The lifecycle belongs to a **binding**, not just an agent name.

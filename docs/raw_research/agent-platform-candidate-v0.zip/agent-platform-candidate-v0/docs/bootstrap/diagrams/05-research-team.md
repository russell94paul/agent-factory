# Research Team

```mermaid
flowchart TB
    Q[Research Question] --> O[Research Orchestrator]
    O --> A[Academic / Prior-Art Scout]
    O --> B[Implementation / Repo Scout]
    O --> C[Contemporary Systems Scout]
    O --> D[Adversarial Scout]
    A & B & C & D --> SL[(Source + Claim Ledger)]
    SL --> SV[Source Verifier]
    SV --> EA[Evidence Auditor]
    EA --> RS[Research Synthesizer]
    RS --> ED[Experiment Designer]
    ED --> H{Human Decision}
    H -->|accept mechanism| SA[Systems Architect / Handoff]
    H -->|needs evidence| O
    H -->|reject| X[Preserve negative result]
```

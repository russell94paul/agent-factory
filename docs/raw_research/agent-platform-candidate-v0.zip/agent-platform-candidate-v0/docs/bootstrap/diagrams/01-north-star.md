# North-Star Architecture

```mermaid
flowchart TB
    I[Email / Ticket / Mission Request] --> C[Mission & Context Compiler]
    K[(Evidence / Knowledge / Client Artifacts)] --> C
    C --> M[Mission + Mandate + ContextPack]
    M --> P[Organization Planner]
    A[(Agent / Skill / Capability Registry)] --> P
    E[(Environment Registry)] --> P
    P --> R[Agent Runtime]
    R --> X[Execution Environment / Tools / Repos / APIs]
    R --> L[(Durable Event + Run Ledger)]
    X --> V[Independent Verifier]
    V --> EV[Evaluation Record]
    EV --> H[Capability / Health Projection]
    L --> H
    H --> D[Organizational Diagnostician]
    D --> O[Organizational Proposals]
    O --> S[Surge / Team Composer]
    O --> OPT[Offline Optimization Lab]
    OPT --> CR[Candidate Registry]
    CR --> G{Promotion Gate}
    G -->|accepted| A
    L --> MC[Memory Curator]
    EV --> MC
    MC --> K
    D --> FM[Internal Factory Maintenance Mission]
    FM --> C
```

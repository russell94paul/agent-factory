# Agent Platform Bootstrap v1

A repository bootstrap and execution pack for evolving the current **Agent Factory** into a measured platform for building, operating, maintaining, composing, diagnosing, and optimizing agents and agent teams.

This pack is intentionally **not** a wholesale rewrite. It is a migration and research workspace built around the evidence already present in:

- `russell94paul/agent-factory`
- `russell94paul/agent-army-research`

## North-star

```text
Agent Factory builds agents
        ↓
Agent Factory measures and maintains agents
        ↓
Agent Factory composes measured agents into teams
        ↓
The platform diagnoses organizational capability gaps
        ↓
It recommends skills / agents / team changes
        ↓
It can form a temporary mission team from available capability
        ↓
Offline replay + optimization evaluates alternatives
        ↓
Validated improvements are promoted with explicit gates
        ↓
The same machinery can maintain Agent Factory itself
```

## The hard sequencing rule

**Do not start with an army. Start with one agent whose lifecycle is measurable.**

The first production objective is one agent that can be:

1. defined;
2. versioned;
3. provisioned into a versioned environment;
4. given a sourced context pack;
5. run against a mission;
6. externally verified;
7. observed and replayed;
8. health-scored / recertified;
9. given reusable skills;
10. improved without silently inheriting old certification.

Only after this works should team composition become a product primitive.

## Recommended repository decision

**For now keep `agent-factory` and `agent-army-research` as sibling source-of-truth repositories.**

Use this bootstrap as the reconciliation / migration workspace. Do not physically merge the two source repos until the `repo-boundary` research gate is accepted.

Why:

- production and research currently have different truth semantics;
- the research repository explicitly requires evidence → synthesis → decision → handoff before product implementation;
- Agent Factory already contains useful tested primitives that should be migrated, not rewritten;
- a monorepo is attractive later when shared runtime/contracts/UI packages are real rather than hypothetical.

### Candidate future monorepo

```text
agent-platform/
├── apps/
│   ├── factory-control/
│   ├── mission-console/
│   └── briefing-room/
├── packages/
│   ├── agent-kernel/
│   ├── missions/
│   ├── contracts/
│   ├── context/
│   ├── environments/
│   ├── capabilities/
│   ├── events/
│   ├── evals/
│   └── optimization/
├── services/
│   ├── evaluator/
│   ├── scheduler/
│   ├── knowledge/
│   └── organizational-diagnostics/
├── skills/
├── evals/
├── environments/
├── research/
│   └── agent-army/
└── infra/
```

## Start here

1. Read `docs/00-FEASIBILITY.md`.
2. Read `docs/01-SEQUENCING.md`.
3. Run the prompt `prompts/00-RECONCILE-CURRENT-REPOS.md` in Claude Code with both repositories available as sibling folders.
4. Run research in `research/RUN_ORDER.md`.
5. Install the skills with `scripts/install_skills.sh <target-repo>`.
6. Build **Phase 1: Single-Agent Kernel** before creating any optimizer or autonomous team-formation path.

## Main design objects

```text
AgentSpec             configuration identity
EnvironmentProfile    execution/harness identity
Mission               work intent + inputs + verification target
Mandate               permissions / authority / budget boundary
ContextPack           sourced task-specific context
Skill                 versioned reusable procedure
Capability            evidence-backed ability in a defined scope
AgentRun               one bound execution of agent × environment × mission
Evaluation             independent verdicts + metrics
CapabilitySnapshot     current evidence-backed readiness
TeamTemplate           composition of certified capabilities
OrganizationProposal   suggested team/skill/resource change
Experiment             baseline vs candidate on a versioned corpus
```

## Key rule: certification belongs to a binding

Never certify only `agent-x`.

Treat the evaluated unit as approximately:

```text
(agent_version,
 model_binding,
 skill_set_version,
 environment_version,
 context_policy_version,
 tool_policy_version,
 verifier_version,
 mission_class)
```

A change to any load-bearing component requires explicit transfer rules or re-evaluation.

## What this pack adds beyond the current repositories

- single-agent-first lifecycle and health model;
- versioned **Execution Environment Profiles** as an optimization dimension;
- organizational diagnostics from event/outcome data;
- capability-gap → new skill/agent/team-member recommendations;
- temporary **surge composition** with urgency/capacity constraints;
- self-maintenance control loop for Agent Factory;
- delta research prompts after the completed W0 foundation work;
- Claude Skills for research, implementation, evaluation, context, diagnostics, optimization, and maintenance;
- a thin early operator UI plan that earns its place through observability rather than animation.

## What this pack refuses to do

- auto-evolve live production organizations;
- let an agent edit its own authoritative grader;
- let team activity substitute for verified outcome;
- broadcast every agent thought to every other agent;
- merge raw observations, claims, evidence, and durable knowledge into one memory type;
- create multi-agent complexity before a single-agent baseline exists;
- build a game skin before the underlying metrics and events are real.

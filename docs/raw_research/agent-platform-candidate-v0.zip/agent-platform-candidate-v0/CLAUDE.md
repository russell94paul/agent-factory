# Candidate Agent Platform — Claude Entry Point

This repository is a **migration candidate**, not production truth.

Read first:

1. `docs/bootstrap/CLAUDE.md`
2. `docs/bootstrap/README.md`
3. `docs/bootstrap/prompts/00-RECONCILE-CURRENT-REPOS.md`

Expected sibling source repositories:

```text
../agent-factory
../agent-army-research
```

Do not copy/move production source until the reconciliation prompt has produced a file-level migration decision accepted by a human.

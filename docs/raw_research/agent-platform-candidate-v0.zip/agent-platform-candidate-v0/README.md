# Agent Platform Candidate

This is a **candidate future monorepo skeleton**, not permission to migrate production code.

Start by copying the bootstrap pack into `docs/bootstrap/` or keep it adjacent, then run the repository reconciliation prompt against the existing sibling repositories.

Do not move production code until a file-level migration decision and rollback path exist.

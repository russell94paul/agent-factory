# Switchboard Redesign Requirements

## Product Objective
Transform Switchboard Console from a transcript-first multi-terminal interface into a premium, keyboard-first operations and communication workspace for supervising concurrent AI sessions.

## Non-Negotiable UX Principles

1. **Human attention is the scarce resource.** The UI must surface exceptions, decisions, blockers, and approvals before raw execution detail.
2. **Conversation is not a log.** Human instructions and agent communication must be readable and visually distinct from tool output.
3. **Raw technical detail remains available.** Do not remove terminal/log access; demote it to an inspectable layer.
4. **Context stays visible.** Mission, repo, branch, environment, files, tests, artifacts, permissions, and dependencies should not require transcript archaeology.
5. **Scale changes the representation.** One session can be conversational; ten sessions should be summarized; a fleet should be aggregated statistically.
6. **Repeated supervision should become automation.** Any common repeated action should be promotable to a playbook, rule, or scheduled routine.
7. **Keyboard-first, mouse-complete.** Expert users must be able to operate the application rapidly with commands and shortcuts while all key actions remain discoverable.
8. **Risk-aware actions.** Production changes, destructive actions, and important approvals need explicit, auditable interaction patterns.
9. **Status language is operator-facing.** Implementation labels belong in Diagnostics; primary UI states should be simple and meaningful.
10. **Motion communicates state.** Animation should show transition, completion, focus, or live activity—not decorate the screen.

## Required Core Components

### 1. Application Shell
- Persistent primary navigation.
- Global search/command palette.
- Active session count.
- Inbox / approval counts.
- Create session / mission action.
- Responsive workspace area.

### 2. Session Dock
- Active and recent sessions.
- State, mission, current activity, elapsed duration.
- Unread count.
- Human-attention indicator.
- Hover / quick actions.
- Search and filters.

### 3. Conversation Surface
- Structured event rendering.
- Collapsible tool events.
- Artifact cards.
- Approval and blocker objects.
- Agent/human authorship.
- Timestamp and state changes.
- Optional raw-log toggle.

### 4. Mission Composer
- Recipient selector.
- Rich text instruction entry.
- @session / @artifact / @file references.
- Slash commands.
- Attachments.
- Voice input.
- Dispatch preview for multi-recipient/voice commands.
- Send / schedule / save as playbook.

### 5. Context Inspector
- Mission objective.
- Repository / branch / environment.
- Modified files / commits.
- Tests.
- Artifacts and evidence.
- Dependencies.
- Permissions and risk.
- Cost/context/usage where appropriate.

### 6. Action Inbox
- Needs You.
- Blocked.
- Approvals.
- Failed automation.
- Completed / informational.
- Snooze / resolve / assign / open.

### 7. Layout Templates
- Focus.
- Compare.
- Monitor Wall.
- War Room.
- Automation Studio.
- Review / Replay.
- Save custom layout.

### 8. Automation Center
- Rules.
- Playbooks.
- Scheduled routines.
- Execution history.
- Retry.
- Disable / enable.
- Natural-language creation.
- Audit log.

### 9. Approval Center
- Requested action.
- Target environment/system.
- Risk level.
- Tests / evidence.
- Agent/session origin.
- Approve / reject / request changes.
- Audit record.

### 10. Timeline / Replay
- Mission lifecycle events.
- Human instructions.
- Agent decisions.
- Tool runs.
- State changes.
- Artifacts.
- Approvals.
- Costs.
- Final outcome.

## Interaction Requirements

- `Ctrl/Cmd + K`: global command palette.
- Fast switcher for sessions.
- Open any session in Focus mode with one action.
- Send one message to multiple recipients without copying text.
- Convert a successful command/instruction into a reusable playbook.
- Create an automation from a completed event or blocker.
- Right-click / overflow actions remain secondary to discoverable primary actions.
- Unsaved composer content must survive layout switching.
- Session state must be visually stable; no jumpy reflow when live events arrive.

## Visual Requirements

- Neutral near-black background; avoid green-tinted black as the only identity.
- Sans-serif UI/conversation typography.
- Monospace reserved for code, IDs, paths, commits, and logs.
- Semantic status colors.
- Fewer visible borders; use spacing and surface hierarchy.
- Consistent 4/8px spacing system.
- Strong focus states and keyboard navigation.
- Minimal motion with clear purpose.
- Dense but legible information presentation.

## Accessibility Requirements

- Full keyboard navigation.
- Visible focus rings.
- Status must never depend on color alone.
- Voice features must always have text equivalents.
- Transcripts and speech must be editable before dispatch when used for commands.
- Avoid flashing/pulsing effects as primary status indication.
- Sufficient contrast for text and interactive controls.

## Operational Requirements

- Live updates must not obscure or reset the operator's reading position.
- The interface must distinguish connected, running, waiting, blocked, needs-human, completed, failed, and disconnected states.
- Every automated action should have an execution record.
- Every privileged approval should be auditable.
- Raw transcript and execution evidence must remain retrievable.
- The system should support additional future communication targets beyond a local Claude session.

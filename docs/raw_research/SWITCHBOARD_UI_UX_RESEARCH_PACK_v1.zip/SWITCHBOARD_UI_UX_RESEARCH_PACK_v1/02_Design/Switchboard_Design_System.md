# Switchboard Design System Direction

## Brand Character

**Premium, precise, calm, operational, technically credible.**

The visual system should feel powerful without looking theatrical. The product is handling live agentic work, so restraint communicates trust.

## Color Roles

Do not hard-code this document as a final palette. Treat it as semantic guidance for design exploration.

- **Canvas:** near-black neutral.
- **Raised surfaces:** charcoal steps.
- **Primary text:** warm or neutral off-white.
- **Secondary text:** muted gray.
- **Interaction accent:** cool blue / cyan family.
- **Success:** green only when success/healthy state is intended.
- **Warning:** amber.
- **Failure:** red.
- **Running / live:** blue/cyan.
- **Waiting / idle:** slate.

### Rule
Color should answer a question, not decorate a region.

## Typography

### UI / Conversation
Use a high-legibility modern sans-serif for:
- navigation;
- labels;
- human messages;
- agent prose;
- buttons;
- summaries.

### Technical Mono
Use monospace for:
- code;
- shell commands;
- paths;
- hashes;
- IDs;
- logs;
- structured technical values.

### Optional Display Face
Use sparingly for high-level workspace titles or editorial moments. Never use a display face throughout the control surface.

## Spacing

Use a consistent spacing scale based around 4px or 8px increments.

- Tight metadata: 4-8px.
- Related controls: 8-12px.
- Component separation: 16px.
- Region separation: 24-32px.

Favor whitespace and alignment over visible boxes.

## Borders and Surfaces

Current UI issue: too many nested outlined rectangles.

New rule:
- Outer workspace regions can use subtle separators.
- Inner content groups rely on spacing and background elevation.
- Strong borders are reserved for focus, selected state, approval, warning, or modal boundaries.

## Status Components

Every status object contains:
- simple state word;
- optional icon/dot;
- age/duration where relevant;
- secondary machine detail on hover or expansion.

Examples:
- RUNNING · 14m
- NEEDS YOU · now
- WAITING · 8m
- BLOCKED · 42m
- COMPLETE · 6m ago
- FAILED · 2m ago

Never rely on color alone.

## Motion

Use motion for:
- new event arrival;
- state transitions;
- pane opening/closing;
- switching layouts;
- progress change;
- confirmation of a dispatched command;
- highlighting a newly raised blocker.

Avoid:
- constantly pulsing borders;
- decorative particles;
- gratuitous glow;
- animations that compete with live logs.

## Hover Behavior

Hover should reveal secondary detail without becoming the only access path to important actions.

Examples:
- Session row hover: branch, repo, last event, quick actions.
- Artifact hover: source, generated time, related mission, open/compare.
- Status hover: raw state, PID, runtime details.
- Automation hover: last run, next run, success rate, pause.

## Cards

Do not make the app “card-first.” Cards are useful for:
- artifacts;
- approvals;
- blockers;
- Monitor Wall summaries;
- automation runs.

Conversation and primary workflow should remain spatially continuous.

## Density Modes

- **Comfortable:** onboarding and wide screens.
- **Compact:** expert daily use.
- **Ultra-compact / Fleet:** high-scale monitoring.

Density should primarily change padding and metadata visibility, not text readability.

## Iconography

Use icons to support recognition, not replace labels for unfamiliar actions. Reuse the same icon for the same semantic action everywhere.

## Accessibility

- Visible focus states.
- Full keyboard support.
- Adequate contrast.
- Reduced-motion support.
- Text equivalent for speech and status.
- Icons paired with text or accessible labels.
- No color-only state communication.

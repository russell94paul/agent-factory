# Switchboard Layout Templates

## Purpose
A layout template is not only a grid arrangement. It is a **task model** that determines which information is prominent, which controls are available, and how much execution detail is summarized.

## 1. Focus

**Use when:** actively directing one session or mission.  
**Primary question:** “What is this session doing, and what should I tell it next?”

```text
15% Session Dock | 60% Conversation / Composer | 25% Context Inspector
```

Persistent components:
- Session header.
- State and elapsed time.
- Structured conversation.
- Mission Composer.
- Context Inspector.

Optional lower drawers:
- Terminal.
- Diff.
- Tests.

## 2. Compare

**Use when:** two agents are working on related tasks, reviewing each other, or producing competing answers.  
**Primary question:** “How do these two executions differ?”

```text
+-------------------------+-------------------------+
| Session A               | Session B               |
| structured conversation | structured conversation |
+-------------------------+-------------------------+
| Shared Composer / Comparison actions              |
+---------------------------------------------------+
```

Actions:
- Ask both.
- Ask A to review B.
- Ask B to review A.
- Compare conclusions.
- Show file overlap.
- Show conflicting claims.
- Transfer artifact/context.

## 3. Monitor Wall

**Use when:** supervising approximately 5-15 concurrent sessions.  
**Primary question:** “Which work is healthy, stalled, completed, or needs me?”

Card content:
- Session / mission.
- State.
- Current activity.
- Age.
- Last meaningful event.
- Cost / token / context indicator where useful.
- Human attention flag.
- Risk/environment.

Do not show full transcripts until the user opens a card.

## 4. War Room

**Use when:** incident response, production issue, high-risk mission, or coordinated multi-agent investigation.  
**Primary question:** “What is happening, what do we believe, and what must happen next?”

Regions:
- Mission / incident header.
- Shared timeline.
- Active agents and assignments.
- Blockers.
- Hypotheses / disputed findings.
- Evidence and artifacts.
- Current decision / approval.
- Broadcast composer.

## 5. Automation Studio

**Use when:** building, testing, reviewing, or debugging rules and playbooks.  
**Primary question:** “What triggers this automation, what can it do, and what happened when it ran?”

Recommended modes:
- Natural language.
- Visual rule view.
- Structured YAML/JSON advanced view.
- Simulation / test events.
- Execution history.

## 6. Review / Replay

**Use when:** mission is finished or failed and needs audit, postmortem, learning, or evidence review.  
**Primary question:** “Why did this outcome happen?”

Timeline filters:
- Human instructions.
- Agent messages.
- Tool calls.
- Code changes.
- Artifacts.
- State transitions.
- Approvals.
- Costs.
- Errors.

## 7. Fleet View — Future

**Use when:** overseeing dozens or hundreds of concurrent executions.  
**Primary question:** “Where is the organization healthy or degraded?”

Aggregate by:
- Cell / team.
- Mission type.
- Status.
- Environment.
- Risk.
- Cost.
- SLA / age.
- Human-attention demand.

Fleet View must drill down into Monitor, then Focus; it should not attempt to show dozens of conversations at once.

## Template Behavior Rules

- Layout switching must never discard composer drafts.
- The selected session/mission should persist where applicable.
- Each template should have a default and user-saveable variant.
- Pane widths should be resizable within sensible limits.
- Avoid unconstrained graph-editor behavior for ordinary users.
- New users should choose task language (“Focus”, “Monitor”, “Compare”), not layout jargon (“2-up”, “3-pane”).

# Claude / Design-Agent Master Prompt — Switchboard UI/UX Redesign

## Role
You are a principal product designer, human-computer interaction researcher, design systems architect, and agentic-product innovator. You are redesigning **Switchboard**, a live multi-session control surface used to supervise, communicate with, coordinate, and automate AI coding/agent sessions.

## Source of Truth
Use the following artifacts in this pack before proposing a design:

1. `00_Baseline/Switchboard_Console_Current_UI.png`
2. `01_Research/Switchboard_UI_UX_Deep_Research_Report.md`
3. `02_Design/Switchboard_Redesign_Requirements.md`
4. `02_Design/Switchboard_Layout_Templates.md`
5. `02_Design/Switchboard_Design_System.md`
6. `03_Product/Switchboard_Feature_Backlog.md`
7. `05_Automation/Switchboard_Automation_Concepts.md`

Do not merely reskin the existing terminal panes. The fundamental problem is that the current interface treats the transcript as the product. The redesigned product must be **attention-first, communication-first, and automation-ready**.

## North-Star Principle

> Switchboard should minimize the amount of agent work the operator has to watch.

The progression is:

```text
OBSERVE -> COMMUNICATE -> COORDINATE -> AUTOMATE -> DELEGATE
```

## Required Design Outcomes

Design a cohesive product system that includes at minimum:

- premium application shell;
- Session Dock;
- Action Inbox;
- Mission Composer;
- structured session event renderer;
- Context Inspector;
- Focus layout;
- Compare layout;
- Monitor Wall;
- War Room concept;
- Automation Studio;
- Approval Center;
- Mission Timeline / Replay;
- command palette;
- voice / push-to-command concept;
- responsive behavior;
- dense expert mode;
- keyboard navigation strategy.

## Product Constraints

- Preserve fast access to raw terminal/log output.
- Do not force raw terminal output to remain the default communication surface.
- Multi-session supervision must remain useful at 1, 2, 10, and eventually many more sessions.
- Status must not depend on color alone.
- Voice must always generate inspectable text before high-impact dispatch.
- Automation must be auditable and policy-aware.
- Avoid decorative cyberpunk excess.
- Avoid generic SaaS card soup.
- Favor calm, precise, premium visual hierarchy.

## Aesthetic Direction

Target an **Industrial Editorial Command Center**:

- neutral near-black / charcoal foundation;
- premium spacing and typography;
- clean sans-serif for conversation/UI;
- monospace only for technical content;
- restrained cool interaction accent;
- semantic status colors;
- minimal purposeful motion;
- subtle surfaces instead of many nested borders;
- dense, high-information layouts that remain readable.

## Research Expectations

Before final design recommendations:

1. Audit the current screenshot.
2. Identify concrete hierarchy, density, navigation, conversation, attention, and scalability problems.
3. Compare relevant interaction patterns from modern developer tools, operations systems, collaboration products, and automation products.
4. Do not copy a competitor wholesale; extract principles and explain why they are appropriate.
5. Explicitly challenge any recommendation that adds visual complexity without reducing operator effort.

## Required Deliverables

### A. Current-State Audit
- Major UX problems.
- What should be preserved.
- Severity and user impact.

### B. Information Architecture
Provide the recommended global nav and session-level nav.

### C. Layout System
For Focus, Compare, Monitor Wall, War Room, Automation Studio, Review/Replay:
- purpose;
- regions;
- component hierarchy;
- ideal information density;
- transitions to other layouts.

### D. Component Specification
For each important component provide:
- name;
- purpose;
- default state;
- hover state;
- selected state;
- loading/live state;
- warning/error state;
- keyboard behavior;
- information displayed;
- actions;
- motion behavior.

Prioritize:
- Session row/card;
- Mission header;
- Mission Composer;
- Event block;
- Tool invocation;
- Artifact card;
- Blocker;
- Approval request;
- Context Inspector section;
- Automation rule;
- Playbook;
- Inbox item.

### E. Voice UX
Design push-to-command with:
- recording state;
- transcription;
- recipient extraction;
- command preview;
- ambiguity handling;
- dispatch confirmation;
- spoken alert preferences.

### F. Automation UX
Design:
- natural-language automation creation;
- visual/structured rule representation;
- playbook creation;
- schedule view;
- execution history;
- retry;
- pause/disable;
- simulation;
- approval gates.

### G. Visual Design Tokens
Recommend semantic tokens for:
- surfaces;
- text;
- borders;
- interaction accent;
- status;
- typography;
- spacing;
- radius;
- elevation;
- motion.

Do not over-focus on exact hex codes before validating hierarchy and component behavior.

### H. Prototype Plan
Produce a phased prototype plan:

**Prototype 1:** Focus + Session Dock + Composer + Context Inspector.  
**Prototype 2:** Inbox + structured events + command palette.  
**Prototype 3:** Monitor + Compare.  
**Prototype 4:** Automations + approvals.  
**Prototype 5:** War Room + Replay + voice.

For each prototype, define the usability question being tested.

### I. Innovation Pass
Propose at least 10 additional high-leverage ideas, especially in:
- productivity;
- multi-agent communication;
- automation;
- attention management;
- context transfer;
- keyboard/voice interaction;
- human approvals;
- audit/replay;
- progressive autonomy.

Score each by:
- user value;
- implementation complexity;
- differentiation;
- operational risk.

## Final Evaluation Test

Before presenting a concept, ask:

> Does this design help the operator understand what needs attention and act with fewer context switches than the current Console?

If not, simplify or remove it.

# Switchboard Console UI/UX Deep Research & Redesign Report

**Version:** v1.0  
**Date:** 2026-09-02  
**Scope:** Current `/Console` experience, multi-session communication, productivity, automation, layout systems, session monitoring, and the future agentic-control experience for Switchboard.

## Executive Summary

The current Switchboard Console is functional and has a distinct technical character, but it behaves more like a web-based terminal multiplexer than a purpose-built control surface for coordinating AI work. The transcript is doing too much: system status, agent reasoning, commands, human instructions, Git state, errors, artifacts, and approvals all compete inside nearly identical dark panes.

The redesign should not be a prettier terminal. It should become the **live operations and communications cockpit for Switchboard**: a place where an operator can communicate with sessions, understand mission state, intervene only when required, automate repeated supervision, inspect evidence, and move fluidly between one session, a mission team, and a fleet of concurrent agentic work.

The core design thesis is:

> **Switchboard should minimize the amount of agent work the operator has to watch.**

A weak multi-agent UI lets the operator open ten terminals. A better one summarizes ten agents. A strong one tells the operator: **seven are fine, two finished, one needs you**. The mature product then allows that recurring intervention to be turned into an automation.

## 1. Baseline Assessment

### What is worth preserving

- A serious, technical operations identity.
- Dark surfaces and compact information density.
- Keyboard-first control.
- Visible repository, branch, process, and environment context.
- Fast access to raw technical output when required.
- Multi-pane workflows for comparison and parallel work.

### What is currently holding the experience back

1. **The transcript has become the primary product surface.** Human communication, machine output, status events, and system metadata are visually flattened into the same stream.
2. **Weak visual hierarchy.** Borders and panes are plentiful, but there is limited semantic separation between “important for me now” and “background execution detail.”
3. **Chat is too terminal-like.** The small “reply to this session” box undersells the product’s ability to direct, coordinate, schedule, broadcast, and govern AI work.
4. **Multi-session UX does not scale.** Side-by-side terminals can work for two sessions but become progressively less useful at 5, 10, or 50 sessions.
5. **There is no strong “needs me” layer.** Operators are forced to inspect sessions rather than being shown decisions, blockers, approvals, and unresolved questions.
6. **Automation is not a first-class interaction.** Repeated supervisory actions should become reusable rules, playbooks, scheduled routines, or event-triggered handoffs.
7. **Navigation is implementation-oriented.** Labels such as Console, Worktrees, Diagnostics, and System Health are useful, but the primary information architecture should organize around what the operator is trying to accomplish.
8. **Context is not persistent enough beside the conversation.** Repository, branch, mission objective, environment, changed files, tests, cost, permissions, and dependencies should be visible without scrolling the transcript.

## 2. Recommended Product Model

### Current mental model

```text
SESSION
   |
   v
TERMINAL TRANSCRIPT
   |
   +-- agent text
   +-- command output
   +-- human messages
   +-- status events
```

### Recommended mental model

```text
                         SWITCHBOARD

          +--------------------------------------+
          |          LIVE WORKSPACE              |
          +--------------------------------------+
                            |
       +--------------------+-----------------------+
       |                    |                       |
       v                    v                       v
 Communication         Operations              Automation
       |                    |                       |
 conversation           sessions                triggers
 instructions           status                  schedules
 voice                   blockers                playbooks
 broadcasts              artifacts               policies
       |                    |                       |
       +--------------------+-----------------------+
                            v
                     Mission Timeline
                            |
                            v
                       Evidence / Replay
```

Switchboard becomes an **agentic workbench**, not a terminal viewer.

## 3. Design Direction: Industrial Editorial Command Center

The current dark technical identity should be retained, but refined. The target aesthetic should feel like a premium operations product rather than a retro terminal skin.

Recommended reference blend:

- Linear: speed, density, navigation discipline, command-driven interaction.
- VS Code: flexible panes, technical context, keyboard control.
- Mission-control software: status awareness, escalation, operational confidence.
- Modern collaboration tools: channels, threads, presence, rich compositional input.

Avoid:

- Neon cyberpunk everywhere.
- Generic SaaS card grids.
- Green monospace as the default typography for ordinary conversation.
- Excessive nested rectangles.
- A dashboard that looks impressive but makes actions harder to find.

### Typography system

Use a clean sans-serif for normal UI and human/agent conversation. Reserve monospace for:

- shell commands;
- repository paths;
- commit hashes;
- identifiers;
- structured logs;
- code.

This simple distinction makes conversation feel human-readable while preserving technical precision.

## 4. Mission Composer: Replace the Reply Box

The bottom input should become a rich **Mission Composer** rather than a terminal reply field.

```text
+---------------------------------------------------------------------------+
| To: GP-329                                     Context: Marketing Model v  |
|                                                                           |
| Ask GP-329 to verify the campaign spend calculation, compare it with      |
| the warehouse result, and report any disagreement.                        |
|                                                                           |
| + Attach      @ Session     / Command      Voice      Actions              |
|                                                                           |
| Mode: Instruction v       Approval: normal        [ Send -> ]             |
+---------------------------------------------------------------------------+
```

### Recipient model

The “To:” field should support:

- This session.
- A named session.
- Selected sessions.
- Mission team.
- Everyone working an incident.
- Team manager.
- New session.

This is important because it turns the interface from one-to-one chat into a **communication topology** for agentic work.

## 5. Communication Channels

Sessions should not be the only unit of conversation. Support four scopes:

| Channel | Purpose |
|---|---|
| Direct | Operator to one session or agent |
| Mission | Everyone associated with one ticket or mission |
| Team | Persistent team communication |
| Broadcast | Instruction or event sent to selected sessions |

Example:

```text
# GP-329                 direct session
# Marketing Model        mission channel
# Semantic Model Team    team channel
# Incident-2026-09-02    temporary war room
```

## 6. Voice as an Operations Feature

Voice should not simply imitate a consumer voice assistant. It becomes useful when it reduces supervisory friction.

### Push-to-command

The operator holds a microphone button or keyboard shortcut and says:

> Tell GP-329 to finish the validation but do not deploy anything. Ask Bash to inspect its branch at the same time.

Switchboard produces a preview:

```text
RECIPIENTS
GP-329
Bash

INSTRUCTION
GP-329:
Finish validation. Do not deploy.

Bash:
Inspect GP-329's current branch concurrently.

[Cancel]                         [Dispatch]
```

### Selective spoken alerts

Do not make every response audible. Let the operator configure speech for events such as:

- agent requires operator input;
- approval required;
- mission completed;
- critical failure;
- specific mission or session priorities.

Example spoken brief:

> “GP-329 is blocked. It found a warehouse discrepancy and needs approval before modifying the model.”

## 7. Structured Session Events

Stop treating every session event as undifferentiated transcript text. Render event types differently.

### Human instruction
Readable normal text with clear authorship and timestamp.

### Agent response
Readable prose, optionally with expandable reasoning summary or sub-events.

### Tool invocation

```text
> Bash                        2.8s
  git status
```

### Result

```text
✓ Command completed
  2 files modified
```

### Git operation

```text
Branch updated
feature/gp329-adspend-cost-section

+2 commits
```

### Artifact

```text
+----------------------------+
| Validation Report          |
| generated 12:46            |
|                            |
| Open   Compare   Pin       |
+----------------------------+
```

### Blocker

```text
! NEEDS YOU

Warehouse result conflicts with model result.

[Review evidence] [Respond]
```

### Approval

```text
PRODUCTION CHANGE REQUEST

Target: Marketing Model
Risk: medium
Tests: 14/14

[Reject]                     [Approve]
```

Raw logs remain available under **View raw log** rather than dominating the main experience.

## 8. Action Inbox

The Action Inbox is one of the highest-leverage features in the redesign. Its purpose is to answer:

> **Where does the operator need to intervene?**

```text
INBOX                                      8

NEEDS YOU                                  3

● GP-329 requests deploy approval        now
● Bash found conflicting commits          2m
● Research Agent asks scope question      8m

BLOCKED                                    2

○ ETL-112 awaiting credentials           19m
○ UI-019 awaiting GP-329                  31m

COMPLETED                                  3

✓ SALES-014 verified                       6m
✓ SALES-021 PR opened                     17m
✓ Docs research completed                 28m
```

### Useful capabilities

- Group by urgency, mission, team, environment, or event type.
- Snooze non-urgent items.
- Resolve directly from the inbox.
- Batch approve low-risk actions when policy permits.
- Pin important missions.
- Keyboard shortcuts for next/previous unresolved item.
- Notification routing preferences.

## 9. Layout Template System

Do not make operators recreate their workspace manually every time. Provide task-oriented layout templates and allow personal variants to be saved.

### Layout 1 — Focus

Default layout for one active mission.

```text
+--------+--------------------------------------+----------------+
|        | GP-329                               | CONTEXT        |
|        | Running · 14m · Marketing Model      |                |
| SESS.  +--------------------------------------+ Mission        |
|        |                                      | Branch         |
| ●329   |                                      | Files          |
| ●Bash  |          CONVERSATION                | Evidence       |
| ○214   |                                      | Cost           |
|        |                                      | Dependencies   |
|        +--------------------------------------+                |
|        |             COMPOSER                 |                |
+--------+--------------------------------------+----------------+
```

Suggested width balance: approximately **15% / 60% / 25%**.

### Layout 2 — Compare

Two sessions or analyses side by side with a shared composer.

Capabilities:

- ask both;
- broadcast;
- compare conclusions;
- request disagreement analysis;
- merge context;
- transfer artifacts between panes.

### Layout 3 — Monitor Wall

Monitoring multiple agents should show summarized operational cards, not several full transcripts.

```text
+--------------------+--------------------+--------------------+
| GP-329             | Bash               | Research           |
| ● RUNNING          | ● RUNNING          | ◐ WAITING          |
|                    |                    |                    |
| Validating model   | Reviewing branch   | Awaiting source    |
| 14m                | 7m                 | 21m                |
| $1.82              | $0.63              | $3.42              |
| Last event: 12s    | Last event: 44s    | Last event: 8m     |
+--------------------+--------------------+--------------------+
```

Click a card to enter Focus mode.

### Layout 4 — War Room

For incidents or complex missions, organize around a shared timeline, active work, hypotheses, evidence, and blockers instead of independent session windows.

### Layout 5 — Automation Studio

A dedicated canvas for event-triggered rules, schedules, reusable playbooks, and execution history.

### Layout 6 — Review / Replay

After completion, show the mission as a scrub-able timeline with inputs, decisions, tool calls, artifacts, approvals, cost, and final outcome.

## 10. Automation as a First-Class Product Pillar

Automation should sit alongside Work, Sessions, Inbox, and Missions rather than living in settings.

Recommended automation model:

```text
WHEN
Session becomes BLOCKED
        |
        v
IF
Blocked > 10 minutes
        |
        v
DO
Ask agent for blocker summary
        |
        v
IF unresolved
        |
        v
Add to Action Inbox + optional spoken alert
```

### Natural-language automation creation

Example request:

> Every weekday at 8:30 summarize anything still running, anything blocked, PRs awaiting approval, and tasks completed overnight.

Compiled form:

```yaml
automation:
  name: morning-operations-brief

trigger:
  type: schedule
  weekdays: true
  time: "08:30"

query:
  include:
    - running_sessions
    - blocked_sessions
    - approval_requests
    - completed_since_last_brief

action:
  type: briefing

delivery:
  - switchboard_inbox
```

### Automation Center tabs

```text
AUTOMATIONS

[ Rules ] [ Playbooks ] [ Scheduled ] [ Executions ]
```

Rules are event/condition/action policies. Playbooks are reusable procedures. Scheduled contains recurring routines. Executions provides history, outcome, retry, logs, and auditability.

## 11. Playbooks

Playbooks can become more valuable than individual rules because they capture recurring supervisory workflows.

Example: **Finish & Ship**

```text
/finish-and-ship GP-329
```

Expands to:

1. Ask the agent to complete implementation.
2. Run required verification.
3. Request independent review.
4. Require clean Git status.
5. Commit.
6. Push.
7. Open pull request.
8. Wait for checks.
9. Notify the operator if checks fail.
10. Add PR to Approval Inbox.

Other candidate playbooks:

- `/check-and-report`
- `/investigate`
- `/prepare-pr`
- `/review-other-session`
- `/close-mission`
- `/compare-models`
- `/deploy-test`
- `/run-regression`

Repeated supervision can gradually be promoted into deterministic or policy-constrained automation.

## 12. Universal Command Palette

The existing top search field should become an always-available command interface.

Examples:

```text
> Open GP-329
> Ask all active sessions for status
> Show blocked
> Switch to Monitor
> Create automation
> Run Finish & Ship on GP-329
> Compare Bash and GP-329
> Open latest artifact
> Start research team
> Show sessions touching Marketing Model
```

For a dense expert application, keyboard-first operation should be a core design principle rather than an optional shortcut layer.

## 13. Session Dock

Replace dependence on dropdowns with a persistent compact session list.

```text
ACTIVE

● GP-329          validating       14m
● Bash            reviewing         8m
◐ Research        waiting          21m
! ETL-112         BLOCKED          42m

RECENT

✓ SALES-014       complete
✓ UI-441          complete
```

Each row should expose status, session, mission, current activity, age, unread count, and whether human input is required.

Hover or quick-view can reveal repository, branch, context usage, cost, and actions such as Focus, Message, Pause, Stop, Pin, or Open in new pane.

## 14. Context Inspector

One of the most important panels in the whole redesign. Keep relevant context visible beside chat rather than forcing the operator to remember it.

```text
CONTEXT

Mission
GP-329

Goal
Fix Google ad-spend calculation

Repository
aldc-launchpad

Branch
feature/gp329...

Environment
TEST

Changed
3 files

Commits
2

Artifacts
5

Tests
14 / 14

Dependencies
Bash review

Permissions
TEST: WRITE
PROD: READ ONLY
```

Potential tabs:

- Mission
- Files / Changes
- Artifacts
- Evidence
- Dependencies
- Permissions
- Metrics
- Diagnostics

## 15. Visual System

### Color semantics

Use a neutral near-black and charcoal foundation. Green should not be both the brand accent and generic status color.

Suggested semantic roles:

| Role | Treatment |
|---|---|
| Primary background | Near-black neutral |
| Elevated panel | Slightly lighter charcoal |
| Borders | Low-contrast neutral |
| Primary text | Warm off-white |
| Secondary text | Muted gray |
| Interaction accent | Electric blue / cool cyan |
| Success | Green |
| Warning | Amber |
| Failure | Red |
| Running | Blue/cyan |
| Waiting | Slate |

### Reduce nested borders

Use spacing, typography, surface elevation, and alignment rather than placing every UI region inside another visible rectangle.

### Status as an object

Instead of raw implementation strings such as `RUNNING-ATTACHED`, expose operator-facing state such as:

```text
RUNNING  14m
Connected · Claude Code
```

Machine-level terminology can remain available in Diagnostics.

## 16. Proposed Information Architecture

```text
SWITCHBOARD

Command

NOW
  Overview
  Inbox                 4

WORK
  Missions
  Sessions              7
  Automations
  Approvals             2

INTELLIGENCE
  Activity
  Evidence
  Artifacts

SYSTEM
  Worktrees
  Diagnostics
  System Health
```

The concept of “Console” can become one mode inside Sessions rather than the primary product abstraction.

Within a session:

```text
Conversation | Timeline | Artifacts | Changes | Terminal | Diagnostics
```

## 17. Proposed Default Screen

```text
+------------------------------------------------------------------------------+
| SWITCHBOARD      Search or command...                          + SESSION     |
+--------------+-----------------------------------------+---------------------+
|              | GP-329                                  | CONTEXT             |
| NOW          | Google Ad Spend                         |                     |
| Overview     | ● Running · 14m                         | Marketing Model     |
| Inbox     4  +-----------------------------------------+ TEST                |
|              |                                         |                     |
| WORK         | YOU                                     | Branch              |
| Missions     | Finish the validation. Do not deploy.   | feature/gp329...    |
| Sessions  7  |                                         |                     |
| Automations  | GP-329                                  | Files changed       |
| Approvals 2  | Validation is complete. I found one     | 3                   |
|              | discrepancy between...                  |                     |
| ACTIVE       |                                         | Tests               |
| ● GP-329     | > Bash · 2.1s                           | 14 / 14             |
| ● Bash       |   query warehouse                       |                     |
| ◐ Research   |                                         | Cost                |
| ! ETL-112    | ✓ Warehouse response received           | $2.12               |
|              |                                         |                     |
|              | ! NEEDS DECISION                        | ARTIFACTS           |
|              | Currency handling differs.              | Validation report   |
|              |                                         | Diff                |
|              | [Review evidence]                       | Test results        |
+--------------+-----------------------------------------+---------------------+
| To: GP-329 v                                                               |
| Tell it what to do...                                                       |
| +  @  /         Voice                        Schedule   Actions     SEND ->  |
+------------------------------------------------------------------------------+
```

## 18. Adaptive Information Density

Support three levels of density:

### Focus density
One mission, high detail.

### Operational density
Approximately 5-15 sessions, summarized.

### Fleet density
Dozens or hundreds of sessions represented statistically, with drill-down by mission/team/status/risk.

This creates a path from a single operative to a team, a collection of Cells, and eventually much larger organizational structures without redesigning the product every time scale increases.

## 19. Feature Backlog — 18 High-Leverage Features

| # | Feature | Primary value | Priority |
|---|---|---|---|
| 1 | Mission Composer | Rich instruction surface replacing tiny reply box | P0 |
| 2 | Action Inbox | Shows exactly where human intervention is required | P0 |
| 3 | Focus / Compare / Monitor layouts | Task-appropriate information density | P0 |
| 4 | Structured session messages | Separate chat, tools, logs, artifacts, blockers | P0 |
| 5 | Session Dock | Fast switching with status/unread/blocker indicators | P0 |
| 6 | Universal Command Palette | Keyboard control of the product | P0 |
| 7 | Cross-session Broadcast | Send one instruction to selected sessions/team | P0 |
| 8 | Mission Channels | Communication organized around work | P1 |
| 9 | Push-to-Talk / Dictation | Fast instruction capture | P1 |
| 10 | Spoken Alerts / Responses | Hands-free awareness of important state changes | P1 |
| 11 | Automation Rule Builder | Event/condition/action orchestration | P0 |
| 12 | Natural-language Automation Creation | Create rules without learning a DSL | P1 |
| 13 | Reusable Playbooks / Macros | Convert repeated supervision into reusable actions | P0 |
| 14 | Automatic Handoff | Route completed/blocked work to the right next agent | P1 |
| 15 | Approval Center | Centralize deploy/high-risk decisions | P0 |
| 16 | Mission Timeline + Replay | Debugging, auditability, learning | P1 |
| 17 | Scheduled Briefings | Morning/end-of-day/project summaries | P1 |
| 18 | Context Inspector | Keep mission/repo/evidence state visible | P0 |

## 20. Recommended Build Sequence

| Phase | Work |
|---|---|
| P0 — Foundation | New shell, Session Dock, Focus mode, Context Inspector, structured event renderer |
| P0 — Productivity | Mission Composer, Command Palette, Inbox |
| P0 — Automation | Automation data model, Rule Builder, Playbooks, execution history |
| P1 — Multi-agent | Compare mode, Monitor Wall, Broadcast, mission channels |
| P1 — Governance | Approval Center, blockers, escalation rules |
| P1 — Intelligence | Mission Timeline, replay, artifacts/evidence |
| P1 — Voice | Push-to-talk, transcription preview, selective voice notifications |
| P2 — Advanced | War Room, fleet views, learned automations, automatic handoffs |

## 21. UX Success Metrics

The redesign should be evaluated on operator outcomes, not visual novelty.

Recommended metrics:

- Median time to identify the one session requiring human intervention.
- Number of session panes opened per completed mission.
- Percentage of session execution consumed as summarized events vs raw log inspection.
- Time to send one instruction to multiple sessions.
- Time to retrieve mission/repository/branch/test context.
- Number of repeated manual supervisory actions converted into playbooks or rules.
- Median approval response time.
- Number of missed or stale “needs human” states.
- Time to reconstruct why a mission failed from timeline/evidence.
- Operator context switches per hour.
- Keyboard-command utilization among expert users.
- Automation success, false-trigger, retry, and override rates.

## 22. Research / Prior-Art References Used in the Concept

These references are not meant to imply Switchboard should copy these products; they are useful interaction precedents.

1. Nielsen Norman Group — Ten Usability Heuristics for User Interface Design. https://www.nngroup.com/articles/ten-usability-heuristics/
2. Nielsen Norman Group — Recognition Rather Than Recall. https://www.nngroup.com/articles/ten-usability-heuristics/
3. Linear — Inbox. https://linear.app/docs/inbox
4. Linear — Search. https://linear.app/docs/search
5. VS Code — Terminal Basics / editor and terminal group patterns. https://code.visualstudio.com/docs/terminal/basics
6. VS Code — Voice accessibility / dictation patterns. https://code.visualstudio.com/docs/configure/accessibility/voice
7. Slack — Huddles and multimodal collaboration patterns. https://slack.com/help/articles/4402059015315-Use-huddles-in-Slack
8. n8n — Workflow execution history and retry patterns. https://docs.n8n.io/workflows/executions/all-executions/

## 23. Final Product Principle

Switchboard should evolve through the following operator relationship:

```text
OBSERVE
   |
   v
COMMUNICATE
   |
   v
COORDINATE
   |
   v
AUTOMATE
   |
   v
DELEGATE
```

This is a stronger north star than simply increasing the number of panes or making the console prettier. It gives the current session manager a natural path toward a premium operational layer for larger agent teams and CELL OS structures.

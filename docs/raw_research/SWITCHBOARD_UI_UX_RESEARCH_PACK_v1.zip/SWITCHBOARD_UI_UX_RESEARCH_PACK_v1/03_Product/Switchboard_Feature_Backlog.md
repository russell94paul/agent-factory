# Switchboard Feature Backlog

## P0 — Core Redesign

| ID | Feature | Problem Solved | Acceptance Signal |
|---|---|---|---|
| SWB-001 | Mission Composer | Tiny terminal reply box limits rich agent direction | One composer supports direct, selected, mission, and broadcast targets |
| SWB-002 | Action Inbox | Operator must inspect terminals to find work requiring attention | All explicit human-required states appear in one queue |
| SWB-003 | Structured Event Renderer | Chat, tools, logs, status, and artifacts are visually flattened | Event types have semantic UI treatments and raw log remains available |
| SWB-004 | Session Dock | Dropdown-first switching hides operational state | Active sessions visible with status, activity, age, unread, blocker flags |
| SWB-005 | Focus Layout | Current pane layout wastes space and lacks context | Default workspace centers conversation with persistent context inspector |
| SWB-006 | Compare Layout | Side-by-side panes lack higher-order coordination | Two sessions can be viewed, jointly instructed, and compared |
| SWB-007 | Monitor Wall | Full transcripts do not scale beyond a few sessions | 6-15 sessions summarized as live operational cards |
| SWB-008 | Context Inspector | User must remember/recover repo and mission context | Core mission/repo/branch/tests/artifacts state visible beside session |
| SWB-009 | Command Palette | Dense product needs fast expert navigation | Core navigation/actions accessible via keyboard command search |
| SWB-010 | Broadcast | Repeating the same instruction across sessions is wasteful | Operator can target selected sessions or a mission team once |
| SWB-011 | Automation Rule Builder | Repeated monitoring/intervention remains manual | Event/condition/action rule can be created, enabled, and audited |
| SWB-012 | Playbooks | Repeatable supervisory workflows are retyped | Saved multi-step actions can be invoked from composer/command palette |
| SWB-013 | Automation Executions | Automation without history is hard to trust | Runs expose status, timing, actions, error, retry, and source rule |
| SWB-014 | Approval Center | High-risk decisions are scattered through transcripts | All pending governed actions appear in a dedicated queue |

## P1 — Multi-Agent Productivity

| ID | Feature | Problem Solved | Acceptance Signal |
|---|---|---|---|
| SWB-101 | Mission Channels | Work discussion is tied too tightly to individual sessions | Persistent mission-scoped conversation exists independent of one process |
| SWB-102 | Team Channels | Recurring teams need durable coordination context | Team-level communication can include multiple missions/sessions |
| SWB-103 | War Room | Incident coordination needs shared timeline/evidence | Incident layout shows active agents, blockers, evidence, hypotheses, timeline |
| SWB-104 | Mission Timeline | Operators cannot quickly reconstruct execution | Major human/agent/tool/state/artifact events appear chronologically |
| SWB-105 | Review / Replay | Postmortem requires reading raw transcripts | Completed mission can be scrubbed and filtered by event type |
| SWB-106 | Automatic Handoff | Human manually routes work between agents | Policy can transfer work/artifacts when stage or state conditions are met |
| SWB-107 | Natural-Language Automation | Rule builders introduce configuration friction | Plain-language intent compiles to inspectable editable rule |
| SWB-108 | Scheduled Briefings | Operator repeatedly checks overnight/current work | Daily/weekly/milestone briefings generated from live mission state |
| SWB-109 | Push-to-Talk | Supervisory typing interrupts flow | Voice command creates editable dispatch preview |
| SWB-110 | Selective Spoken Alerts | Critical events can be missed while user is elsewhere | Configurable event classes generate concise spoken alert + visible item |
| SWB-111 | Saved Layouts | Different missions need different arrangements | User saves and restores named workspace configurations |
| SWB-112 | Session Pinning / Priorities | High-value sessions compete with background work | Pinned/priority sessions remain prominent across views |

## P2 — Advanced Agentic Operations

| ID | Feature | Problem Solved | Acceptance Signal |
|---|---|---|---|
| SWB-201 | Fleet View | Monitor Wall does not scale to large organizations | Aggregations by team/mission/status/risk with drill-down |
| SWB-202 | Learned Automation Suggestions | Repeated supervision remains unnoticed | Product identifies recurring operator sequences and proposes playbook/rule |
| SWB-203 | Attention Forecast | Operator is reactive to future approval/blocker load | Near-term likely human attention demands are summarized |
| SWB-204 | Cross-Session Synthesis | User manually compares agent conclusions | Selected sessions produce explicit agreement/disagreement synthesis |
| SWB-205 | Evidence Graph | Artifacts and claims are difficult to trace | Mission evidence can be navigated by source, decision, artifact, outcome |
| SWB-206 | Policy-Aware Delegation | Automation must respect environment/risk boundaries | Rules/playbooks show permitted, gated, and prohibited actions before run |
| SWB-207 | Automation Simulation | New automation may behave unexpectedly | Rule/playbook can be replayed against historical events before enabling |
| SWB-208 | Mission Templates | Frequent work begins from blank context | Mission type can preconfigure layout, team, channels, context, automations |

## Suggested First Vertical Slice

Build the smallest complete experience that proves the new mental model:

1. New application shell.
2. Session Dock.
3. Focus workspace.
4. Structured event renderer.
5. Context Inspector.
6. Mission Composer.
7. Action Inbox.
8. One simple automation: `blocked > N minutes -> inbox notification`.

This is preferable to building a polished Automation Studio before the core communication and attention model is fixed.

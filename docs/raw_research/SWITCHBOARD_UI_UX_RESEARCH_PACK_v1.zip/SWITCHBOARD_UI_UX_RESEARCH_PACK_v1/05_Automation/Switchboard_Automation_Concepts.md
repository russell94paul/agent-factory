# Switchboard Automation Concepts

## Product Thesis

Automation should reduce repeated **operator supervision**, not merely run cron jobs.

A useful Switchboard automation is usually one of five things:

1. **Watch** — detect a state or threshold.
2. **Summarize** — compress agent activity into useful information.
3. **Route** — move work/context to the correct session/team.
4. **Govern** — request/require approval for risky actions.
5. **Execute** — perform a safe repeatable procedure.

## Core Model

```text
TRIGGER -> CONDITIONS -> ACTIONS -> GATES -> DELIVERY -> AUDIT
```

### Triggers
- Schedule.
- Session state change.
- Mission state change.
- Tool/error event.
- Pull request status.
- Artifact created.
- Test result.
- Approval requested.
- Human message.
- External integration event.

### Conditions
- Duration threshold.
- Environment.
- Risk.
- Mission/team/session.
- Error class.
- Confidence threshold.
- Cost threshold.
- Business hours.
- Dependency state.

### Actions
- Ask session for status.
- Send instruction.
- Broadcast.
- Create mission.
- Start/restart a session.
- Route artifact.
- Run playbook.
- Create inbox item.
- Request approval.
- Notify / speak.
- Pause/stop within policy.

### Gates
- Always allow.
- Require approval.
- Allowed only in TEST.
- Human approval for PROD.
- Cost/risk threshold.
- Specific role/permission.

## High-Value Automation Features

### 1. Blocked Session Escalation
When a session remains blocked for N minutes, ask it to summarize the blocker. If unresolved, create a Needs You inbox item.

### 2. Morning Operations Brief
Summarize running, blocked, failed, completed, and awaiting-approval work since the previous brief.

### 3. End-of-Day Handoff
Ask active sessions to persist status, artifacts, next actions, and unresolved questions, then create a concise resume point for the next day.

### 4. PR Watch
When an agent opens a PR, monitor checks. On failure, route failure context back to the originating session. On success, create approval item.

### 5. Stale Session Watch
Detect no meaningful activity for a configured duration and distinguish legitimate waiting from stalled execution before alerting.

### 6. Budget Guard
Warn or pause when a mission crosses a cost budget or context threshold, subject to mission policy.

### 7. Automatic Review Handoff
After implementation completes, pass diff, objective, and tests to a reviewer session without the operator manually copying context.

### 8. Artifact Routing
When a specified artifact is generated, attach it to the mission, notify relevant agents, and pin it in the Context Inspector.

### 9. Failed Automation Recovery
Retry safe transient failures, but escalate deterministic/permanent failures rather than repeatedly re-running them.

### 10. Production Gate
Any action targeting production creates an Approval Center item containing target, diff/action, evidence, tests, risk, and originating session.

### 11. Session Completion Hygiene
On completion, require final summary, changed files, commits, tests, artifacts, and known issues before marking the mission complete.

### 12. Recurring Research / Maintenance Mission
Schedule a recurring mission template and deliver output into a dedicated channel/inbox without forcing the user to manually initiate it.

## Playbook Model

A playbook is a versioned, named, reusable sequence that can contain deterministic steps, agent instructions, checks, branches, and approval gates.

Example:

```yaml
playbook:
  name: finish-and-ship
  version: 1

steps:
  - instruct_current_session: finish implementation
  - run: requested verification
  - require: clean_git_status
  - invoke: independent_review
  - if: review_passed
    then:
      - commit
      - push
      - open_pr
  - wait_for: checks
  - if: checks_failed
    then: route_failure_to_origin_session
  - if: checks_passed
    then: create_approval_item
```

## Natural-Language Creation UX

The user types:

> If GP-329 is blocked for more than 10 minutes, ask it what it needs. If it still needs me, put it in my Inbox and speak a short alert.

Switchboard should:

1. Parse intent.
2. Produce an inspectable rule.
3. Highlight assumptions.
4. Show permission/risk implications.
5. Offer a test/simulation event.
6. Require explicit enable action.

## Automation Trust Requirements

- Clear enabled/disabled state.
- Every execution recorded.
- Source rule/playbook/version recorded.
- Retry reason visible.
- Manual override available.
- No silent privilege escalation.
- Production gates explicit.
- Easy rollback to previous playbook version.
- Simulation against historical events for important rules.
- False-positive/false-trigger metrics for monitoring rules.
